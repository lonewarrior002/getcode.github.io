<?php

if (!function_exists('sendEmail')) {

    function sendEmail($subject = '', $to = '', $message = '') {

        //echo $subject;
        //echo $to;die();
        $CI = &get_instance();

		$config['protocol'] = "smtp";
        $config['smtp_host'] = "ssl://smtp.gmail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = $CI->config->item('smtp_user');
        $config['smtp_pass'] = $CI->config->item('smtp_pass');
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";
        //print_r($config);die();

        $CI->email->initialize($config);

//        echo $CI->config->item('from');die();

        $CI->email->from($CI->config->item('from'), SITENAME);

        $CI->email->to($to);

        $CI->email->subject($subject);

        $CI->email->message($message);

        // print_r($CI->email->send());die();


        if ($CI->email->send()) {
            return TRUE;

        } else {

        //$error = show_error($CI->email->print_debugger());
        //die();
        //return $error;
        return FALSE;
        }
    }

}


if (!function_exists('send_push')) {

    function send_push($user_id = '', $user_type = '', $push_title = '', $push_message = '', $message_type = '', $extra_param = []) {
        
        $ci = & get_instance();

        if ($user_id != '' && $user_type != '') {

            $ci->db->select(array('device_type', 'device_token'));

            $row = (array) $ci->db->get_where($user_type, array('id' => $user_id))->row();
                
                $key = $ci->config->item('fcm_key');

                $token = $row['device_token'];

                if ($row['device_type'] == IOS_DEVICE) {

                    $fcmFields = array(
                        'priority' => 'high',
                        'to'       => $token,
                        'notification'  => array(
                            "title"     => $push_title,
                            "body"      => $push_message,
                            "type"      => $message_type,
                            "response"  => $extra_param,
                            'sound'      => 'default'
                        ),
                    );
                    if($message_type == 'logout' || $message_type == 'profile_approved') {
                        $fcmFields['notification']['content-available'] = 1;
                        $fcmFields['notification']['apns-priority'] = 5;
                    }
                } else {
                   
                    $fcmFields = array(
                        'priority' => 'high',
                        'to'       => $token,
                        'data' => array(
                            "type" => $message_type,                            
                            "title"     => $push_title,
                            "body"      => $push_message,
                            'response'  => $extra_param,
                            'sound'    => 'default',
                        )
                    );
                }
                $headers = array('Authorization: key=' . $key, 'Content-Type: application/json');
                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');

                curl_setopt($ch, CURLOPT_POST, true);

                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmFields));

                $result = curl_exec($ch);

                curl_close($ch);
            //    echo '<pre>';
            //    print_r($fcmFields);
            //    echo '<br>';
               //print_r($result);
               //die();

        }
    }
}

if (!function_exists('send_bulk_push')) {

    function send_bulk_push($tokens = '', $device_type = '', $push_title = '', $push_message = '', $message_type = '', $data = []) {
        $ci = & get_instance();
        if ($tokens != '' && $device_type != '') {

            $key = $ci->config->item('fcm_key');

            if ($device_type == 'android') {

                $push_data = array(
                    'body' => $push_message,
                    'title' => $push_title,
                    'sound' => "default",
                    'data' => $data,
                    'type' => $message_type
                );
                $fcmFields = array(
                    'registration_ids' => $tokens,
                    'priority' => 'high',
                    'data' => $push_data,
                );
            } else {
                $push_data = array(
                    'body' => $push_message,
                    'title' => $push_title,
                    'sound' => "default",
                    'data' => $data,
                    'type' => $message_type
                );
                $fcmFields = array(
                    'registration_ids' => $tokens,
                    'priority' => 'high',
                    'notification' => $push_data,
                );
            }
            // echo json_encode( $fcmFields );die;
            $headers = array('Authorization: key=' . $key, 'Content-Type: application/json');

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmFields));
            $result = curl_exec($ch);
            curl_close($ch);
        //    echo $result . "\n\n";die;
        }
    }

}

if (!function_exists('sendEmail_')) {
    
    function sendEmail_($subject, $to, $message) {
        $url = 'https://api.sendgrid.com/';
        $user = 'kv.eww';
        $pass = 'kv.eww@123*';

        
        $params = array(
            'api_user' => $user,
            'api_key' => $pass,
            'to' => $to,
            'subject' => $subject,
            'html' => $message,
            'text' => '',
            'from' => 'noreply@excellentwebworld.info',
        );

        $request = $url . 'api/mail.send.json';

// Generate curl request
        $session = curl_init($request);

// Tell curl to use HTTP POST
        curl_setopt($session, CURLOPT_POST, true);

// Tell curl that this is the body of the POST
        curl_setopt($session, CURLOPT_POSTFIELDS, $params);

// Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
// Tell PHP not to use SSLv3 (instead opting for TLS)
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

// obtain response
        $response = curl_exec($session);
        curl_close($session);

// print everything out
//        print_r($response);
        return TRUE;
    }
    
}

if (!function_exists('create_email_template_new'))
{
    function create_email_template_new($template)
    {
        //echo 'dsafsf';exit;
        $ci=& get_instance();
        $base_url = BASE_URL();
        $template = str_replace('##SITEURL##', $base_url, $template);
        $template = str_replace('##SITENAME##', $ci->config->item('site_name'), $template);
        $template = str_replace('##SITEEMAIL##', $ci->config->item('site_email'), $template);
        $template = str_replace('##FOOTER##', $ci->config->item('footer'), $template);
        $template = str_replace('##SITELOGO##', $ci->config->item('site_logo'), $template);
        $template = str_replace('##CURRENCY##', $ci->config->item('currency'), $template);         
        return $template;
    }
}
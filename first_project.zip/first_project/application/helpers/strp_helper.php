<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



if (!function_exists('pay_stripe'))
{
    function pay_stripe($card_info)
    {
        //print_r($card_info);exit;
         $CI =& get_instance();
        // print_r($CI);exit;
         $CI->load->library('Stripe');

          $card_array['name'] = $card_info['Fullname'];
          $card_array['card_number'] = $card_info['credit_card_no'];

          $monthyear = explode('/',$card_info['expiry_date']);
          //$month_array = array('Jan'=>'01','Feb'=>'02','Mar'=>'03','Apr'=>'04','May'=>'05','Jun'=>'06','Jul'=>'07','Aug'=>'08','Sep'=>'09','Oct'=>'10','Nov'=>'11','Dec'=>'12');
          
          $card_array['month'] = $monthyear[0];
          $card_array['year'] = $monthyear[1];
          $card_array['cvc_number'] = $card_info['security_code'];

//          print_r($card_array);exit;

        $stripeCardObject=$CI->stripe->createToken($card_array);
    //    print_r($stripeCardObject);exit;
        if(isset($stripeCardObject['status']) && $stripeCardObject['status'] == true)
        {            

            $stripe_pay['amount'] = $card_info['cost'];
            $stripe_pay['source'] = $stripeCardObject['token'];
            $booking_id = 0;
            if(isset($card_info['purchase_id']))
            {
              $booking_id = $card_info['purchase_id'];
            }
            $stripe_pay['description'] = $card_info['Description'];

            $paymentResponse = $CI->stripe->addCharge($stripe_pay);

            // _pre($paymentResponse);
            
            if(isset($paymentResponse['status']) && $paymentResponse['status'] == true)
            {
                
                //print_r($paymentResponse['success']->balance_transaction);
                //print_r($paymentResponse['success']->id);exit;
//                $response['Status'] = $paymentResponse['status'];
                $response['Status'] = 'success';
                $response['ReferenceId'] = $paymentResponse['success']->id;
                $response['id'] = $paymentResponse['success']->id;
                return $response;
            }
            else
            {
                $response['Status'] = 'failed';
                $response['ReferenceId'] = 0;
                //$response['id'] = $paymentResponse['success']->id;
                return $response;
            }
            // _pre($response);
        }
        else
        {
           
            //print_r($stripeCardObject['error']);
            $stripeCardObject['Status'] = $stripeCardObject['status'];
            return $stripeCardObject;
        }
        exit;
    } 


    function refund_stripe($id ='')
    {
      $CI =& get_instance();
         $CI->load->library('Stripe');
      $paymentResponse = $CI->stripe->addRefund($id);

      return $paymentResponse;
      //print_r($paymentResponse);exit;
    }

}
<?php

if(!function_exists('assets')){

	function assets($file)

	{

		return base_url('assets/').$file;

	}

}

if(!function_exists('assets_css')){

	function assets_css($file)

	{

		return base_url('assets/css/').$file.'.css';

	}

}

if(!function_exists('assets_js')){

	function assets_js($file)

	{

		return base_url('assets/js/').$file.'.js';

	}

}

if(!function_exists('assets_image')){

	function assets_image($file)

	{

		return base_url('assets/image/').$file;

	}

}

if(!function_exists('assets_upload')){

	function assets_upload($file)

	{

		return base_url('assets/upload/').$file;

	}

}

if(!function_exists('validation_errors_response_web')){

    function validation_errors_response_web()

    {

    	$err_array=array();

    	$err_str="";

    	$err_str=str_replace(array('<p>','</p>'),array('|',''),trim(validation_errors()));



    	$err_str=ltrim($err_str,'|');

    	$err_str=rtrim($err_str,'|');

    	// $err_array=explode('|',$err_str);

    	// $err_array = array_filter($err_array);

    	return $err_array;

    }

}

/*

* Additional :

*/

if(!function_exists('assets_less')){

	function assets_less($file)

	{

		return base_url('assets/less/').$file.'.less';

	}

}

if(!function_exists('assets_sass')){

	function assets_sass($file)

	{

		return base_url('assets/sass/').$file.'.sass';

	}

}

if(!function_exists('to_json')){

	function to_json($array)

	{

		

	}

}

if(!function_exists('config')){

	function config($key)

	{

		$CI = get_instance();

		$CI->load->model('Config');

		$config = Config::wherePath($key)->first();

		return $config->value;

	}

}

if(!function_exists('config_set')){

	function config_set($key_array)

	{

		$CI = get_instance();

        $CI->load->model('Config');

		foreach ($key_array as $key => $value) {

			$update['value']=$value;

			

			Config::wherePath($key)->update($update);

		}

		return true;

	}

}

// if(!function_exists('image_upload')){

// 	 function image_upload($file,$path='',$enc=FALSE,$type = '', $size = ''){

// 	 	$CI = get_instance();

	 	

// 	 	if(!is_dir("./assets/".$path))

// 	 	{

	 		

// 	 		mkdir("./assets/".$path,0777,TRUE);

// 	 	}



// 		$config = array(

// 			'upload_path' => "./assets/".$path,

// 			'allowed_types' => ($type) ?? "gif|jpg|png|PNG|jpeg|pdf",

// 			'overwrite' => TRUE,

// 			'max_size' => ($size) ?? "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)

// 			'remove_spaces' => TRUE,

//             'encrypt_name' => $enc,

//             'file_ext_tolower' =>TRUE

// 		);

// 		$CI->load->library('upload', $config);

// 		$CI->upload->initialize($config);

// 		if($CI->upload->do_upload($file))

// 		{

// 			$data = $CI->upload->data();

// 			$data['status'] = true;

// 			$data['uploaded_path'] = "assets/".$path.$data['file_name'];

			

// 		}

// 		else

// 		{

// 			$data['error']  = strip_tags($CI->upload->display_errors());

// 			$data['status'] = false;

//             $data['uploaded_path'] = '';

// 		}

// 		return $data;

// 	}

// }

if(!function_exists('image_upload')){

	 function image_upload($file,$path='',$enc=FALSE,$type = '', $size = '', $custom_name = ''){

	 	//print_r($type);die();

	 	$CI = get_instance();

	 	if(!is_dir("./assets/".$path))

	 	{
	 		mkdir("./assets/".$path,0777,TRUE);

	 	}

		$config = array(

			'upload_path' => "./assets/".$path,

			'allowed_types' => ($type) ? $type: "gif|jpg|png|PNG|jpeg|pdf",

			'overwrite' => TRUE,

			'max_size' => ($size) ? $size: "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)

			'remove_spaces' => TRUE,

            'encrypt_name' => $enc,

            'file_ext_tolower' =>TRUE,

            'quality' => '60%'

		);
        if(!empty($custom_name)) {
            $config['file_name'] = $custom_name;
        }

		$CI->load->library('upload', $config);

		$CI->upload->initialize($config);

		if($CI->upload->do_upload($file))

		{

			$data = $CI->upload->data();

			$data['status'] = true;

			$data['uploaded_path'] = "assets/".$path.$data['file_name'];

			if($type == 'jpg|JPG|png|PNG|jpeg|JPEG'){
                $return_url = compress_image(FCPATH.$data['uploaded_path'], "assets/" . $path . 'thumb_'.$data['file_name'], 70);

                //print_r($return_url);die();
                @unlink(FCPATH.$data['uploaded_path']);
                $data['uploaded_path'] = "assets/" . $path . 'thumb_'.$data['file_name'];
            }

			//print_r($data);die();

		}

		else

		{

			$data['error']  = strip_tags($CI->upload->display_errors());

			$data['status'] = false;

            $data['uploaded_path'] = 'error';

            //print_r($data);die();

		}

		return $data;

	}

}

if(!function_exists('__timeago')){

	function __timeago($datetime, $full = false) {

		    $now = new DateTime;

		    $ago = new DateTime($datetime);

		    $diff = $now->diff($ago);



		    $diff->w = floor($diff->d / 7);

		    $diff->d -= $diff->w * 7;



		    $string = array(

		        'y' => 'year',

		        'm' => 'month',

		        'w' => 'week',

		        'd' => 'day',

		        'h' => 'hour',

		        'i' => 'minute',

		        's' => 'second',

		    );

		    foreach ($string as $k => &$v) {

		        if ($diff->$k) {

		            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');

		        } else {

		            unset($string[$k]);

		        }

		    }



		    if (!$full) $string = array_slice($string, 0, 1);

		    return $string ? implode(', ', $string) . ' ago' : 'just now';

		}

}


if (!function_exists('__date'))

{	

	function __date($date, $timestamp=false)

	{

		if($timestamp)

		{
            return date(DATE_FORMAT, $date);
            
		}

		else

		{

			return date(DATE_FORMAT, strtotime($date));

		}

	}

}



if (!function_exists('base64ToImage'))

{	

	function base64ToImage($image,$dir)

	{

        $img     = $image;

        $img     = str_replace('data:image/png;base64,', '', $img);

        $img     = str_replace('data:image/jpeg;base64,', '', $img);

        $img     = str_replace(' ', '+', $img);

        $data    = base64_decode($img);

        $time    = time() . '.png';

        $file    = 'assets/'.$dir.$time;

        $success = file_put_contents($file, $data);

        if($success)

        {

        	return $time;

        }

        else

        {

        	return "";

        }

	}

}



if (!function_exists('_pre'))

{	

	function _pre($array)

	{

        echo "<pre>";

        print_r($array);

        echo "<pre>";

        exit;

	}

}



if(!function_exists('show_general'))

{

	function show_general($message="")

	{

		$CI = get_instance();

		$data['heading'] = "Auth error";

		$data['message'] = $message;

		$CI->load->view('errors/html/error_general',$data);

	}

}





if(!function_exists('routeLink'))

{

	function routeLink($url)

	{

		return base_url($url);

	}

}



if(!function_exists('generateString'))

{

	function generateString() {

		$strength = 6;

		$input = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

	    $input_length = strlen($input);

	    $random_string = '';

	    for($i = 0; $i < $strength; $i++) {

	        $random_character = $input[mt_rand(0, $input_length - 1)];

	        $random_string .= $random_character;

	    }

	    return $random_string;

	}

}





if(!function_exists('renderFront'))

{

	function renderFront($page = null,$params = null, $return = false)

	{

		$CI = get_instance();

        $CI->load->view('front/layout/header',[]);

        if($page != null){

            $CI->load->view('front/pages/'.$page,$params,$return);

        }

        $CI->load->view('front/layout/footer',$params);

	}

}





if(!function_exists('validation_errors_response'))

{

	 function validation_errors_response()

    {

    	$err_array=array();

    	$err_str="";

    	$err_str=str_replace(array('<p>','</p>'),array('|',''),trim(validation_errors()));

    	$err_str=ltrim($err_str,'|');

    	$err_str=rtrim($err_str,'|');
        
    	$err_str=str_replace('|', '', trim($err_str));
        
        return $err_str;
    }
	 function validation_errors_response1()

    {

    	$err_array=array();

    	$err_str="";

    	$err_str=str_replace(array('<p>','</p>'),array('|',''),trim(validation_errors()));

    	$err_str=ltrim($err_str,'|');

    	$err_str=rtrim($err_str,'|');

    	$err_array=explode('|',$err_str);

    	$err_array = array_filter($err_array);
        
    	return count($err_array) >1 ? $err_array: $err_array[0];

    }

}



if(!function_exists('encrypt')){

	function encrypt($string){

	    $CI = &get_instance();

	    $key = $CI->config->item('custom_encryption_key');

	    $result = '';

	    for($i=0, $k= strlen($string); $i<$k; $i++) {

	        $char = substr($string, $i, 1);

	        $keychar = substr($key, ($i % strlen($key))-1, 1);

	        $char = chr(ord($char)+ord($keychar));

	        $result .= $char;

	    }

	    return base64_encode($result);

	}

}



if(!function_exists('decrypt')){

	function decrypt($string) {

		//print_r($string);exit;

		$CI=& get_instance(); 

        $key = $CI->config->item('custom_encryption_key');

        $result = '';

        $string = base64_decode($string);

        for($i=0,$k=strlen($string); $i< $k ; $i++) 

        {

            $char = substr($string, $i, 1);

            $keychar = substr($key, ($i % strlen($key))-1, 1);

            $char = chr(ord($char)-ord($keychar));

            $result.=$char;

        }

        return $result;   

	}



}

if(!function_exists('generateRandomString')){

    function generateRandomString($length = 5) {

//        return substr(str_shuffle(str_repeat($x='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);

        return substr(str_shuffle(str_repeat($x='ABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);

    }

}

if(!function_exists('get_day_name')){

    function get_day_name($timestamp) {

        $date = date('d/m/Y', $timestamp);

        if($date == date('d/m/Y')) {

          $return_date = 'Today at '. date('h:i A', $timestamp);

        } else if($date == date('d/m/Y',now() - (24 * 60 * 60))) {

          $return_date = 'Yesterday at '. date('h:i A', $timestamp);

        } else {

            $return_date = date('d/m/Y h:i A', $timestamp);

        }

        return $return_date;

    }

}

if(!function_exists('ValidatePostFields')){

    function ValidatePostFields($postFields){

        $error = array();        

        foreach ($postFields as $field => $value){            

            if(!isset($field) || $value == '' || is_null($value)){                

                $error[]= "The ".ucfirst(str_replace('_', ' ',$field)) ." field is required";             

            }        

        }

        return $error;   

    }

}

if(!function_exists('validate_key')){ 

    function validate_key($key = '') {

        if($key != '') {

            $CI=& get_instance();             

            if($CI->config->item('api_key')  ==  $key) {

                return true; }

            else {

                return false; }

        } else {

            return false;

        }

    }

}

if(!function_exists('compress_image')) {

    function compress_image($source_url, $destination_url, $quality) {

        $info = getimagesize($source_url);

        if ($info['mime'] == 'image/jpeg')

            $image = imagecreatefromjpeg($source_url);



        elseif ($info['mime'] == 'image/gif')

            $image = imagecreatefromgif($source_url);



        elseif ($info['mime'] == 'image/png')

            $image = imagecreatefrompng($source_url);



        $is_image_create = imagejpeg($image, $destination_url, $quality);

        return $destination_url;

    }

}



if(!function_exists('current_date')) {

    function current_date() {

        return date('Y-m-d H:i:s');

    }

}


if(!function_exists('payout')){ 

	function payout($email,$amount,$token)
	{
        $batch_id = "batch-".time()."";
		$curl = curl_init();
        $note = "Payout #".$token;
        curl_setopt_array($curl, array(
            //CURLOPT_URL => "https://api.paypal.com/v1/payments/payouts",
            CURLOPT_URL => "https://api.sandbox.paypal.com/v1/payments/payouts",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
                            "sender_batch_header": {
                              "email_subject": "You have a payment",
                              "sender_batch_id": "'.$batch_id.'"
                            },
                            "items": [
                              {
                                "recipient_type": "EMAIL",
                                "amount": {
                                  "value": "'.$amount.'",
                                  "currency": "USD"
                                },
                                "receiver": "'.$email.'",
                                "note": "'.$note.'"
                              }
                            ]
                          }',
            CURLOPT_HTTPHEADER => array(
                'accept: application/json',
                'authorization: Bearer '.$token,
                'content-type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
        	$return['response'] = $err;
        	$return['batch_id'] = $batch_id;
            // echo "cURL Error #:" . $err;
        } else {
        	$return['response'] = $response;
        	$return['batch_id'] = $batch_id;
            // echo $response;
        }

        return $return;
	}

}

if(!function_exists('payout_bulk')){
    function payout_bulk($items,$token)
    {
        $batch_id = "batch-".time()."";
        $curl = curl_init();
        

        curl_setopt_array($curl, array(
            //CURLOPT_URL => "https://api.paypal.com/v1/payments/payouts",
            CURLOPT_URL => "https://api.sandbox.paypal.com/v1/payments/payouts",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
                            "sender_batch_header": {
                              "email_subject": "You have a payment",
                              "sender_batch_id": "'.$batch_id.'"
                            },
                            "items": '.$items.'
                          }',
            CURLOPT_HTTPHEADER => array(
                'accept: application/json',
                'authorization: Bearer '.$token,
                'content-type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            $return['response'] = $err;
            $return['batch_id'] = $batch_id;
            // echo "cURL Error #:" . $err;
        } else {
            $return['response'] = $response;
            $return['batch_id'] = $batch_id;
            // echo $response;
        }

        return $return;
    }
}

if(!function_exists('payment_status')){
    function payment_status($payout_id,$token){
        // Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
        $ch = curl_init();

        //curl_setopt($ch, CURLOPT_URL, 'https://api-m.paypal.com/v1/payments/payouts/'.$payout_id);
        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/payments/payouts/'.$payout_id);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: Bearer '.$token;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        return $result;
    }

}

if(!function_exists('payout_item_details')){
    function payout_item_details($payout_item_id,$token){

        $ch = curl_init();

        //curl_setopt($ch, CURLOPT_URL, 'https://api-m.paypal.com/v1/payments/payouts-item/'.$payout_item_id);
        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/payments/payouts-item/'.$payout_item_id);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: Bearer '.$token;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        return $result;
    }
}

if(!function_exists('get_token')){

	function get_token(){

		$ch = curl_init();

        //curl_setopt($ch, CURLOPT_URL, 'https://api-m.paypal.com/v1/oauth2/token');
        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/oauth2/token');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_USERPWD,  CLIENT_ID. ':' .SECRET );

        $headers = array();
        $headers[] = 'Accept: application/json';
        $headers[] = 'Accept-Language: en_US';
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        return json_decode($result,true)['access_token'];
        // echo '<pre>';print_r($result);
	}
}

if (!function_exists('cancel_unclaimed_payment'))

{

    function cancel_unclaimed_payment($payout_item_id,$token){
        
        $ch = curl_init();
        //curl_setopt($ch, CURLOPT_URL, 'https://api-m.paypal.com/v1/payments/payouts-item/'.$payout_item_id.'/cancel');
        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/payments/payouts-item/'.$payout_item_id.'/cancel');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: Bearer '.$token;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        return $result;
    }
}

if (!function_exists('create_email_template'))

{

    function create_email_template($template)

    {
    	$CI = get_instance();
        $template = str_replace('##SITEURL##', BASE_URL(), $template);

        $template = str_replace('##SITELOGO##', $CI->config->item('email_site_logo'), $template);

        $template = str_replace('##FOOTER##', FOOTER_COPYRIGHT.'<br>'.FOOTER_ADDRESS, $template);

        $template = str_replace('##CONTACTEMAIL##', CONTACT_EMAIL, $template);

        return $template;

    }

}

// multi language
if(!function_exists('__'))
{
    function __()
    {
        $args = func_get_args();
        if(count($args) >= 1){
        $CI = get_instance();
        $str = $args[0];
        $nstr = $str;
        $fstr = $CI->lang->line($str);
        if($fstr != null){
        $nstr = $fstr;
        }
        if(count($args) >= 2){
        array_shift($args);
        return vsprintf($nstr,$args);
        }
        return $nstr;
        }
        return null;
    }
}


if(!function_exists('lq')) {

    function lq() {
        $CI=& get_instance(); 
        
        return $CI->db->last_query();

    }



}

// if(!function_exists('renderWebsite')) {

//     function renderWebsite($page = null,$params = null, $return = false)
//     {
//         $params['body_class'] = $this->_generate_body_class();
//         $this->load->view('website/header',$params);
//         //$this->load->view('kitchen/layout/sidebar',$params);
//         if($page != null){
//             $this->load->view('website/'.$page,$params,$return);
//         }
//         $this->load->view('website/footer',$params);
//     }

// }
<?php 
use Twilio\Rest\Client;
require_once('Twilio/autoload.php');
class Twilio 
{

	public function send_sms($mobile_no = '',$message = '')
    {
    	$sid = "ACc68242d6ea816c0b7ab35dcf30dcd3b1";
		$token = "fbc4ceab996a740e9a41e540d31cbba5";

    	if($mobile_no != '' && $message != '')
    	{
    		$from_no = '+19292698686';
			$client = new Client($sid, $token);
			try {
			  $res = $client->messages->create($mobile_no,array('from' => $from_no,'body' => $message));			  
			}

			//catch exception
			catch(Exception $e) {
			  echo 'Message: ' .$e->getMessage();
			}
			//$res = $client->messages->create($mobile_no,array('from' => $from_no,'body' => $message));
			// echo "<pre>";
			// print_r($res);
			return true;
		}
		else
		{
			return false;
		}
    }

}


			
?>
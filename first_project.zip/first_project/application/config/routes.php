<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'auth';
$route['404_override'] = 'auth/error_404';
$route['translate_uri_dashes'] = FALSE;

$route['admin/login']                        = 'auth/admin_login';
$route['kitchen/login']                        = 'auth/kitchen_login';
$route['logout/(:any)']                      = 'auth/logout/$1';
$route['change-password/(:any)']             = 'auth/change_password/$1';
$route['auth/create-password/(:any)/(:any)'] = 'auth/create_password/$1/$2';
$route['forgot-password/(:any)']             = 'auth/forgot_password/$1';

$route['change/status/(:any)/(:num)'] = 'CommonController/change_status/$1/$2';


$route['home'] = 'Website/index';
$route['aboutus'] = 'Website/aboutus';
$route['our-advisor'] = 'Website/our_advisor_coming_soon';
$route['advisor-details(/:num)'] = 'Website/advisor_details$1';
$route['coming-soon'] = 'Website/our_advisor';
$route['work-with-us'] = 'Website/work_with_us';
$route['contact-us'] = 'Website/contact_us';

$route['admin'] = 'admin/DashboardController/index';
$route['admin/profile'] = 'admin/DashboardController/profile';

$route['admin/category'] = 'admin/CategoryController/index';
$route['admin/category/add'] = 'admin/CategoryController/add';
$route['admin/category/edit(/:num)?'] = 'admin/CategoryController/edit$1';
$route['admin/category/delete/(:num)'] = 'admin/CategoryController/delete/$1';

$route['admin/customer'] = 'admin/CustomerController/index';
$route['admin/customer/edit/(:num)'] = 'admin/CustomerController/edit/$1';
$route['admin/customer/delete/(:num)'] = 'admin/CustomerController/delete/$1';


$route['admin/testimonial'] = 'admin/TestimonialController/index';
$route['admin/testimonial/add'] = 'admin/TestimonialController/add';
$route['admin/testimonial/dropdown'] = 'admin/TestimonialController/get_dropdown_data';
$route['admin/testimonial/delete/(:num)'] = 'admin/TestimonialController/delete/$1';
$route['admin/testimonial/edit(/:num)?'] = 'admin/TestimonialController/edit$1';

// $route['admin/service-provider'] = 'admin/ServiceProviderController/index';
$route['admin/service-provider(/:any)?'] = 'admin/ServiceProviderController/index$1';
$route['admin/service-provider/edit(/:num)'] = 'admin/ServiceProviderController/edit$1';
$route['admin/service-provider/delete/(:num)'] = 'admin/ServiceProviderController/delete/$1';
$route['admin/service-provider/approve-status/(:num)'] = 'admin/ServiceProviderController/approve_status/$1';
$route['admin/s-p/profile-update-popup'] = 'admin/ServiceProviderController/profile_update_details_popup';
$route['admin/s-p/profile-update-save'] = 'admin/ServiceProviderController/profile_update_save';
$route['admin/service-provider/category-view(/:num)?(/:any)?(/:any)'] = 'admin/ServiceProviderController/category_view$1$2$3';

//$route['admin/payment'] = 'admin/PaymentController/index';

$route['admin/rating-review'] = 'admin/RatingController/index';
$route['admin/rating-review/delete/(:num)'] = 'admin/RatingController/delete/$1';

$route['admin/contact-us'] = 'admin/ContactUsController/index';
$route['admin/contact-us-popup'] = 'admin/ContactUsController/contact_us_popup';

$route['admin/training-management'] = 'admin/TrainingController/index';
$route['admin/training-management/add'] = 'admin/TrainingController/add';
$route['admin/training-management/edit(/:num)?'] = 'admin/TrainingController/edit$1';
$route['admin/upload-training'] = 'admin/TrainingController/upload_training';
$route['admin/training-management/edit-video(/:num)?'] = 'admin/TrainingController/upload_video$1';
$route['admin/training-management/delete/(:num)'] = 'admin/TrainingController/delete/$1';
$route['admin/training-management/delete-video/(:num)'] = 'admin/TrainingController/delete_video/$1';

$route['admin/privacy-policy'] = 'admin/CmsController/index';
$route['admin/customer-terms'] = 'admin/CmsController/customer_terms';
$route['admin/advisor-terms'] = 'admin/CmsController/advisor_terms';

$route['admin/settings'] = 'admin/SettingController/index';
$route['admin/update-settings'] = 'admin/SettingController/update_settings';
$route['admin/other-settings'] = 'admin/SettingController/other_settings';
$route['admin/open-other-settings-popup'] = 'admin/SettingController/open_other_settings_popup';
$route['admin/save-other-setting'] = 'admin/SettingController/save_other_setting';

$route['admin/seo'] = 'admin/SeoController/index';
$route['admin/get-seo-detail'] = 'admin/SeoController/get_seo_detail';

$route['admin/notification'] = 'admin/NotificationController/index';
$route['admin/notification/send'] = 'admin/NotificationController/send';
$route['admin/notification/dropdown'] = 'admin/NotificationController/get_dropdown_data';

$route['admin/offers(/:any)?(/:any)?'] = 'admin/PromocodeController/index$1$2';
$route['admin/offer/add'] = 'admin/PromocodeController/add';
$route['admin/offer/edit(/:num)'] = 'admin/PromocodeController/edit$1';
$route['admin/offer/delete/(:num)'] = 'admin/PromocodeController/delete/$1';

$route['admin/Payment(/:num)?(/:any)?(/:any)?'] = 'admin/PaymentController/index$1$2$3';  
$route['admin/payment/payment-details-popup'] = 'admin/PaymentController/payment_details_popup';
$route['admin/payment/transaction-details-popup'] = 'admin/PaymentController/transaction_details_popup';
$route['admin/payment/view-chat(/:num)?(/:num)'] = 'admin/PaymentController/view_chat$1$2';

$route['admin/reports(/:num)?(/:any)?(/:any)?'] = 'admin/ReportController/index$1$2$3';
$route['admin/Report/advisor(/:num)?(/:any)?(/:any)?'] = 'admin/ReportController/advisor$1$2$3';
$route['admin/Report/customer(/:num)?(/:any)?(/:any)?'] = 'admin/ReportController/customer$1$2$3';
$route['admin/Report/revenue(/:num)?(/:any)?(/:any)?'] = 'admin/ReportController/revenue$1$2$3';

$route['admin/report/advisor/view-chat(/:num)?(/:num)'] = 'admin/PaymentController/view_chat$1$2';
$route['admin/report/customer/view-chat(/:num)?(/:num)'] = 'admin/PaymentController/view_chat$1$2';
$route['admin/report/sessions/view-chat(/:num)?(/:num)'] = 'admin/PaymentController/view_chat$1$2';
$route['admin/report/revenue/view-chat(/:num)?(/:num)'] = 'admin/PaymentController/view_chat$1$2';








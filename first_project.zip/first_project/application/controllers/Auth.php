<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Auth
 * @property Ion_auth|Ion_auth_model $ion_auth        The ION Auth spark
 * @property CI_Form_validation      $form_validation The form validation library
 */
class Auth extends CI_Controller
{
	public $data = [];

	public function __construct()
	{
        
		parent::__construct();
		$this->load->database();
		$this->load->library(['ion_auth', 'form_validation']);
		$this->load->helper(['url', 'language']);

		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

		$this->lang->load('auth');
        if(empty($this->uri->segment(1))) {
//            redirect('admin/login', 'refresh');
            redirect('/home');
        }

//        $this->pharmacy_grp = $this->config->item('roles', 'ion_auth')['pharmacy'];
	}

	/**
	 * Redirect if needed, otherwise display the user list
	 */
	public function index()
	{
//        _pre($this->session->userdata());
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
//			show_error('You must be an administrator to view this page.');
            if ($this->ion_auth->in_group('pharmacy')) {
    			show_error('You are pharmacy.');
            }
		}
		else
		{
			$this->data['title'] = $this->lang->line('index_heading');
			
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			
			//USAGE NOTE - you can do more complicated queries like this
			//$this->data['users'] = $this->ion_auth->where('field', 'value')->users()->result();
			
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'index', $this->data);
		}
	}

    public function admin_login() {
        if(!$this->ion_auth->is_admin()) {
            $this->login('admin');
        } else {
            redirect('admin');
        }
    }
    public function kitchen_login() {
        if(!$this->ion_auth->is_kitchen()) {
            $this->login('kitchen');
        } else {
            redirect('kitchen');
        }
    }

    public function pharmacy_register(){
        $request = $this->input->post();
        
    	if (isset($_POST) && !empty($_POST)){
            
            $this->db->select('t1.id');

            $this->db->from('users t1');

            $this->db->join('users_groups t2', 't1.id = t2.user_id');

            $this->db->where('t1.email', trim($request['email']));

            $this->db->where('t1.deleted_at', NULL);

            $this->db->where('t2.group_id', $this->pharmacy_grp);

            $this->db->limit(1);

            $sql_query = $this->db->get();

            if($sql_query->num_rows() > 0) {
                return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'pharmacy_register_successfully', ['message' => 'Account already created.']);
                die();
            } else {
                
                if($this->pharmacy_validation($_POST) === true) {

                    

                        $create_user = [

                            'business_name'   => (addslashes($request['business_name'])),

                            'email'           => trim($request['email']),

                            'phone'           => str_replace(["-", '-'], '', $request['phone']),

                            'dea_number'      => $request['dea_number'],

                            'first_name'      => trim($request['first_name']),

                            'last_name' 	  => trim($request['last_name']),

                            'address'    	  => (addslashes($request['address'])),

                            'city'      	  => (addslashes($request['city'])),

                            'state'     	  => (addslashes($request['state'])),

                            'zip_code'  	  => $request['zip_code'],

                        ];

                        $user_id = $this->ion_auth->register($create_user['email'], '12345678', $create_user['email'], $create_user, [$this->pharmacy_grp]);
                        if ($user_id != "" && $user_id > 0) {
                            return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'pharmacy_register_successfully', ['message' => 'Account Create Successfully']);
                            die();
                        }
                } else {

                    $this->session->set_flashdata('error', validation_errors());

                }
            }

    	}

    	$this->load->view('auth/pharmacy_register');
    }
	/**
	 * Log the user in
	 */
	public function login($role ='')
	{
		$this->data['title'] = $this->lang->line('login_heading');

		// validate form input
		$this->form_validation->set_rules('identity', str_replace(':', '', $this->lang->line('login_identity_label')), 'required');
		$this->form_validation->set_rules('password', str_replace(':', '', $this->lang->line('login_password_label')), 'required');

        $role = (empty($role)) ? $this->input->post('role') : $role;
		if ($this->form_validation->run() === TRUE)
		{
			// check to see if the user is logging in
			// check for "remember me"
			$remember = FALSE;
			if ($this->ion_auth->login($this->input->post('identity'), $this->input->post('password'), $remember, $role))
			{
				//if the login is successful
				//redirect them back to the home page
				$this->session->set_flashdata('message', $this->ion_auth->messages());
                
                if ($role == 'admin') {
                    redirect('admin');
                } else if ($role == 'pharmacy') {
                    redirect('pharmacy');
                } 
			}
			else
			{
				// if the login was un-successful
				// redirect them back to the login page
				$this->session->set_flashdata('error', $this->ion_auth->errors());
				redirect($role.'/login', 'refresh'); // use redirects instead of loading views for compatibility with MY_Controller libraries
			}
            
		}
		else
		{
			$this->load->view($role.'/pages/login', ['role' => $role]);
		}
	}
    
    

	/**
	 * Log the user out
	 */
	public function logout($user_group)
	{
		$this->data['title'] = "Logout";

		// log the user out
		$this->ion_auth->logout($user_group);

		// redirect them to the login page
        $this->session->set_flashdata('message', $this->ion_auth->messages());
		redirect($user_group.'/login', 'refresh');
	}

	/**
	 * Change password
	 */
	public function change_password($role)
	{
		$this->form_validation->set_rules('old', $this->lang->line('change_password_validation_old_password_label'), 'required');
		$this->form_validation->set_rules('new', $this->lang->line('change_password_validation_new_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[new_confirm]');
		$this->form_validation->set_rules('new_confirm', $this->lang->line('change_password_validation_new_password_confirm_label'), 'required');
        
        $role = (empty($role)) ? $this->input->post('role') : $role;
        $call_func = 'is_'.$role;
		if (!$this->ion_auth->$call_func())
		{
			redirect($role.'login', 'refresh');
		}
        
        $user_id = $this->ion_auth->get_user_id($role);
		$user = $this->ion_auth->user($user_id)->row();
        
		if ($this->form_validation->run() === FALSE)
		{
			// display the form
			// set the flash data error message if there is one
            $this->session->set_flashdata('error', (validation_errors()) ? validation_errors() : $this->session->flashdata('message'));
            $data = $this->get_change_pass_view($user);
            
            $this->_render_page($role . DIRECTORY_SEPARATOR . 'layout' . DIRECTORY_SEPARATOR. 'header', $data);
			$this->_render_page($role . DIRECTORY_SEPARATOR . 'layout' . DIRECTORY_SEPARATOR. 'sidebar', $data);
			$this->_render_page($role . DIRECTORY_SEPARATOR . 'pages' . DIRECTORY_SEPARATOR. 'change_password', $data);
			$this->_render_page($role . DIRECTORY_SEPARATOR . 'layout' . DIRECTORY_SEPARATOR. 'footer', $data);
		}
		else
		{
			$identity = $this->session->userdata()[$role]['identity'];
			$change = $this->ion_auth->change_password($identity, $this->input->post('old'), $this->input->post('new'), $user_id);
			if ($change)
			{
				//if the password was successfully changed
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				$this->logout($role);
			}
			else
			{
//				$this->session->set_flashdata('error', $this->ion_auth->errors());
//				redirect('change-password/'.$role);
				$this->session->set_flashdata('error', 'Invalid old password');
                $data = $this->get_change_pass_view($user);
            
                $this->_render_page($role . DIRECTORY_SEPARATOR . 'layout' . DIRECTORY_SEPARATOR. 'header', $data);
                $this->_render_page($role . DIRECTORY_SEPARATOR . 'layout' . DIRECTORY_SEPARATOR. 'sidebar', $data);
                $this->_render_page($role . DIRECTORY_SEPARATOR . 'pages' . DIRECTORY_SEPARATOR. 'change_password', $data);
                $this->_render_page($role . DIRECTORY_SEPARATOR . 'layout' . DIRECTORY_SEPARATOR. 'footer', $data);
			}
		}
	}
    
    function get_change_pass_view($user) {
        $this->data['min_password_length'] = $this->config->item('min_password_length', 'ion_auth');
        $this->data['old_password'] = [
            'name' => 'old',
            'id' => 'old',
            'type' => 'password',
            'class' => 'form-control',
            'required' => true
        ];
        $this->data['new_password'] = [
            'name' => 'new',
            'id' => 'new',
            'type' => 'password',
            'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
            'class' => 'form-control',
            'required' => true
        ];
        $this->data['new_password_confirm'] = [
            'name' => 'new_confirm',
            'id' => 'new_confirm',
            'type' => 'password',
            'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
            'class' => 'form-control',
            'required' => true,
            'data-parsley-equalto' => '#new',
            'data-parsley-equalto-message' => 'New password does not match with confirm password'
        ];
        $this->data['user_id'] = [
            'name' => 'user_id',
            'id' => 'user_id',
            'type' => 'hidden',
            'value' => $user->id,
        ];

        // render
        $this->data['title'] = 'Change Password';
        return $this->data;
    }
	/**
	 * Forgot password
	 */
	public function forgot_password($role = '')
	{
		$this->data['title'] = $this->lang->line('forgot_password_heading');
        
		// setting validation rules by checking whether identity is username or email
		if ($this->config->item('identity', 'ion_auth') != 'email')
		{
			$this->form_validation->set_rules('identity', $this->lang->line('forgot_password_identity_label'), 'required');
		}
		else
		{
			$this->form_validation->set_rules('identity', $this->lang->line('forgot_password_validation_email_label'), 'required|valid_email');
		}

		$role = (empty($role)) ? $this->input->post('role') : $role;
        
		if ($this->form_validation->run() === FALSE)
		{
			// set any errors and display the form
            if(validation_errors()) {
                $this->session->set_flashdata('error', validation_errors());
            } else {
                $this->session->set_flashdata('success', $this->session->flashdata('message'));
            }
            
			$this->_render_page($role. DIRECTORY_SEPARATOR . 'pages/forgot_password', ['role' => $role]);
		}
		else
		{
			$identity_column = $this->config->item('identity', 'ion_auth');
			$user_roles = $this->config->item('roles', 'ion_auth');
            $role_id = $user_roles[$role]; 
            $identity = $this->db->query('select users.* from users join users_groups on users.id = users_groups.user_id where '.$identity_column. ' = "'. $this->input->post('identity').'" AND users_groups.group_id = '.$role_id)->row();
			if (empty($identity))
			{

				if ($this->config->item('identity', 'ion_auth') != 'email')
				{
					$this->ion_auth->set_error('forgot_password_identity_not_found');
				}
				else
				{
					$this->ion_auth->set_error('forgot_password_email_not_found');
				}

				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect("forgot-password/".$role, 'refresh');
			}

			// run the forgotten password method to email an activation code to the user
			$forgotten = $this->ion_auth->forgotten_password($identity->{$this->config->item('identity', 'ion_auth')}, $identity);

			if ($forgotten)
			{
				// if there were no errors
				$this->session->set_flashdata('info', $this->ion_auth->messages());
				redirect($role."/login", 'refresh'); //we should display a confirmation page here instead of the login page
			} else {
				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect("forgot-password/".$role, 'refresh');
			}
		}
	}

	/**
	 * Reset password - final step for forgotten password
	 *
	 * @param string|null $code The reset code
	 */
	public function reset_password($code = NULL, $id = '')
	{
		if (!$code)
		{
			show_404();
		}

		$this->data['title'] = $this->lang->line('reset_password_heading');
		
		$user = $this->ion_auth->forgotten_password_check($code);
        
        $user_group = $this->db->query('select group_id from users_groups where user_id = '.$id)->row();
        $roles      = $this->config->item('roles', 'ion_auth');
        $role       = array_search($user_group->group_id, $roles);
		if ($user)
		{
			// if the code is valid then display the password reset form
			$this->form_validation->set_rules('new', $this->lang->line('reset_password_validation_new_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[new_confirm]');
			$this->form_validation->set_rules('new_confirm', $this->lang->line('reset_password_validation_new_password_confirm_label'), 'required');
			if ($this->form_validation->run() === FALSE)
			{
            
				// display the form

				// set the flash data error message if there is one
                $this->session->set_flashdata('error', (validation_errors()) ? validation_errors() : $this->session->flashdata('message'));

				$this->data['min_password_length'] = $this->config->item('min_password_length', 'ion_auth');
				$this->data['new_password'] = [
					'name' => 'new',
					'id' => 'new',
					'type' => 'password',
                    'class' => 'form-control',
                    'placeholder' => 'Enter password min 8 char long',
					'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
				];
				$this->data['new_password_confirm'] = [
					'name' => 'new_confirm',
					'id' => 'new_confirm',
					'type' => 'password',
                    'class' => 'form-control',
                    'placeholder' => 'Enter confirm password ',
					'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
				];
				$this->data['user_id'] = [
					'name' => 'user_id',
					'id' => 'user_id',
					'type' => 'hidden',
					'value' => $user->id,
				];
				$this->data['code'] = $code;
				$this->data['id'] = $id;

				// render
				$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'reset_password', $this->data);
			}
			else
			{
				$identity = $user->{$this->config->item('identity', 'ion_auth')};
				// do we have a valid request?
				if ($user->id != $this->input->post('user_id'))
				{
					// something fishy might be up
					$this->ion_auth->clear_forgotten_password_code($identity);
					show_error($this->lang->line('error_csrf'));
				}
				else
				{
					// finally change the password
					$change = $this->ion_auth->reset_password($identity, $this->input->post('new'), $id);

					if ($change)
					{
						// if the password was successfully changed
                        $this->session->set_flashdata('message', $this->ion_auth->messages());
                        if($role == 'customer' || $role == 'service_provider') {
                            return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'password_change_successfully');
                            die();
                        } 
					}
					else
					{
						$this->session->set_flashdata('message', $this->ion_auth->errors());
                        redirect('auth/reset_password/' . $code.'/'.$id, 'refresh');
					}
				}
			}
		}
		else
		{
			// if the code is invalid then send them back to the forgot password page
			$this->session->set_flashdata('message', $this->ion_auth->errors());
            if($role == 'customer' || $role == 'service_provider') {
                return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'invalid_code');
                die();
            } else {
                redirect("forgot-password/".$role, 'refresh');
            }
		}
	}

	/**
	 * Activate the user
	 *
	 * @param int         $id   The user ID
	 * @param string|bool $code The activation code
	 */
	public function activate($id, $code = FALSE)
	{
       
		$activation = FALSE;
		if ($code !== FALSE)
		{
            $activation = $this->ion_auth->activate($id, $code);
		}
		else if ($this->ion_auth->is_admin())
		{
			$activation = $this->ion_auth->activate($id);
		}
		if ($activation)
		{
			// redirect them to the auth page
			$this->session->set_flashdata('message', $this->ion_auth->messages());
//			redirect("auth", 'refresh');
            return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'account_activated',['header' => 'Account Activated Successfully', 'error' => false]);
            die();
		}
		else
		{
			// redirect them to the forgot password page
			$this->session->set_flashdata('message', $this->ion_auth->errors());
            return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'account_activated',['header' => 'Account Already Activated', 'error' => true]);
            die();
//			redirect("auth/forgot_password", 'refresh');
		}
	}

	/**
	 * Deactivate the user
	 *
	 * @param int|string|null $id The user ID
	 */
	public function deactivate($id = NULL)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			// redirect them to the home page because they must be an administrator to view this
			show_error('You must be an administrator to view this page.');
		}

		$id = (int)$id;

		$this->load->library('form_validation');
		$this->form_validation->set_rules('confirm', $this->lang->line('deactivate_validation_confirm_label'), 'required');
		$this->form_validation->set_rules('id', $this->lang->line('deactivate_validation_user_id_label'), 'required|alpha_numeric');

		if ($this->form_validation->run() === FALSE)
		{
			// insert csrf check
			$this->data['csrf'] = $this->_get_csrf_nonce();
			$this->data['user'] = $this->ion_auth->user($id)->row();

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'deactivate_user', $this->data);
		}
		else
		{
			// do we really want to deactivate?
			if ($this->input->post('confirm') == 'yes')
			{
				// do we have a valid request?
				if ($id != $this->input->post('id'))
				{
					show_error($this->lang->line('error_csrf'));
				}

				// do we have the right userlevel?
				if ($this->ion_auth->logged_in() && $this->ion_auth->is_admin())
				{
					$this->ion_auth->deactivate($id);
				}
			}

			// redirect them back to the auth page
			redirect('auth', 'refresh');
		}
	}

	/**
	 * Create a new user
	 */
	public function create_user()
	{
		$this->data['title'] = $this->lang->line('create_user_heading');

//		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
//		{
//			redirect('auth', 'refresh');
//		}

		$tables = $this->config->item('tables', 'ion_auth');
		$identity_column = $this->config->item('identity', 'ion_auth');
		$this->data['identity_column'] = $identity_column;

		// validate form input
		$this->form_validation->set_rules('first_name', $this->lang->line('create_user_validation_fname_label'), 'trim|required');
		$this->form_validation->set_rules('last_name', $this->lang->line('create_user_validation_lname_label'), 'trim|required');
		if ($identity_column !== 'email')
		{
			$this->form_validation->set_rules('identity', $this->lang->line('create_user_validation_identity_label'), 'trim|required|is_unique[' . $tables['users'] . '.' . $identity_column . ']');
			$this->form_validation->set_rules('email', $this->lang->line('create_user_validation_email_label'), 'trim|required|valid_email');
		}
		else
		{
			$this->form_validation->set_rules('email', $this->lang->line('create_user_validation_email_label'), 'trim|required|valid_email|is_unique[' . $tables['users'] . '.email]');
		}
		$this->form_validation->set_rules('phone', $this->lang->line('create_user_validation_phone_label'), 'trim');
		$this->form_validation->set_rules('company', $this->lang->line('create_user_validation_company_label'), 'trim');
		$this->form_validation->set_rules('password', $this->lang->line('create_user_validation_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[password_confirm]');
		$this->form_validation->set_rules('password_confirm', $this->lang->line('create_user_validation_password_confirm_label'), 'required');

		if ($this->form_validation->run() === TRUE)
		{
			$email = strtolower($this->input->post('email'));
			$identity = ($identity_column === 'email') ? $email : $this->input->post('identity');
			$password = $this->input->post('password');

			$additional_data = [
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'company' => $this->input->post('company'),
				'phone' => $this->input->post('phone'),
			];
		}
		if ($this->form_validation->run() === TRUE && $this->ion_auth->register($identity, $password, $email, $additional_data))
		{
			// check to see if we are creating the user
			// redirect them back to the admin page
			$this->session->set_flashdata('message', $this->ion_auth->messages());
			redirect("auth", 'refresh');
		}
		else
		{
			// display the create user form
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

			$this->data['first_name'] = [
				'name' => 'first_name',
				'id' => 'first_name',
				'type' => 'text',
				'value' => $this->form_validation->set_value('first_name'),
			];
			$this->data['last_name'] = [
				'name' => 'last_name',
				'id' => 'last_name',
				'type' => 'text',
				'value' => $this->form_validation->set_value('last_name'),
			];
			$this->data['identity'] = [
				'name' => 'identity',
				'id' => 'identity',
				'type' => 'text',
				'value' => $this->form_validation->set_value('identity'),
			];
			$this->data['email'] = [
				'name' => 'email',
				'id' => 'email',
				'type' => 'text',
				'value' => $this->form_validation->set_value('email'),
			];
			$this->data['company'] = [
				'name' => 'company',
				'id' => 'company',
				'type' => 'text',
				'value' => $this->form_validation->set_value('company'),
			];
			$this->data['phone'] = [
				'name' => 'phone',
				'id' => 'phone',
				'type' => 'text',
				'value' => $this->form_validation->set_value('phone'),
			];
			$this->data['password'] = [
				'name' => 'password',
				'id' => 'password',
				'type' => 'password',
				'value' => $this->form_validation->set_value('password'),
			];
			$this->data['password_confirm'] = [
				'name' => 'password_confirm',
				'id' => 'password_confirm',
				'type' => 'password',
				'value' => $this->form_validation->set_value('password_confirm'),
			];

			$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'create_user', $this->data);
		}
	}
	/**
	* Redirect a user checking if is admin
	*/
	public function redirectUser(){
		if ($this->ion_auth->is_admin()){
			redirect('auth', 'refresh');
		}
		redirect('/', 'refresh');
	}

	/**
	 * Edit a user
	 *
	 * @param int|string $id
	 */
	public function edit_user($id)
	{
		$this->data['title'] = $this->lang->line('edit_user_heading');

		if (!$this->ion_auth->logged_in() || (!$this->ion_auth->is_admin() && !($this->ion_auth->user()->row()->id == $id)))
		{
			redirect('auth', 'refresh');
		}

		$user = $this->ion_auth->user($id)->row();
		$groups = $this->ion_auth->groups()->result_array();
		$currentGroups = $this->ion_auth->get_users_groups($id)->result();
			
		//USAGE NOTE - you can do more complicated queries like this
		//$groups = $this->ion_auth->where(['field' => 'value'])->groups()->result_array();
	

		// validate form input
		$this->form_validation->set_rules('first_name', $this->lang->line('edit_user_validation_fname_label'), 'trim|required');
		$this->form_validation->set_rules('last_name', $this->lang->line('edit_user_validation_lname_label'), 'trim|required');
		$this->form_validation->set_rules('phone', $this->lang->line('edit_user_validation_phone_label'), 'trim');
		$this->form_validation->set_rules('company', $this->lang->line('edit_user_validation_company_label'), 'trim');

		if (isset($_POST) && !empty($_POST))
		{
			// do we have a valid request?
			if ($id != $this->input->post('id'))
			{
				show_error($this->lang->line('error_csrf'));
			}

			// update the password if it was posted
			if ($this->input->post('password'))
			{
				$this->form_validation->set_rules('password', $this->lang->line('edit_user_validation_password_label'), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[password_confirm]');
				$this->form_validation->set_rules('password_confirm', $this->lang->line('edit_user_validation_password_confirm_label'), 'required');
			}

			if ($this->form_validation->run() === TRUE)
			{
				$data = [
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'company' => $this->input->post('company'),
					'phone' => $this->input->post('phone'),
				];

				// update the password if it was posted
				if ($this->input->post('password'))
				{
					$data['password'] = $this->input->post('password');
				}

				// Only allow updating groups if user is admin
				if ($this->ion_auth->is_admin())
				{
					// Update the groups user belongs to
					$this->ion_auth->remove_from_group('', $id);
					
					$groupData = $this->input->post('groups');
					if (isset($groupData) && !empty($groupData))
					{
						foreach ($groupData as $grp)
						{
							$this->ion_auth->add_to_group($grp, $id);
						}

					}
				}

				// check to see if we are updating the user
				if ($this->ion_auth->update($user->id, $data))
				{
					// redirect them back to the admin page if admin, or to the base url if non admin
					$this->session->set_flashdata('message', $this->ion_auth->messages());
					$this->redirectUser();

				}
				else
				{
					// redirect them back to the admin page if admin, or to the base url if non admin
					$this->session->set_flashdata('message', $this->ion_auth->errors());
					$this->redirectUser();

				}

			}
		}

		// display the edit user form
		$this->data['csrf'] = $this->_get_csrf_nonce();

		// set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

		// pass the user to the view
		$this->data['user'] = $user;
		$this->data['groups'] = $groups;
		$this->data['currentGroups'] = $currentGroups;

		$this->data['first_name'] = [
			'name'  => 'first_name',
			'id'    => 'first_name',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('first_name', $user->first_name),
		];
		$this->data['last_name'] = [
			'name'  => 'last_name',
			'id'    => 'last_name',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('last_name', $user->last_name),
		];
		$this->data['company'] = [
			'name'  => 'company',
			'id'    => 'company',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('company', $user->company),
		];
		$this->data['phone'] = [
			'name'  => 'phone',
			'id'    => 'phone',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('phone', $user->phone),
		];
		$this->data['password'] = [
			'name' => 'password',
			'id'   => 'password',
			'type' => 'password'
		];
		$this->data['password_confirm'] = [
			'name' => 'password_confirm',
			'id'   => 'password_confirm',
			'type' => 'password'
		];

		$this->_render_page('auth/edit_user', $this->data);
	}

	/**
	 * Create a new group
	 */
	public function create_group()
	{
		$this->data['title'] = $this->lang->line('create_group_title');

		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}

		// validate form input
		$this->form_validation->set_rules('group_name', $this->lang->line('create_group_validation_name_label'), 'trim|required|alpha_dash');

		if ($this->form_validation->run() === TRUE)
		{
			$new_group_id = $this->ion_auth->create_group($this->input->post('group_name'), $this->input->post('description'));
			if ($new_group_id)
			{
				// check to see if we are creating the group
				// redirect them back to the admin page
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect("auth", 'refresh');
			}
			else
            		{
				$this->session->set_flashdata('message', $this->ion_auth->errors());
            		}			
		}
			
		// display the create group form
		// set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

		$this->data['group_name'] = [
			'name'  => 'group_name',
			'id'    => 'group_name',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('group_name'),
		];
		$this->data['description'] = [
			'name'  => 'description',
			'id'    => 'description',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('description'),
		];

		$this->_render_page('auth/create_group', $this->data);
		
	}

	/**
	 * Edit a group
	 *
	 * @param int|string $id
	 */
	public function edit_group($id)
	{
		// bail if no group id given
		if (!$id || empty($id))
		{
			redirect('auth', 'refresh');
		}

		$this->data['title'] = $this->lang->line('edit_group_title');

		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}

		$group = $this->ion_auth->group($id)->row();

		// validate form input
		$this->form_validation->set_rules('group_name', $this->lang->line('edit_group_validation_name_label'), 'trim|required|alpha_dash');

		if (isset($_POST) && !empty($_POST))
		{
			if ($this->form_validation->run() === TRUE)
			{
				$group_update = $this->ion_auth->update_group($id, $_POST['group_name'], array(
					'description' => $_POST['group_description']
				));

				if ($group_update)
				{
					$this->session->set_flashdata('message', $this->lang->line('edit_group_saved'));
					redirect("auth", 'refresh');
				}
				else
				{
					$this->session->set_flashdata('message', $this->ion_auth->errors());
				}				
			}
		}

		// set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

		// pass the user to the view
		$this->data['group'] = $group;

		$this->data['group_name'] = [
			'name'    => 'group_name',
			'id'      => 'group_name',
			'type'    => 'text',
			'value'   => $this->form_validation->set_value('group_name', $group->name),
		];
		if ($this->config->item('admin_group', 'ion_auth') === $group->name) {
			$this->data['group_name']['readonly'] = 'readonly';
		}
		
		$this->data['group_description'] = [
			'name'  => 'group_description',
			'id'    => 'group_description',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('group_description', $group->description),
		];

		$this->_render_page('auth' . DIRECTORY_SEPARATOR . 'edit_group', $this->data);
	}
    
    public function create_password($role, $token = '') {
        $activation_selector = substr($token,0,20);
        $check_if_already_activated = $this->db->query('select id from users where activation_selector = "'.$activation_selector.'"')->row_array();

        if(!empty($check_if_already_activated) && count($check_if_already_activated) > 0) {
            if(isset($_POST) && !empty($_POST)) {
                $request = $this->input->post();
                $validation_rule = [
                    array('field' => 'password', 'label' => 'password', 'rules' => 'trim|required|min_length[8]'),
                    array('field' => 'cpassword', 'label' => 'confirm password', 'rules' => 'trim|required|min_length[8]|matches[password]'),
                    array('field' => 'token', 'label' => 'token', 'rules' => 'trim|required')
                ];
                $this->form_validation->set_rules($validation_rule);

                if($this->form_validation->run()) {
                    $activate_vet = $this->ion_auth->activate($check_if_already_activated['id'], $request['token'], $request['password']);
                    if($activate_vet){
                        $this->session->set_flashdata('success', 'Account activated successfully.');
                        redirect($role.'/login');
                    } else {
                        $this->session->set_flashdata('error', 'Unable to set the password');
                        redirect($role.'/login');
                    }
                } else {
                    $this->session->set_flashdata('error', validation_errors());
                }
            }
            
            $data['role'] = $role;
            $data['token'] = $token;
            $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'create_password', $data);
        } else {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            return $this->_render_page('auth' . DIRECTORY_SEPARATOR . 'account_activated',['header' => 'Account Already Activated', 'error' => true]);
        }

    }

	/**
	 * @return array A CSRF key-value pair
	 */
	public function _get_csrf_nonce()
	{
		$this->load->helper('string');
		$key = random_string('alnum', 8);
		$value = random_string('alnum', 20);
		$this->session->set_flashdata('csrfkey', $key);
		$this->session->set_flashdata('csrfvalue', $value);

		return [$key => $value];
	}

	/**
	 * @return bool Whether the posted CSRF token matches
	 */
	public function _valid_csrf_nonce(){
		$csrfkey = $this->input->post($this->session->flashdata('csrfkey'));
		if ($csrfkey && $csrfkey === $this->session->flashdata('csrfvalue'))
		{
			return TRUE;
		}
			return FALSE;
	}

	/**
	 * @param string     $view
	 * @param array|null $data
	 * @param bool       $returnhtml
	 *
	 * @return mixed
	 */
	public function _render_page($view, $data = NULL, $returnhtml = FALSE)//I think this makes more sense
	{

		$viewdata = (empty($data)) ? $this->data : $data;

		$view_html = $this->load->view($view, $viewdata, $returnhtml);

		// This will return html on 3rd argument being true
		if ($returnhtml)
		{
			return $view_html;
		}
	}
    
    public function error_404() {
        $this->output->set_status_header('404'); 
        $this->load->view('auth/error_404');
    }
    
    public function pharmacy_isexists($str = NULL, $id = '') {

        $this->db->select('t1.id');

        $this->db->from('users t1');

        $this->db->join('users_groups t2', 't1.id = t2.user_id');

        $this->db->where('t1.email', trim($str));

        $this->db->where('t1.deleted_at', NULL);

        $this->db->where('t2.group_id', $this->pharmacy_grp);

        if ($id != '') {

            $this->db->where_not_in('t1.id', $id);

        }

        $this->db->limit(1);

        $sql_query = $this->db->get();
        

        if ($sql_query->num_rows() > 0){

            $this->form_validation->set_message('pharmacy_isexists', "The pharmacy email field is already exists.");

            return false;

        } else {

            return true;

        }

	}

    public function pharmacy_validation($post_array, $id = '') {

        $post_array = [

            ['field' => 'business_name', 'label' => 'business name', 'rules' => 'trim|required|max_length[50]'],

            ['field' => 'email', 'label' => 'email', 'rules' => 'trim|required|valid_email|callback_pharmacy_isexists'],

            ['field' => 'phone', 'label' => 'phone', 'rules' => 'trim|required'],

            ['field' => 'first_name', 'label' => 'first name', 'rules' => 'trim|required|max_length[50]'],

            ['field' => 'last_name', 'label' => 'last name', 'rules' => 'trim|required|max_length[50]'],

            ['field' => 'dea_number', 'label' => 'dea number', 'rules' => 'trim|required'],

            ['field' => 'zip_code', 'label' => 'zip_code', 'rules' => 'trim|regex_match[/^[a-zA-Z0-9 -]{0,10}$/]'],

            ['field' => 'address', 'label' => 'address', 'rules' => 'trim|required|max_length[100]'],

            ['field' => 'city', 'label' => 'city', 'rules' => 'trim|required|max_length[100]'],

            ['field' => 'state', 'label' => 'state', 'rules' => 'trim|required'],

        ]; 

        $this->form_validation->set_rules($post_array);

        return $this->form_validation->run();

	}
    
}

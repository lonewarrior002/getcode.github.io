<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CommonController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
	}
 
    public function change_status($table,$id) {
		$data = $this->db->get_where($table, ['id' => $id])->row();
		$status = STATUS_ACTIVE;
		$column = '';
		if($table == 'users') {
			if($data->active == STATUS_ACTIVE) {
				$status = STATUS_INACTIVE;
                send_push($id, 'users', SITENAME , 'Block By Admin', 'block_by_admin');
			} else {
                $template = file_get_contents(base_url('email_templates/account_activated.html'));
                $message  = create_email_template($template);
                $subject = $this->config->item('site_title', 'ion_auth') . ' - Account Activated' ;
                sendEmail($subject, $data->email, $message);
            }
            $column = 'active';
		} else {
			if($data->status == STATUS_ACTIVE) {
				$status = STATUS_INACTIVE;
			}	
            $column = 'status';
		}
        $this->comman->update_record($table, [$column => $status], $id);
		
		echo $status;
	}
    
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website extends CI_Controller {

	public function __construct() {
        parent::__construct();
    }

    public function index()
	{
		$data["page_name"] = "index.php";
		$this->renderWebsite('index', $data);
		// $this->load->view('website/index', $data);
	}
    public function aboutus()
	{
		$data["page_name"] = "aboutus.php";
		$data['testimonial'] = $this->db->select('t.*,users.full_name as customer_name,users.profile_picture')->from('testimonials as t')
		->join('users', 't.user_id = users.id')->where('t.deleted_at IS NULL')->limit(3)->get()->result_array();
		$this->renderWebsite('aboutus', $data);
		// $this->load->view('website/aboutus', $data);
	}
    public function our_advisor()
	{

		$advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture from users
		JOIN users_groups ON users.id = users_groups.user_id
		WHERE users_groups.group_id = '.$this->config->item('roles', 'ion_auth')['service_provider'].' AND deleted_at IS NULL ')->result_array();

		foreach ($advisors as $key => $value) {

			$availability = $this->db->select('id,category_id, user_id, type')->from('availability')->where('user_id',$value['id'])->get()->result_array();

			if(!empty($availability)){

				$row[$key] = $value;
				if($value['profile_picture'] == ''){
					$row[$key]['profile_picture'] = "assets/images/No_Image.png";
				}
				$row[$key]['categories']     = implode(',',array_unique(array_column($availability, 'category_id')));

				$row[$key]['categories_name'] = $this->db->select('name')->from('category')->where('id IN ('.$row[$key]['categories'].')')->order_by( 'FIELD (id,'.$row[$key]['categories'].')')->get()->result_array();
				$row[$key]['categories_name'] = implode(', ',array_column( $row[$key]['categories_name'], 'name'));
				$row[$key]['available_for'] = implode(',',array_unique(array_column($availability, 'type')));

				$ratings = $this->db->query('SELECT advisor_id, CASE WHEN count(id) > 0 THEN FORMAT((sum(rating)/count(id)), 2) ELSE 0 END AS avg_rating, COUNT(id) as total_rating FROM advisor_rating where advisor_id = '.$value['id'].' group by advisor_id order by avg_rating desc')->result_array();
				$row[$key]['avg_rating'] = !empty($ratings) ? $ratings[0]['avg_rating'] : "0.00";
			}
		}
		$ratings_unsorted = array_column($row, 'avg_rating');
		asort($ratings_unsorted);
		$ratings_sorted = array_values(array_reverse($ratings_unsorted, true));
		usort($row, function ($a, $b) use ($ratings_sorted) {
			$pos_a = array_search($a['avg_rating'], $ratings_sorted);
			$pos_b = array_search($b['avg_rating'], $ratings_sorted);
			return $pos_a - $pos_b;
		});
		// _pre($row);
		$data['advisors'] = $row;
		$data["page_name"] = "our_advisor.php";
		$this->renderWebsite('our_advisor', $data);
		// $this->load->view('website/our_advisor', $data);
	}

	public function advisor_details($id = ''){

		//$request = $this->post();

		$request['advisor_id'] = $id;

		$get_advisor_promocode = $this->comman->get_record_by_condition('promocode',['promocode_for' => 'advisor','status' => 1],'special_day_date,discount_value');

		// $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->where('user_id',$request['advisor_id'])->group_by('user_id')->get()->result_array();
		$availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->where('user_id',$request['advisor_id'])->group_by('user_id')->get()->result_array();
		$user_ids = array_column($availability, 'user_id');
		
		$advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description from users WHERE users.id IN ('.implode(',', $user_ids).') AND users.id = '.$request['advisor_id'].' AND active = '.STATUS_ACTIVE.' AND deleted_at IS NULL ')->row_array();
		
		if(!empty($get_advisor_promocode)) {
			$availability = $this->db->query('SELECT category_id, user_id, type, price, status, CASE WHEN "'.date('Y-m-d',strtotime(current_date())).'" = "'.date('Y-m-d',strtotime($get_advisor_promocode[0]['special_day_date'])).'" THEN TRUNCATE((price-((price*'.$get_advisor_promocode[0]['discount_value'].')/100)), 2) ELSE price END AS discount_price FROM `availability` WHERE user_id ='.$request['advisor_id'])->result_array();
		} else {
			$availability = $this->db->select('category_id, user_id, type, price, status, price as discount_price')->from('availability')->where('user_id',$request['advisor_id'])->get()->result_array();
		}
		// _pre($availability);

		$ratings = $this->db->query('SELECT advisor_id, CASE WHEN count(id) > 0 THEN FORMAT((sum(rating)/count(id)), 2) ELSE 0 END AS avg_rating, COUNT(id) as total_rating FROM advisor_rating where advisor_id = '.$request['advisor_id'].' group by advisor_id order by avg_rating desc')->result_array();

		$advisor_details['id'] = $advisors['id'];
		$advisor_details['full_name'] = $advisors['full_name'];
		$advisor_details['nick_name'] = $advisors['nick_name'];
		$advisor_details['profile_picture'] = $advisors['profile_picture'];
		$advisor_details['advisor_description'] = $advisors['advisor_description'];
		//$advisor_details['is_favourite'] = $advisors['is_favourite'];
		$advisor_details['availability'] = $availability;
		$advisor_details['categories'] = implode(',',array_unique(array_column($availability, 'category_id')));
		$advisor_details['categories_name'] = $this->db->select('id,name')->from('category')->where('id IN ('.$advisor_details['categories'].')')->order_by( 'FIELD (id,'.$advisor_details['categories'].')')->get()->result_array();
		//$advisor_details['categories_name'] = implode(', ',array_column( $advisor_details['categories_name'], 'name'));
		$type = "";
		$availible_options = array_values(array_filter($availability, function($val) use($type){
			if(!empty($type)) {
				return ($val['status'] == 1 && $val['type'] == $type);
			} else {
				return $val['status'] == 1;
			}
		}));
		$advisor_details['availabile_for'] = implode(',',array_unique(array_column($availible_options, 'type')));
		$advisor_details['availabile_for_count'] = count(array_filter(explode(',',$advisor_details['availabile_for'])));
		$advisor_details['ratings'] = 0;
		$advisor_details['avg_rating'] = !empty($ratings) ? $ratings[0]['avg_rating'] : "0.00";
		$advisor_details['total_rating'] = !empty($ratings) ? $ratings[0]['total_rating'] : "0";
		$advisor_details['is_availabile'] = (in_array(STATUS_ACTIVE, array_unique(array_column($availability, 'status')))) ? 1 : ((in_array(STATUS_BUZY, array_unique(array_column($availability, 'status')))) ? STATUS_BUZY : STATUS_INACTIVE);
		$advisor_details['review_history'] = $this->db->select('advisor_id, advisor_rating.rating, advisor_rating.note, users.full_name, users.profile_picture, advisor_rating.created_at')->from('advisor_rating')->join('users', 'advisor_rating.user_id = users.id')->where('advisor_id', $request['advisor_id'])->order_by('advisor_rating.id','desc')->limit(5)->get()->result_array();
		
		
		$ID = 5;
		$avl = array_values(array_filter($availability, function($val) use($ID){
			return $val['category_id'] == $ID;
		}));
		$data['advisor_details'] = $advisor_details;
		// _pre($data);
		// $data["page_name"] = "our_advisor.php";
		$this->renderWebsite('advisor_details', $data);
		
		// _pre($advisor_details);
		// $data['status'] = TRUE;
		// $data['advisor_details'] = $advisor_details;
	}

	public function our_advisor_coming_soon(){
		$data["page_name"] = "our_advisor.php";
		$this->renderWebsite('our_advisor_coming_soon', $data);
	}

    public function work_with_us()
	{
		$data["page_name"] = "work_with_us.php";
		$this->renderWebsite('work_with_us', $data);
		// $this->load->view('website/work_with_us', $data);
	}

	public function advisor_details1(){
		$data["page_name"] = "work_with_us.php";
		$this->renderWebsite('advisor_details1', $data);
	}


    public function contact_us()
	{
		if(isset($_POST) && !empty($_POST)){

			$request = $this->input->post();

			if($request['full_name'] != '' && $request['email'] != '' && $request['phone'] != '' && $request['subject'] != '' && $request['message'] != ''){

			// echo '<pre>';
			// print_r($_POST);exit();
                $contact_us = [

                    'full_name'   	=> $request['full_name'],

                    'email'			=> $request['email'],

                    'phone'   		=> $request['phone'],

                    'subject'   	=> $request['subject'],

                    'message'   	=> $request['message'],

                    'created_at'   	=> current_date()

                ];

                $this->comman->insert_record("contact_us", $contact_us);

                $user_details=$this->db->select('u.id,u.email,ug.group_id', false)->from('users as u')

              	->join('users_groups ug', 'u.id = ug.user_id')

				->where('u.email',$request['email'])

				->get()->row_array();

				if($user_details['group_id'] == 2){$role = "Advisor";}else{$role = "Customer";}

                $template = file_get_contents(base_url('email_templates/contact_us_request.html'));
		        $message  = create_email_template($template);
		        $message  = str_replace('##NAME##',$request['full_name'], $message);
		        $message  = str_replace('##EMAIL##',$request['email'], $message);
		        $message  = str_replace('##PHONE##',$request['phone'], $message);
//		        $message  = str_replace('##SUBJECT##',$request['subject'], $message);
		        $message  = str_replace('##MESSAGE##',$request['message'], $message);
		        $message  = str_replace('##ROLE##',$role, $message);
		        $subject = $this->config->item('site_title', 'ion_auth') . ' - Contact Us Request' ;
		        sendEmail($subject, CONTACT_EMAIL, $message);

                $this->session->set_flashdata('success', 'Request Submitted Sucessfully');

                redirect('contact-us');
			}else{
				$this->session->set_flashdata('error', 'Please Fill up all the details.');

                redirect('contact-us');
			}
		}

		$data["page_name"] = "contact_us.php";
		$this->renderWebsite('contact_us', $data);
		// $this->load->view('website/contact_us', $data);
	}

	function renderWebsite($page = null,$params = null, $return = false)
    {
        $params['body_class'] = $this->_generate_body_class();
        $this->load->view('website/header',$params);
        if($page != null){
            $this->load->view('website/'.$page,$params,$return);
        }
        $this->load->view('website/footer',$params);
    }

	public function _generate_body_class()
    {
        if($this->uri->segment_array() == null){
            $uri = array('index');
        }else{
            $uri = $this->uri->segment_array();
            if(end($uri) == 'index'){
                array_pop($uri);
            }
        }
        return implode('-', $uri);
    }

}
<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index() {
        $this->load->view('welcome_message');
    }

    public function test_mail() {
        $email = sendEmail('test subject', '5saftx7weu@privaterelay.appleid.com', 'Test Message');
        if($email){
            echo "here";
        }else{
            echo "error";
        }
    }
    
    public function test_push2() {
        //        send_push($id, 'users', 'test', 'test', '');
        $key = $this->config->item('fcm_key');
        $fcmFields = array(
            'priority' => 'high',
            'to'       => 'df_GuwW1gUr3jIij3bdP_s:APA91bHadwWZ53QJZGSr2p6KCKcEh3ADYQq7N-zx88I2NtEqnxIKw_kwIkNjM3-4SWI2AlscoyaTp_WPsfNIJJwh90yA7tw-uoBIzG2e_8x7C1HVsxU3nRSXrl_igpuhzJNWzx5tiEe-',
            'data'  => array(
                "title"     => 'custom push title',
                "body"      => 'custom push message',
                "type"      => 'custom',
            ),
        );
        $headers = array('Authorization: key=' . $key, 'Content-Type: application/json');
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');

        curl_setopt($ch, CURLOPT_POST, true);

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmFields));

        $result = curl_exec($ch);
        
        _pre($result);

        curl_close($ch);
    }

    public function test_push() {

       

        //        send_push($id, 'users', 'test', 'test', '');
        $key = $this->config->item('fcm_key');
        $fcmFields = array(
            'priority' => 'high',
            'to'       => 'fZHUcYfjA0kKv-zVKAN-Bo:APA91bHVVwW2Bv-eouiZj-QpOccNTGxBwJEbVtex0JsMI3jLsb-Stpm-CbsQdoct-K3AHfOyqBjh1H6WbvO5-uNal9IcV2rpLLJdVEQ-0z6fHvgaPu5gYWHXCg9UxbotOUdjpGtXmSXU',
            'notification'  => array(
                "title"     => 'custom push title',
                "body"      => 'custom push message',
                "type"      => 'custom',
            ),
        );
        $headers = array('Authorization: key=' . $key, 'Content-Type: application/json');
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');

        curl_setopt($ch, CURLOPT_POST, true);

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmFields));

        $result = curl_exec($ch);
        
        _pre($result);

        curl_close($ch);
    }

    public function test_voip_push(){

        // echo base_url().'assets/pushcert1.pem';exit;

        // Put your device token here (without spaces):

        if(file_exists('assets/EWWVoipProd.pem')){

        

            $deviceToken = '9e1d5c4d0d08d3c931cd4c8b7bfde252c19dc2c5d76236a06c3519fa838bc956';
            //


            // Put your private key's passphrase here:
            $passphrase = 'apple';

            // Put your alert message here:
            $message = 'My first silent push notification!';



            $ctx = stream_context_create();
            // $ctx = stream_context_create(['ssl' => [
            //     'ciphers' => 'RC4-MD5'
            // ]]);
            stream_context_set_option($ctx, 'ssl', 'local_cert', 'assets/EWWVoipProd.pem');
            stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

            // Open a connection to the APNS server
            // $fp = stream_socket_client(
            // //  'ssl://gateway.push.apple.com:2195', $err,
            // 'ssl://gateway.sandbox.push.apple.com:2195', $err,
            // $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

            $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $ctx);

            if (!$fp)
            exit("Failed to connect: $errno $errstr" . PHP_EOL);

            echo 'Connected to APNS' . PHP_EOL;

            // Create the payload body

            $body['aps'] = array(
            'content-available'=> 1,
            'alert' => $message,
            'sound' => 'default',
            'badge' => 0,
            );



            // Encode the payload as JSON

            $payload = json_encode($body);

            // Build the binary notification
            $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

            // Send it to the server
            $result = fwrite($fp, $msg, strlen($msg));
            echo $result."<br>";
            if (!$result)
            echo 'Message not delivered' . PHP_EOL;
            else
            echo 'Message successfully delivered' . PHP_EOL;

            // Close the connection to the server
            fclose($fp);
        }else{
            echo "file not exist";
        }

    }

    public function test_pdf() {
        header("Content-type: application/pdf");
        header("Content-Disposition: inline; filename=filename.pdf");
        @readfile('https://www.templebliss.co/assets/files/privacy_policy.pdf');
    }

    public function functionName() {
        //       $result = $this->db->query('SELECT users.id from users JOIN users_groups on users.id = users_groups.user_id WHERE users_groups.group_id = 2 AND ( profile_picture IS NULL OR profile_picture = "") AND users.active = 1 AND users.id != 290 AND users.id != 259 AND users.id != 261 AND change_params is NULL AND approve_advisor_detail = "1"')->result_array();

        $img_arr = ['assets/images/users/image_2021_02_25T13_45_45_375Z.png', 'assets/images/users/image_2021_02_25T13_45_33_282Z.png', 'assets/images/users/image_2021_02_25T13_45_37_093Z.png', 'assets/images/users/image_2021_02_25T13_45_41_012Z.png'];
        $row = [];
        //       $arr = array_column($result, 'id');
        //       $arr = [424,427,399,375,372,241,282,270,255,330,242];
        //       $arr = [430,398,284,251];
        $arr = [244];
        foreach ($arr as $key => $value) {
            $row[$key]['id'] = $value;
            $row[$key]['profile_picture'] = $img_arr[0];
            shuffle($img_arr);
        }
        //       _pre($row);
        $this->db->update_batch('users', $row, 'id');

        //       _pre($result);
    }

    public function fName() {
        $row[0]['id'] = 1;
        $row[0]['title'] = 'test';
        $row[0]['description'] = 'test232';

        $row[1]['id'] = 3;
        $row[1]['title'] = 'test';
        $row[1]['description'] = 'test232';

        $row[2]['id'] = 4;
        $row[2]['title'] = 'test';
        $row[2]['description'] = 'test232';

        $this->db->where('sent_by', 1);
        $this->db->update_batch('notification', $row, 'id');
    }

    public function payouts() {

        $token = $this->get_token();

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.sandbox.paypal.com/v1/payments/payouts",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
                            "sender_batch_header": {
                              "email_subject": "You have a payment",
                              "sender_batch_id": "batch-1616131024"
                            },
                            "items": [
                              {
                                "recipient_type": "EMAIL",
                                "amount": {
                                  "value": "1.00",
                                  "currency": "USD"
                                },
                                "receiver": "nirav.b@excellentwebworld.in",
                                "note": "Payouts sample transaction",
                                "sender_item_id": "item-3-1615278144737"
                              }
                            ]
                          }',
            CURLOPT_HTTPHEADER => array(
                'accept: application/json',
                'authorization: Bearer '.$token,
                'content-type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
    }

     function payment_status(){
        // Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/payments/payouts/AY65Z75JZQBJ8');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: Bearer A21AAKg2W-qrgSBmqz3pl9KZKb3tJDXxmvXhZ_AIRM-W7XJzDZ9pWCIB5I61TYmhqOpiEi98llneersBG6y2MAvgnEGIQ6eKQ';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        $response = json_decode($result,true)['items'][0]['transaction_status'];
        _pre($result);
    }
    // public function get_token() {
    //     $ch = curl_init();

    //     curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/oauth2/token');
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    //     curl_setopt($ch, CURLOPT_POST, 1);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
    //     curl_setopt($ch, CURLOPT_USERPWD, 'AdzC7nDzlWBbRKA1xsG2ZFWilLMPE1di-PhWAOAebBCbvRelSHW4P5GLvbwuBuGsg6PPUtZ2Eau_0PvE' . ':' . 'EFxCUyfSrWa1WH24UDWziLDi2L4g_bUizLyikqq1-tsARATU2SnP9bM3_4uLEEHIFYTxHzLNXDutXa-5');

    //     $headers = array();
    //     $headers[] = 'Accept: application/json';
    //     $headers[] = 'Accept-Language: en_US';
    //     $headers[] = 'Content-Type: application/x-www-form-urlencoded';
    //     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    //     $result = curl_exec($ch);
    //     if (curl_errno($ch)) {
    //         echo 'Error:' . curl_error($ch);
    //     }
    //     curl_close($ch);
        
    //     echo '<pre>';print_r(json_decode($result,true)['access_token']);
    // }


    public function get_token(){

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/oauth2/token');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_USERPWD,  'AaVriSmAxCoRw-yTbwNqGjxSCTmyx6KCsuSjHh_3Y0_b_ZM3iaXkerMxTR0jogKcsCqZvOqkHRwlr71j:EDoT4wEv0qi6D6filH8xZU2pK8kb8b2MZrCOJms_WORv3oWFKPrjmYwUi6Qef_EdHjps6rV2mQrW2emj');

        $headers = array();
        $headers[] = 'Accept: application/json';
        $headers[] = 'Accept-Language: en_US';
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        return json_decode($result,true)['access_token'];
        // echo '<pre>';print_r($result);
    } 
    
    public function voip() {
        $token = '9e1d5c4d0d08d3c931cd4c8b7bfde252c19dc2c5d76236a06c3519fa838bc956';
        if (!defined('CURL_HTTP_VERSION_2_0')) {
          define('CURL_HTTP_VERSION_2_0', 3);
        }
        // open connection 
        $http2ch = curl_init();
        curl_setopt($http2ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
        // send push
        $apple_cert = 'assets/voip12.pem';
        
        $message = '{"aps":{"action":"message","title":"your_title","body":"your_message_body"}}';
        $http2_server = 'https://api.development.push.apple.com'; // or 'api.push.apple.com' if production
        // $app_bundle_id = 'com.ecg.TempleBliss.voip';
        $app_bundle_id = 'excellentWebworld.VideoCallTwilioDemo.voip';
        $status = $this->sendHTTP2Push($http2ch, $http2_server, $apple_cert, $app_bundle_id, $message, $token);
        echo $status;
        // close connection
        curl_close($http2ch);
    }
    
    function sendHTTP2Push($http2ch, $http2_server, $apple_cert, $app_bundle_id, $message, $token) 
    {
        // url (endpoint)
        $url = "{$http2_server}/3/device/{$token}";
        $cert = realpath($apple_cert);
        if(!$cert || !is_readable($cert)){
            die("error: myfile.pem is not readable! realpath: \"{$cert}\" - working dir: \"".getcwd()."\" effective user: ".print_r(posix_getpwuid(posix_geteuid()),true));
        }
        // headers
        $headers = array(
            "apns-topic: {$app_bundle_id}",
            "User-Agent: My Sender"
        );
        curl_setopt_array($http2ch, array(
            CURLOPT_URL => $url,
            CURLOPT_PORT => 443,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POST => TRUE,
            CURLOPT_POSTFIELDS => $message,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSLCERT => $cert,
            CURLOPT_HEADER => 1
        ));
        $result = curl_exec($http2ch);
        if ($result === FALSE) {
          throw new Exception("Curl failed: " .  curl_error($http2ch));
        }
        // get response
        $status = curl_getinfo($http2ch, CURLINFO_HTTP_CODE);
        if($status=="200")
        echo "SENT|NA";
        else
        echo "FAILED|$status";
    }
    
    public function twillio_push() {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://notify.twilio.com/v1/Services/CRa76e0adae028a4f689d15718ebdf1a2e/Notifications');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_USERPWD, 'ACc68242d6ea816c0b7ab35dcf30dcd3b1:fbc4ceab996a740e9a41e540d31cbba5');

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        print_r($result);
        curl_close($ch);
    }

    public function test_sms(){
        //13474718340
        $this->twilio->send_sms('2017904726', 'TempleBliss code: 0101 , Do not share it or use it elsewhere!');
    }

    public function test_profile(){

        $profile = $this->comman->get_record_byid('profile_update_log', 260);
        // _pre($profile);
        ($profile['old_value'] != '') ? $image = "<img src='".base_url($profile['old_value'])."' style='height: 90px; object-fit: cover;'>" : $image = '-';
        ($profile['new_value'] != '') ? $image = "<img src='".base_url($profile['new_value'])."' style='height: 90px; object-fit: cover;'>" : $image = '-';
        $html = '';
        $html .= "<table class='o_block' border='1' width='100%' cellspacing='0' cellpadding='0' border='0' role='presentation' style='max-width: 632px;margin: 0 auto;background-color: #ffffff;'>
                    <tbody>
                        <tr style='color:#424651;'>
                            <th align=center style='padding: 1%;'> <b>FIELD NAME</b></td>
                            <th align=center style='padding: 1%;'><b>OLD VALUE</b></td>
                            <th align=center style='padding: 1%;'><b>NEW VALUE</b></td>
                        </tr>";
        if($profile['field_name'] == 'profile_picture'){
            $html .= "<tr>";
            $html .=  "<td align=left style='padding: 1% 1% 1% 4%;'>Advisor Description</td>";
            $html .=  "<td align=center>Test</td>";
            $html .=  "<td align=center style='padding: 1% 1% 1% 4%;'>test</td>";
            $html .=  "</tr>";
        }
        
        if($profile['field_name'] == 'profile_picture'){
            $html .= "<tr>";
            $html .=  "<td align=left style='padding: 1% 1% 1% 4%;'>Profile Picture</td>";
            $html .=  "<td align=center>".$image."</td>";
            $html .=  "<td align=center style='padding: 1% 1% 1% 4%;'>".$image."</td>";
            $html .=  "</tr>";
        }

        $html .=  "</tbody>
                </table>";

        $template = file_get_contents(base_url('email_templates/admin_approval.html'));
        $message  = create_email_template($template);
        $message  = str_replace('##TABLE##',$html, $message);
        $message = str_replace('##USERNAME##',"Nirav",$message);
        $subject = $this->config->item('site_title', 'ion_auth') . ' - Profile Approval' ;
        sendEmail($subject, "temple_bliss@mailinator.com", $message);
        
        echo $message;
    }

    

    public function send_apns()
    {

        $deviceToken = '92184de4d2a52dac78022998274a2f0373893ed3f200e89c9ce93cbb53eca662';
        //$apnsCert = 'CertificatesNew.pem';
        $apnsCert = 'assets/voip12.pem';
        //$apnsCert = 'CertificatesNew.p12';
        $passphrase = '';     


        $ctx = stream_context_create();
        stream_context_set_option($ctx, 'ssl', 'local_cert', $apnsCert);
        //stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

        // Open a connection to the APNS server
        $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

        if (!$fp)
            exit("Failed to connect: $err $errstr" . PHP_EOL);

        //echo 'Connected to APNS' . PHP_EOL;
      
        
        $body['aps'] = array(         
            'alert' => 'test push',             
            'badge' => 1,
            'sound' => 'default'
            );


        $payload = json_encode($body);
        //print_r($payload);exit;
        // Build the binary notification
        $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;


        $result = fwrite($fp, $msg);

        if (!$result)
            echo 'Message not delivered' . PHP_EOL;
        else
            echo 'Message successfully delivered' . PHP_EOL;

        fclose($fp);
    
    }

    function ios_venue_notification() {
        $deviceToken = '32155f3ba571d082302e6301d57ce3412ad7ffa15134212170e49b4bba0405a7';
        $passphrase = '';
        $ctx = stream_context_create();
        // stream_context_set_option($ctx, 'ssl', 'local_cert', 'pushcert.pem');
        // stream_context_set_option($ctx, 'ssl', 'local_cert', 'PartnetDevelopmentCertificates.pem');
        stream_context_set_option($ctx, 'ssl', 'local_cert', 'prod.pem');
        stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
        $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        //$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        if (!$fp) {
            exit("Failed to connect: $err $errstr" . PHP_EOL);
        }

        // if (!$fp) exit("Failed to connect: $err $errstr" . PHP_EOL);
        /*$body['aps'] = array(
            'alert' => 'kv test message',
            'sound' => 'default',
            'badge' => 1
        );*/

        $body['aps'] = array(
            'alert' => 'test message',
            'badge' => 1,
            'sound' => 'default',
            ); 

        $payload = json_encode($body);
        $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
        echo $result = fwrite($fp, $msg, strlen($msg));

        echo $errorResponse = @fread($fp, 6);
        if (!$result)
            echo 'Message not delivered' . PHP_EOL;
        else
            echo 'Message successfully delivered' . PHP_EOL;
        fclose($fp); 
    }

    public function test_curl(){

        $pem_file = "assets/EWWVoipProd.pem";
        $pem_secret = "apple";

        $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, 'https://api.development.push.apple.com/3/device/9e1d5c4d0d08d3c931cd4c8b7bfde252c19dc2c5d76236a06c3519fa838bc956');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, '{"aps":{"alert":"Hey, Rahul","badge":42}}');
            curl_setopt($ch, CURLOPT_SSLCERT, $pem_file);
            curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pem_secret);

            $headers = array();
            $headers[] = 'Apns-Topic: excellentWebworld.VideoCallTwilioDemo';
            $headers[] = 'Passphrase: apple';
            $headers[] = 'Apns-Priority: 10';
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch);
            echo $result;
            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            curl_close($ch);
    }

    public function test_apns($token = '')
    {
        if($token != '')
        {
            $device_token   = $token;
            $pem_file       = 'assets/TempleblissVOIP.pem';
            $pem_secret     = 'apple';
            // $apns_topic     = 'excellentWebworld.VideoCallTwilioDemo.voip';
            $apns_topic     = 'com.ecg.TempleBliss.voip';
            //,"twi_call_sid":"CAb63d5b22af1f82f135fe742911548c85","twi_bridge_token":"TempleBliss - 123","twi_message_type":"twilio.voice.call","twi_account_sid":"ACc68242d6ea816c0b7ab35dcf30dcd3b1","twi_from":"Dummy70_821","twi_to":"Ankur_928"
            $sample_alert = '{"aps":{"alert":"hiiiiii 11111","sound":"default","body":"video"},"twi_call_sid":"CAb63d5b22af1f82f135fe742911548c85","twi_bridge_token":"TempleBliss - 123","twi_message_type":"twilio.video.call","twi_account_sid":"ACc68242d6ea816c0b7ab35dcf30dcd3b1","twi_from":"Dummy70_821","twi_to":"Ankur_928"}';
            $url = "https://api.development.push.apple.com/3/device/".$device_token;

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $sample_alert);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("apns-topic: $apns_topic"));
            curl_setopt($ch, CURLOPT_SSLCERT, $pem_file);
            curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pem_secret);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            echo "<pre>";
            print_r($response);
            print_r($httpcode);
        }
        else
        {
            echo "please enter token";
        }
        
    }

    public function test_card(){
        $cvv = decrypt("WomUn6CemA==");
        echo $cvv;
    }
}

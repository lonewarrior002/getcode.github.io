<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ContactUsController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Contact Us';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'contact_us';
	}

	public function index() {

	 	$data['title'] = $this->title;

		$this->load->library('Datatables');

		$rating = new Datatables;

		$rating->select('*', false)->from('contact_us');

				 // ->where('advisor_rating.deleted_at',NULL);
       
		$action['delete'] = base_url('admin/rating-review/delete/');
 
        $rating

        	->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Type', 'user_id', function($user_id) {
                return $user_id != 0 ? "Application" : "Website";
            })

			->column('Name', 'full_name')

            ->column('Email', 'email')

            ->column('Phone', 'phone')
                                                            
            ->column('Craeted On', 'created_at', function ($created_at) {

                return __date($created_at);

            })

            ->column('Action', 'id', function ($id) use ($action) {

				$option = '<a href="javascript:void(0);" data-id="'.$id.'" class="on-default contact_us_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Details" data-original-title = "View Details" ><i class="la la-eye"></i></a>';

				return $option;

            });


            $rating->set_options(["columnDefs" => "[ { targets: [6], sortable: false}]"]);

            $rating->searchable('full_name, email, phone');
            
            $rating->datatable($this->table_name);


            $rating->init();


			$data['datatable'] = true;


			$data['export'] = true;


			$data['export_columns'] = [0,1,2,3,4,5];


        	$data['title'] = $this->title;


        	$data['export_title'] = $this->title;


			$this->renderAdmin('contact_us/index', $data);
	}

	public function contact_us_popup(){

		$id = intval($this->input->post('id'));

		if($id) {
            $data['contact_us_details'] = $this->db->select('*')->from('contact_us')

                                    ->where('id', $id)

                                    ->get()->row_array();
        } else {
            $data['contact_us_details'] = [];
        }

        echo json_encode(['view' => $this->load->view('admin/pages/contact_us/contact_us_view', $data)]);
	}

}
<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class PromocodeController extends MY_Controller {

	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Offers';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'promocode';
	}

	public function index($filter_1 = '',$filter_2 = '') {

		$data['title'] = $this->title;

		$this->load->library('Datatables');

		$promocode = new Datatables;

        if($filter_1 == 'customer' && ($filter_2 == 'first_time' || $filter_2 == 'birthday')){
            $where = 'promocode_for = "'.$filter_1.'" AND promocode_type = "'.$filter_2.'"';
            $data['filter_1'] = $filter_1;$data['filter_2'] = $filter_2;
        }else if($filter_1 == 'advisor'){
            $where = 'promocode_for = "'.$filter_1.'"';
            $data['filter_1'] = $filter_1;  $data['filter_2'] = "";
        }else{$where = '1=1';
            $data['filter_1'] = "";  $data['filter_2'] = "";
        }

		$promocode->select('*', false)->from('promocode')->where('deleted_at',null)->where($where);

		$action['edit'] = base_url('admin/offer/edit/');
       
		$action['delete'] = base_url('admin/offer/delete/');

		$promocode

        	->style(['class' => 'table table-striped table-bordered nowrap'])

			->column('#', 'id')

			->column('Offer Code', 'promocode')

			->column('Offer For', 'promocode_for',function($promocode_for){

                $promocode_for = ($promocode_for == 'customer') ? "Customer" : "Advisor";

                return $promocode_for;

            })

			->column('Offer Title', 'discount_type',function($discount_type,$row){

                if($row['promocode_for'] == 'customer'){

                    $type = ($row['promocode_type'] == 'first_time') ? "First Time" : "Birthday";
                }else{
//                    $type = ($row['discount_type'] == 'flat') ? "Flat" : "Percentage";
                    $type = "Special Day";
                }
                
                return $type;

            })
            
			->column('Offer Type', 'discount_type',function($discount_type,$row){

                if( ($row['promocode_for'] == 'customer' && $row['promocode_type'] == 'birthday') || $row['promocode_for'] == 'advisor'){

                    return $discount_type;
                }
                return '-';

            })

			->column('Offer Value', 'discount_value',function($discount_value,$row){
                if($row['promocode_type'] == 'first_time'){
                    $value = "-";
                }else{
                    $value = $discount_value;
                }

                return $value;
            })

            ->column('Status', 'status',function($status, $row){

            	if ($status == 1) {

					return '<h5 class="mb-0 mt-0"><span onclick="change_promocode_state(this);" class="badge badge-success cursor-pointer font-15 status_' . $row['id'] . '" data-table="promocode" data-id="' . $row['id'] . '" data-promocode_for = '.$row['promocode_for'].' data-type = "'.$row['promocode_type'].'"  data-status = '.$status.'>Active</span></h5>';

				} else {

					return '<h5 class="mb-0 mt-0"><span onclick="change_promocode_state(this);" class="badge badge-danger cursor-pointer font-15 status_' . $row['id'] . '" data-table="promocode" data-id="' . $row['id'] . '" data-promocode_for = '.$row['promocode_for'].' data-type = "'.$row['promocode_type'].'"  data-status = '.$status.'>Inactive</span></h5>';

                }

            })

            ->column('Actions', 'id', function ($id) use ($action) {

            	$option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="Edit" data-original-title = "Edit"><i class="la la-pencil-square "></i></a>';

				$option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_confirm(this);"  class="on-default text-danger confirm_model" data-toggle="tooltip" data-placement="bottom" title="Delete" data-original-title = "Delete" data-rediret-url="'.current_url().'"  data-table="'.$this->table_name.'" data-href="faq"><i class="la la-times-circle"></i></a>';

				return $option;

            });

            $promocode->set_options(["columnDefs" => "[ { targets: [6,7], sortable: false}]"]);

            $promocode->searchable('promocode,promocode_for,discount_type,promocode_type');

            $promocode->datatable($this->table_name);

            $promocode->init();

			$data['datatable'] = true;

			$data['export'] = true;

			$data['export_columns'] = [0,1,2,3,4,5,6];

			$data['add_url'] = base_url('admin/offer/add');

        	$data['title'] = $this->title;

        	$data['export_title'] = $this->title;

            $data['filter_record'] = '';

			$this->renderAdmin('promocode/index', $data);
	}

	public function add(){

		$current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

        	$request = $this->input->post();

        	$data['promocode_for'] = $request['promocode_for'];

        	if($request['promocode_for'] == 'customer'){

        	    $data['promocode'] = $request['promocode_customer'];
                if($request['type_customer'] == 'first_time'){

                    $data['promocode_type'] = $request['type_customer'];
            		$data['min_minute'] = $request['min_minute'];
            		$data['free_minute'] = $request['free_minute'];

                }else{

                    $data['promocode_type'] = $request['type_customer'];
        	        $data['discount_value'] = $request['discount_value_customer'];
                    $data['discount_type'] = $request['discount_type_customer'];
                }
        	}else{

                $data['promocode'] = $request['promocode_advisor'];
                $data['special_day_date'] = $request['special_day_date'];
                $data['discount_type'] = 'percentage';
                $data['discount_value'] = $request['discount_value_advisor'];

            }

        	$data['created_at'] = $current_date;

        	$this->comman->insert_record($this->table_name, $data);

            $this->session->set_flashdata('success', 'Promocode added sucessfully');

            redirect('admin/offers');
        }

		$data['title'] = 'Add '.$this->title;

        $this->renderAdmin('promocode/add',$data);

	}

	public function edit($id){

		$current_date = current_date();

		if (isset($_POST) && !empty($_POST)) {

			$request = $this->input->post();

        	$update_data['promocode_for'] = $request['promocode_for'];

        	if($request['promocode_for'] == 'customer'){

			    $update_data['promocode'] = $request['promocode_customer'];
                if($request['type_customer'] == 'first_time'){
                    $update_data['min_minute'] = $request['min_minute'];
                    $update_data['free_minute'] = $request['free_minute'];
                    $update_data['discount_type'] = NULL;
                    $update_data['discount_value'] = NULL;
//                    $update_data['status'] = 0;
                }else{
                    $update_data['min_minute'] = NULL;
                    $update_data['free_minute'] = NULL;
    		        $update_data['discount_type'] = $request['discount_type_customer'];
        	        $update_data['discount_value'] = $request['discount_value_customer'];
                }
                $update_data['promocode_type'] = $request['type_customer'];
        		$update_data['special_day_date'] = NULL;
        	}
        	if($request['promocode_for'] == 'advisor'){
                $update_data['promocode_type'] = NULL;
                $update_data['promocode'] = $request['promocode_advisor'];
        		$update_data['min_minute'] = NULL;
        		$update_data['free_minute'] = NULL;
        		$update_data['discount_type'] = 'percentage';
                $update_data['discount_value'] = $request['discount_value_advisor'];
        		$update_data['special_day_date'] = $request['special_day_date'];
        	}

        	$update_data['updated_at'] = $current_date;
            
        	$this->comman->update_record_by_condition($this->table_name, $update_data, ['id' => $id]);

            $this->session->set_flashdata('success', 'Promocode updated sucessfully');

            redirect('admin/offers');
		}

		$data['title'] = 'Edit '.$this->title;

		$data['promocode_detail'] = $this->comman->get_record_byid($this->table_name, $id);

		$this->renderAdmin('promocode/edit',$data);

	}

	public function delete($id) {

        $current_date = current_date();

        $this->db->delete($this->table_name, array('id' => $id));

        echo 1;

    }

    public function change_status(){

        $request = $this->input->post();

        if($request['promocode_for'] == 'customer' && ($request['type'] == 'first_time' || $request['type'] == 'birthday') && $request['status'] == 0){
            // $result = $this->db->select('id')->from('promocode')->where('promocode_type = "first_time" AND status = 1 AND deleted_at IS NOT NULL')->num_rows();
            $result = $this->db->get_where('promocode','promocode_type = "'.$request['type'].'" AND status = 1 AND deleted_at IS NULL')->num_rows();
            if($result > 0){ $status = false;}else{$status = true;}
        }else if($request['promocode_for'] == 'customer' && ($request['type'] == 'first_time' || $request['type'] == 'birthday') && $request['status'] == 1){
            $status = true;
        }else if($request['promocode_for'] == 'advisor' && $request['status'] == 0){
            $advisor_result = $this->db->get_where('promocode','promocode_for = "advisor" AND status = 1 AND deleted_at IS NULL')->num_rows();
            if($advisor_result > 0){$status = false;}else{$status = true;}
        }else{
            $status = true;
        }

        if($status == true){
            if($request['status'] == 1){$update_data = ['status' => 0];}else{$update_data = ['status' => 1];}
            $this->comman->update_record_by_condition('promocode', $update_data, ['id' => $request['id']] );
        }
        echo json_encode(['status' => $status, 'promocode_status' => $request['status']]);

    }

}
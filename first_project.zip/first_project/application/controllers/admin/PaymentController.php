<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PaymentController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Payment Management';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'booking_request';
	}

    public function index($filter = '',$filter1 = '',$filter2 = '') {

        $this->load->library('Datatables');

        if($filter == '1' || $filter == 1 && $filter1 != '' && $filter2 != ''){
        	$From = $filter1." 00:00:00";
        	$To = $filter2." 23:59:59";
        	$where = 'paypal_transaction_log.created_at BETWEEN "'.$From.'" AND "'.$To.'"';
        	$data['from'] = $filter1; $data['to'] = $filter2;
        	$data['category_filter'] = '';
            $data['payout_status_filter'] = '';
        	$data['filter'] = 1; 
        }else if($filter == '2'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'category.id = "'.$filter1.'"';
            }
        	$data['from'] = ''; $data['to'] = ''; 
        	$data['category_filter'] = $filter1;
            $data['payout_status_filter'] = '';
        	$data['filter'] = 2;
        }else if($filter == '3'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'paypal_transaction_log.status = "'.$filter1.'"';
            }
        	$data['from'] = ''; $data['to'] = ''; 
        	$data['payout_status_filter'] = $filter1;
            $data['category_filter'] = '';
        	$data['filter'] = 3;
        }
        else{
        	$where = "1=1";
        	$data['filter'] = 0;
        	$data['from'] = ''; $data['to'] = ''; 
        	$data['category_filter'] = '';
            $data['payout_status_filter'] = '';
        }

        // _pre($where);withdrawal_log.batch_id,withdrawal_log.id as withdrawal_id,
        $payment = new Datatables;

		$payment->select('u.id as advisor_id, u.full_name as advisor_name, c.id as customer_id,c.full_name as customer_name,b.id,b.total,b.advisor_commission,b.created_at,paypal_transaction_log.payout_item_id,paypal_transaction_log.created_at as withdrawal_date', false)->from($this->table_name.' b')

                ->join('users u', 'u.id = b.advisor_id')

                ->join('users c', 'c.id = b.user_id')

                ->join('category', 'b.category_id = category.id')

                //->join('withdrawal_log ','withdrawal_log.user_id = b.advisor_id AND FIND_IN_SET(b.id,withdrawal_log.booking_ids)')

                ->join('paypal_transaction_log ','paypal_transaction_log.user_id = b.advisor_id AND FIND_IN_SET(b.id,paypal_transaction_log.booking_id) AND paypal_transaction_log.status != 2 AND paypal_transaction_log.status != 3')

                ->where('b.end_time IS NOT NULL')

                ->where('b.status',1)

                ->where('is_session_running',1)

                ->where($where);
                // ->group_start()
                //     ->where('pul.user_id','u.id')
                // ->group_end();


		$action['edit'] = base_url('admin/payment/edit/');

		$action['delete'] = base_url('admin/payment/delete/');

		$payment

			->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

            ->column('#', 'id')
            
            ->column('Item Id', 'payout_item_id', function ($batch_id, $row){
                return '<a href="javascript:void(0);" title="Transaction Details" class="transaction_details_modal" data-advisor_id="'.$row['advisor_id'].'" data-booking_id="'.$row['id'].'" data-batch_id="'.$row['payout_item_id'].'"><span class="badge badge-pill badge-secondary">'.$batch_id.'</span></a>';
            })

			->column('Advisor Name', 'advisor_name')
                                                        
			->column('Customer Name', 'customer_name')

			->column('Amount', 'advisor_commission')

            ->column('Created On', 'withdrawal_date', function ($created_on) {

                return __date(strtotime( $created_on), true);

            })

			->column('Action', 'id', function ($id, $row) {


        $option = '<a href="javascript:void(0);" data-booking_id="'.$id.'" data-advisor_id="'.$row['advisor_id'].'" class="on-default payment_details_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Session Details" data-original-title="View payment details"><i class="la la-eye"></i></a>';

				return $option;

			});

        $payment->set_options(["columnDefs" => "[ { targets: [0], sortable: false}]", "order" => '[ 5, "desc" ]',"lengthMenu" => "[ [10, 25, 50,100, -1], [10, 25, 50,100,'All'] ]"]);

        $payment->searchable('u.full_name,c.full_name,b.id,paypal_transaction_log.payout_item_id,b.id');

		$payment->datatable($this->table_name);

		$payment->init();

		$data['datatable'] = true;

        $data['export'] = true;

		$data['export_columns'] = [0,1,2,3,4,5];

        $data['export_title'] = $this->title;

        $data['title'] = $this->title;

        $data['category'] = $this->db->select('name,id')->from('category')->where('deleted_at Is NULL AND status = 1')->get()->result_array();

		$this->renderAdmin('payment/index', $data);
    }

    public function payment_details_popup(){
        $booking_id = $this->input->post('booking_id');
        //$advisor_id = $this->input->post('advisor_id');
        $page = $this->input->post('page');
        if($page == 'customer'){$data['link'] = "admin/report/customer/";}
        else if ($page == 'advisor'){$data['link'] = "admin/report/advisor/";}
        else if ($page == 'session'){$data['link'] = "admin/report/sessions/";}
        else if ($page == 'revenue'){$data['link'] = "admin/report/revenue/";}
        else{$data['link'] = "admin/payment/";}
        $data['booking_details'] = $this->db->select('users.id as advisor_id,users.full_name as advisor_name,customer.id as customer_id,customer.full_name as customer_name,booking_request.*,withdrawal_log.batch_id,category.name as category_name,call_history.reject_by')
        ->from('booking_request')
        ->join('users','booking_request.advisor_id = users.id','left')
        ->join('users as customer','booking_request.user_id = customer.id','left')
        ->join('withdrawal_log ','withdrawal_log.user_id = users.id AND FIND_IN_SET("'.$booking_id.'",withdrawal_log.booking_ids)','left') 
        ->join('category ','booking_request.category_id = category.id','left')
        ->join('call_history','booking_request.id = call_history.booking_id','left')
        ->where('booking_request.id',$booking_id)
        // ->group_start()
        //     ->group_start()
        //         ->where('booking_request.status','1')
        //         ->where('booking_request.id',$booking_id)
        //     ->group_end()
        //     ->or_group_start()
        //         ->where('booking_request.status','2')
        //         ->where('booking_request.id',$booking_id)
        //         ->or_where('call_history.booking_id',$booking_id)
        //     ->group_end()
        // ->group_end()
        ->get()->row_array();

        if($data['booking_details']['offer_id'] != ''){
            $data['promocode'] =$this->db->query('SELECT `promocode` FROM `promocode` WHERE `id` IN('.$data['booking_details']['offer_id'].')')->result_array();
        }

        echo json_encode(['view' => $this->load->view('admin/pages/payment/payment_details_popup', $data)]);

        // _pre($booking_details);
    }

    public function transaction_details_popup(){
         // this function is updated at 10-05-2021 
        $item_id = $this->input->post('batch_id');
        $advisor_id = $this->input->post('advisor_id');
        $email = $this->db->select('account_detail')->from('advisor_payment_detail')->where('user_id',$advisor_id)->get()->row_array();
       // $details = $this->db->select('*')->from('withdrawal_log')->where('batch_id',$batch_id)->where('user_id',$advisor_id)->get()->row_array();
        $paypal_details = $this->db->select('*')->from('paypal_transaction_log')->where('payout_item_id',$item_id)->where('user_id',$advisor_id)->get()->row_array();
        //$items = json_decode($details['success_response'],true)['items'];
        //$data['success_response'] = json_decode($details['success_response'],true)['batch_header'];
        $data['transaction'] = [];
        $data['items'] = [];
        // foreach($items as $key => $value){
           
        //     if($email['account_detail'] == $value['payout_item']['receiver']){
                
        //         $data['items'] = $value;
        //         if($details['token'] != '' && $details['token'] != NULL){
        //             $data['transaction'] = json_decode(payout_item_details($value['payout_item_id'],$details['token']),true);
        //         }
        //     }
        // }
        $token = get_token();
        $data['transaction'] = json_decode(payout_item_details($item_id,$token),true);
        //_pre($data['transaction']);
        echo json_encode(['view' => $this->load->view('admin/pages/payment/transaction_details_popup', $data)]);
        
        
    }

    public function get_transaction_details($batch_id,$advisor_id){
        //$batch_id = $this->input->post('batch_id');
        //$advisor_id = $this->input->post('advisor_id');
        $email = $this->db->select('account_detail')->from('advisor_payment_detail')->where('user_id',$advisor_id)->get()->row_array();
        $details = $this->db->select('*')->from('withdrawal_log')->where('batch_id',$batch_id)->where('user_id',$advisor_id)->get()->row_array();
        $items = json_decode($details['success_response'],true)['items'];
        $data['success_response'] = json_decode($details['success_response'],true)['batch_header'];
        $data['transaction'] = [];
        $data['items'] = [];
        foreach($items as $key => $value){
           
            if($email['account_detail'] == $value['payout_item']['receiver']){
                
                $data['items'] = $value;
                if($details['token'] != '' && $details['token'] != NULL){
                    $data['transaction'] = json_decode(payout_item_details($value['payout_item_id'],$details['token']),true);
                }
            }
        }
        $data['transaction'] = json_decode(payout_item_details($value['payout_item_id'],$details['token']),true);
        _pre($data);
    }

    public function view_chat($advisor_id,$customer_id){
        $data['title'] = "Chat";
        $from = date("Y-m-d",strtotime("-2 month"))." 00:00:00";
        $to = date("Y-m-d")." 23:59:59";
        $data['chat'] = $this->db->select('*')->from('chat_history')
                ->where('sender_id IN('.$advisor_id.','.$customer_id.')')
                ->where('receiver_id IN('.$advisor_id.','.$customer_id.')')
                ->where('created_at BETWEEN "'.$from.'" AND "'.$to.'"')
                ->get()->result_array();

        // _pre($this->db->last_query());
        $data['customer'] = $this->db->select('full_name,profile_picture')->from('users')->where('id',$customer_id)->get()->row_array();
        $data['advisor'] = $this->db->select('full_name,profile_picture')->from('users')->where('id',$advisor_id)->get()->row_array();
        $this->renderAdmin('payment/view_chat',$data);
    }
    
    public function reports() {
        $this->load->library('Datatables');

        $report = new Datatables;

		$report->select('u.id as advisor_id, u.full_name as advisor_name, c.id as customer_id,c.full_name as customer_name,b.id,b.total,b.created_at', false)->from($this->table_name.' b')

                ->join('users u', 'u.id = b.advisor_id')

                ->join('users c', 'c.id = b.user_id')

                ->where('b.end_time IS NOT NULL');

		$report

			->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Advisor Name', 'advisor_name')
                                                        
			->column('Customer Name', 'customer_name')

			->column('Amount', 'total')

            ->column('Created On', 'created_at', function ($created_on) {

                return __date(strtotime( $created_on), true);

            })
            ->column('Status', 'active', function($active, $row) {

                if ($active == 1) {
                    return '<h5 class="mb-0 mt-0"><span onclick="fun_change_state(this);" class="badge badge-success cursor-pointer font-15 status_' . $row['id'] . '" data-table="users" data-id="' . $row['id'] . '">Active</span></h5>';

                } else {
                   return '<h5 class="mb-0 mt-0"><span onclick="fun_change_state(this);" class="badge badge-danger cursor-pointer font-15 status_' . $row['id'] . '" data-table="users" data-id="' . $row['id'] . '">Inactive</span></h5>';

                }

            });

			

        $report->set_options(["columnDefs" => "[ { targets: [5], sortable: false}]"]);

        $report->searchable('advisor_name, customer_name');

		$report->datatable($this->table_name);

		$report->init();

		$data['datatable'] = true;

        $data['export'] = true;

		$data['export_columns'] = [0,1,2,3,4];

        $data['export_title'] = $this->title;

        $data['title'] = 'Reports';
        
        $this->renderAdmin('payment/report', $data);
    }
}
    
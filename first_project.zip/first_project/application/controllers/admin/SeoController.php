<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SeoController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'SEO';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'seo';
	}

    public function index() {
        $data['title'] = $this->title;
        $data['records'] = $this->comman->get_all_record($this->table_name);
        if($_POST) {
            $request = $this->input->post();
            $status = true;
            if(empty($request['page_name'])) {
                $this->session->set_flashdata('error', 'Please select page');
                $status = false;
            }
            if($status){
                $seo_settings[] = [ 'attr' => 'meta_title', 'content' => $request['meta_title'] ];
                $seo_settings[] = [ 'attr' => 'meta_description', 'content' => $request['meta_description'] ];
                $seo_settings[] = [ 'attr' => 'meta_keyword', 'content' => $request['meta_keyword'] ];
                $seo_settings[] = [ 'attr' => 'og_title', 'content' => $request['og_title'] ];
                $seo_settings[] = [ 'attr' => 'og_meta_description', 'content' => $request['og_meta_description'] ];

                if($request['remove_image_field']) {
                    $seo_settings[] = [ 'attr' => 'og_image', 'content' => '' ];
                    $page_name = $request['page_name'];
                    $record = array_values(array_filter($data['records'], function($val) use($page_name){
                        return $val['page'] == $page_name && $val['attr'] == 'og_image';
                    }));
                    
                    @unlink(FCPATH.$record[0]['content']);
                }
                if(file_exists($_FILES['og_image']['tmp_name']) || is_uploaded_file($_FILES['og_image']['tmp_name'])) {

                    $image_is_uploaded = image_upload('og_image', 'images/seo/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG');

                    if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                        $seo_settings[] = [ 'attr' => 'og_image', 'content' => $image_is_uploaded['uploaded_path'] ];

                        $status = true;

                    } else if( isset($image_is_uploaded['error']) ) {

                        $status  = false;

                        $this->session->set_flashdata('error', ucfirst($image_is_uploaded['error']));

                    }

                } 


                if($status){

                    $this->db->where('page',$request['page_name'])->update_batch($this->table_name, $seo_settings, 'attr');

                    $this->session->set_flashdata('success', 'Record save successfully');

                    redirect('admin/seo');
                }
            }

            
        }
        
        $this->renderAdmin('setting/seo', $data);
    }
    
    public function get_seo_detail() {
        $seo_detail = $this->comman->get_record_by_condition($this->table_name,['page' => $this->input->post('page')], 'attr, content');
        echo json_encode($seo_detail);
    }
}
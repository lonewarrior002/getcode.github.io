<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CategoryController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Categories';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'category';
	}

    public function index() {

	 	$data['title'] = $this->title;

        //print_r($_SESSION);die();

		//$this->renderPharmacy('coming_soon', $data);

		$this->load->library('Datatables');

		$category = new Datatables;

		$category->select('*', false)->from('category')->where('deleted_at', null);

        $action['edit'] = base_url('admin/category/edit/');

		$action['delete'] = base_url('admin/category/delete/');
 
        $category

        	->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Name', 'name')

			->column('Image', 'image', function($category, $row) {
                if(!is_null($category)) {
                    return '<a data-lightbox="order_img_'.$row['id'].'" href="'.base_url($category).'" title="Preview Image"><img src="'.base_url($category).'" alt="no image" class="border border-secondary" style="height: 36px; width: 36px; object-fit: cover;"></a>';
                } 
                return '-';
            })

            ->column('Description', 'description')

            ->column('Status', 'status',function($status, $row){

            	if ($status == 1) {

					return '<h5 class="mb-0 mt-0"><span onclick="fun_change_state(this);" class="badge badge-success cursor-pointer font-15 status_' . $row['id'] . '" data-table="category" data-id="' . $row['id'] . '">Active</span></h5>';

				} else {


					return '<h5 class="mb-0 mt-0"><span onclick="fun_change_state(this);" class="badge badge-danger cursor-pointer font-15 status_' . $row['id'] . '" data-table="category" data-id="' . $row['id'] . '">Inactive</span></h5>';

                }

            })

            ->column('Actions', 'id', function ($id) use ($action) {

            	// $option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="" data-original-title = "Edit Field"><i class="la la-pencil-square "></i></a>';

                $option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="Edit" data-original-title = "Edit"><i class="la la-pencil-square "></i></a>';

				$option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_confirm(this);"  class="on-default text-danger confirm_model" data-toggle="tooltip" data-placement="bottom" title="Delete" data-original-title = "Delete Field" data-rediret-url="'.current_url().'"  data-table="'.$this->table_name.'" data-href="categoty"><i class="la la-times-circle"></i></a>';

				return $option;

            });


        $category->set_options(["columnDefs" => "[ { targets: [1,2,4,5], sortable: false}]"]);
        
        $category->searchable('name');


        $category->datatable($this->table_name);


        $category->init();


        $data['datatable'] = true;


        $data['export'] = true;


        $data['export_columns'] = [0,1,3,4];


        $data['add_url'] = base_url('admin/category/add');


        $data['title'] = $this->title;


        $data['export_title'] = $this->title;


        $this->renderAdmin('category/index', $data);
	}

	public function add(){

		$current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

            if($this->category_validation($_POST) === true) {

                $request = $this->input->post();

                $create_category = [
                    'name'   => $request['name'],

                    'description'   => $request['description'],

                    'created_at'   => $current_date

                ];
                if(file_exists($_FILES['image']['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name'])) {

                    $image_is_uploaded = image_upload('image', 'images/category/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG');

                    if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                        $create_category['image'] = $image_is_uploaded['uploaded_path'];

                        $status = true;

                    } else if( isset($image_is_uploaded['error']) ) {

                        $status  = false;

                        $this->session->set_flashdata('error', ucfirst($image_is_uploaded['error']));

                        redirect('admin/category/add');
                        
                    }

                } 
                
                if($status){
                    $arr[] = ['type' => 'chat', 'from' => $request['chat_from'], 'to' => $request['chat_to']];
                    $arr[] = ['type' => 'audio', 'from' => $request['audio_from'], 'to' => $request['audio_to']];
                    $arr[] = ['type' => 'video', 'from' => $request['video_from'], 'to' => $request['video_to']];

                    $create_category['price_range'] = json_encode($arr);
                    $create_category['default_min_price'] = $request['default_min_price'];
                    
                    $this->comman->insert_record($this->table_name, $create_category);

                    $this->session->set_flashdata('success', 'Category added sucessfully');

                    redirect('admin/category');
                }

            }

            else

            {

            	$this->session->set_flashdata('error', (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message'))));

            }
        }

        $data['title'] = 'Add '.$this->title;

        $this->renderAdmin('category/add',$data);
	}

    public function edit($id = ''){

        $category = $this->comman->get_record_byid('category',$id);
        
        $current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

            if($this->category_validation($_POST) === true) {

                $request = $this->input->post();

                $create_category = [

                    'name'   => $request['name'],

                    'description'   => $request['description'],

                    'updated_at'   => $current_date

                ];

                if(file_exists($_FILES['image']['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name'])) {

                    $image_is_uploaded = image_upload('image', 'images/category/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG');

                    if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                        $create_category['image'] = $image_is_uploaded['uploaded_path'];

                    } else if( isset($image_is_uploaded['error']) ) {

                        $status  = false;

                        $message = $image_is_uploaded['error'];

                    }

                }
                $arr[] = ['type' => 'chat', 'from' => $request['chat_from'], 'to' => $request['chat_to']];
                $arr[] = ['type' => 'audio', 'from' => $request['audio_from'], 'to' => $request['audio_to']];
                $arr[] = ['type' => 'video', 'from' => $request['video_from'], 'to' => $request['video_to']];
                
                $create_category['price_range'] = json_encode($arr);
                $create_category['default_min_price'] = $request['default_min_price'];

                $this->comman->update_record($this->table_name, $create_category,$id);

                $this->session->set_flashdata('success', 'Category edited sucessfully');

                redirect('admin/category');

            }

            else

            {

                $this->session->set_flashdata('error', (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message'))));

            // echo "here";
            }
        }else{
            $data['title'] = 'Edit '.$this->title;

            $data['category'] = $category;

            $this->renderAdmin('category/edit',$data);

        }

        
    }
    
    public function delete($id) {
        $this->comman->update_record($this->table_name, ['deleted_at' => current_date()], $id);
        echo 1;
    }

	function category_validation($post_array, $id = '') {


        $post_array = [


            ['field' => 'name', 'label' => 'category name', 'rules' => 'trim|required'],

            ['field' => 'description', 'label' => 'category description', 'rules' => 'trim|required'],

            //['field' => 'image', 'label' => 'image', 'rules' => 'required']

        ];

        $this->form_validation->set_rules($post_array);

        return $this->form_validation->run();

	}
}
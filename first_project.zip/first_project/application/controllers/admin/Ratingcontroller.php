<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RatingController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Rating & Review';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'advisor_rating';
	}

	public function index() {

	 	$data['title'] = $this->title;

        //print_r($_SESSION);die();

		//$this->renderPharmacy('coming_soon', $data);

		$this->load->library('Datatables');

		$rating = new Datatables;

		$rating->select('advisor_rating.*,customer.full_name,advisor.full_name as advisor_name', false)->from('advisor_rating')

				 ->join('users as customer','users.id = advisor_rating.user_id')
				 
				 ->join('users as advisor','users.id = advisor_rating.advisor_id');
       
		$action['delete'] = base_url('admin/rating/delete/');
 
        $rating

        	->style(['class' => 'table table-striped table-bordered nowrap'])

			->column('#', 'id')

			->column('Customer Name', 'full_name')

            ->column('Advisor Name', 'advisor_name')

            ->column('Rating', 'rating')

            ->column('Review', 'note')

            ->column('Actions', 'id', function ($id) use ($action) {

				$option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_confirm(this);"  class="on-default text-danger confirm_model" data-toggle="tooltip" data-placement="bottom" title="Delete Field" data-original-title = "Delete Field" data-rediret-url="'.current_url().'"  data-table="'.$this->table_name.'" data-href="advisor_rating"><i class="la la-times-circle"></i></a>';

				return $option; 

            });


            $rating->set_options(["columnDefs" => "[ { targets: [5], sortable: false}]"]);


            $rating->datatable($this->table_name);


            $rating->init();


			$data['datatable'] = true;


			$data['export'] = true;


			//$data['export_columns'] = [0,1,2,3,4,5,6,7];


        	$data['title'] = $this->title;


        	$data['export_title'] = $this->title;


			$this->renderAdmin('rating_review/index', $data);
	}
}


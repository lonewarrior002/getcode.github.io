<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SettingController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Settings';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'appsetting';
	}

    public function index() {
        $data['records'] = $this->comman->get_all_record('appsetting');
        $data['title']   = $this->title;
        $this->renderAdmin('setting/index', $data);
    }
    
    public function update_settings() {
        $request = $this->input->post();
        // $this->comman->update_record_by_condition('appsetting',['app_version' => $request['android_ad_version'], 'updates' => (int)($request['andriod_ad_chk'])], ['app_name' => 'android_service_provider']);
        // $this->comman->update_record_by_condition('appsetting',['app_version' => $request['ios_ad_version'], 'updates' => (int)($request['ios_ad_chk'])], ['app_name' => 'ios_service_provider']);
        // $this->comman->update_record_by_condition('appsetting',['app_version' => $request['andriod_cust_version'], 'updates' => (int)($request['andriod_cust_chk'])], ['app_name' => 'android_customer']);
        // $this->comman->update_record_by_condition('appsetting',['app_version' => $request['ios_cust_version'], 'updates' => (int)($request['ios_cust_chk'])], ['app_name' => 'ios_customer']);
        $this->comman->update_record_by_condition('appsetting',['app_version' => $request['android_version'], 'updates' => (int)($request['android_chk'])], ['app_name' => 'android_app']);
        $this->comman->update_record_by_condition('appsetting',['app_version' => $request['ios_version'], 'updates' => (int)($request['ios_chk'])], ['app_name' => 'ios_app']);
        $this->comman->update_record_by_condition('appsetting',['updates' => (int)($request['maintenance_chk'])], ['app_name' => 'maintenance_mode']);
        echo 1;
    }
    
    public function other_settings() {

        $this->load->library('Datatables');

        $other = new Datatables;

		$other->select('id, name, value', false)->from('settings')->where_in('name', ['minutes', 'advisor_commission','admin_paypal_commission']);

		$other

			->style(['class' => 'table table-striped table-bordered nowrap'])

			->column('#', 'id')
            ->column('Field', 'name', function($field) {
                return ucfirst(str_replace('_', ' ', $field));
            })
            ->column('Value', 'value', function($value, $row){
                if($row['name'] == 'minutes'){
                    return implode(', ',explode('|',$value));
                }
                if($row['name'] == 'advisor_commission'){
                    return $value."%";
                }
                if($row['name'] == 'admin_paypal_commission'){
                    return "$".$value;   
                }
                return $value;
            })
            ->column('Action', 'id', function($id){
                return '<a href="javascript:void(0);" data-id = "'.$id.'" class="on-default edit_other_settings_popup text-secondary" data-toggle="tooltip" data-placement="bottom" title="Edit" data-original-title = "Edit"><i class="la la-pencil-square"></i></a>';
            });

        $other->set_options(["columnDefs" => "[ { targets: [2,3], sortable: false}]"]);

		$other->datatable('settings');

		$other->init();

		$data['datatable'] = true;
        
        $data['export'] = true;
		$data['export_columns'] = [0,1,2];
        $data['export_title'] = $this->title;

        $data['title'] = $this->title;

		$this->renderAdmin('setting/other', $data);

    }
    
    public function open_other_settings_popup() {
        $record_id = $this->input->post('record_id');
        $data = [];
        if(!empty($record_id)) {
            $data['record'] = $this->comman->get_record_byid('settings', $record_id, 'id, name, value');
        }
        echo json_encode(['view' => $this->load->view('admin/pages/setting/popup_view', $data)]);
    }
    public function save_other_setting() {
        if (isset($_POST) && !empty($_POST)) {
            $request = $this->input->post();
            
            $validation_rules = [
                ['field' => 'value', 'label' => 'value', 'rules' => 'trim|required']
            ];
            $this->form_validation->set_rules($validation_rules);
            if ($this->form_validation->run() === true) {
                if($request['field'] == 'minutes') {
                    $request['value'] = implode('|',explode(',',$request['value']));
                }
                $this->comman->update_record('settings',['value' => $request['value'], 'updated_at' => current_date()], $request['record_id']);
                $status = true;
                $message = 'Record save successfully';
            } else {
                $status = false;
                $message = validation_errors(); 
            }
            echo json_encode(['status' => $status, 'message' => $message]);
        }
    }
    
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Dashboard';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
	}

    public function index() {
        $data['title'] = $this->title;
        $data['users_count'] = $this->db->select('u.id')->from('users as u')
                                        ->join('users_groups as ug', 'u.id= ug.user_id')
                                        ->where('ug.group_id', $this->config->item('roles','ion_auth')['customer'])
                                        ->where('u.deleted_at', null)
                                        ->get()->num_rows();
        $data['advisor_count'] = $this->db->select('u.id')->from('users as u')
                                        ->join('users_groups as ug', 'u.id= ug.user_id')
                                        ->where('ug.group_id', $this->config->item('roles','ion_auth')['service_provider'])
                                        ->where('u.deleted_at', null)
                                        ->get()->num_rows();
        $data['on_going_count'] = $this->db->select('id')->from('booking_request')
                                        ->where('status', BOOKING_ACCEPT)
                                        ->where('start_time IS NOT NULL')
                                        ->where('end_time IS NULL')
                                        ->where('is_session_running',1)
                                        ->get()->num_rows();
        $data['canceled_count'] = $this->db->select('id')->from('booking_request')
                                        ->where('status', BOOKING_REJECT)
                                        // ->where('booking_request.is_session_running','1')
                                        ->where('booking_request.reject_call_detail',2)
                                        ->get()->num_rows();

        $data['bookings'] = $this->db->select('booking_request.*,advisor.full_name as advisor_name,customer.full_name as customer_name')->from('booking_request')
                                    ->join('users as advisor','booking_request.advisor_id = advisor.id')
                                    ->join('users as customer','booking_request.user_id = customer.id')
                                    ->group_start()
                                        ->group_start()
                                            ->where('booking_request.status','1')
                                            ->where('booking_request.end_time IS NOT NULL')
                                            ->where('booking_request.is_session_running','1')
                                        ->group_end()
                                        ->or_group_start()
                                            ->where('booking_request.status','2')
                                            ->where('booking_request.reject_call_detail','2')
                                            // ->where('booking_request.is_session_running','1')
                                        ->group_end()
                                    ->group_end()
                                    ->order_by('booking_request.id','DESC')
                                    ->limit(10)
                                    ->get()->result_array();
		$this->renderAdmin('dashboard', $data);
    }
    
    public function profile() {
        $data['login_user_detail'] = $this->comman->get_record_byid('users', $this->login_user_id);
        
        if (isset($_POST) && !empty($_POST)) {
            $validation_rules = [
                ['field' => 'fname', 'label' => 'first name', 'rules' => 'trim|required'],
                ['field' => 'lname', 'label' => 'last name', 'rules' => 'trim|required'],
            ];
            $image_is_uploaded = [];
            if(file_exists($_FILES['profile_picture']['tmp_name']) || is_uploaded_file($_FILES['profile_picture']['tmp_name'])) {
                $image_is_uploaded = image_upload('profile_picture', 'images/users/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG');
                if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {
                    $submit_data['profile_picture'] = $image_is_uploaded['uploaded_path'];
                } else if( isset($image_is_uploaded['error']) ) {
                    $this->session->set_flashdata('error', ucfirst($image_is_uploaded['error']));
                    redirect('admin/profile');
                }
            }
	
            $this->form_validation->set_rules($validation_rules);
            if ($this->form_validation->run() === true) {
                $request = $this->input->post();
                $submit_data['first_name'] = addslashes($request['fname']);
                $submit_data['last_name']  = addslashes($request['lname']);
                $submit_data['full_name']  = addslashes($request['fname'].' '.$request['lname']);
                $submit_data['updated_at'] = current_date();

                if(!$request['update_pic']) {
                    $submit_data['profile_picture'] = null;
                    @unlink(FCPATH.'/'.$data['login_user_detail']['profile_picture']);
                }
                $this->ion_auth->update($this->login_user_id, $submit_data);
                $this->session->set_flashdata('success', 'Profile update successfully');
                redirect('admin');
            } else {
                $this->session->set_flashdata('error', validation_errors());
            }
		}
        
        $data['title'] = "Profile";
        $this->renderAdmin('profile', $data);
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TrainingController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Training Management';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'training';
	}

    function index(){
        

        $this->load->library('Datatables');

        $training = new Datatables;

        // $data['video_record'] = $this->comman->get_record_by_condition($this->table_name, 'video_url IS NOT NULL AND type = "video"', 'id,title,description,video_url,thumbnail');

        $data['video_record'] = $this->db->select('*')->from('training')
                                ->where('type',"video")
                                //->where('deleted_at IS NULL')
                                ->get()->row_array();

        // $training  = $this->db->select('tr.id, tr.file, category.name')->from($this->table_name.' as tr')
        //             ->join('category', 'tr.category_id = category.id')
        //             ->where('tr.video_url IS NULL');

        $training ->select('tr.id, tr.file,tr.title, category.name', false)->from($this->table_name.' as tr')
                ->join('category', 'tr.category_id = category.id', 'left')
                ->where('tr.video_url IS NULL');
        // echo "<pre>";
        // print_r($training);exit();

        $data['categories']   = $this->comman->get_record_by_condition('category', ['status' => STATUS_ACTIVE, 'deleted_at' => null]);

        $data['title']        = $this->title;

        $data['title'] = $this->title;

        //print_r($_SESSION);die();

        //$this->renderPharmacy('coming_soon', $data);


        $action['edit'] = base_url('admin/training-management/edit/');

        $action['delete'] = base_url('admin/training-management/delete/');
 
        $training

            ->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

            ->column('#', 'id')

            ->column('Category Name', 'name',function ($name){
                if(isset($name) && !empty($name)) {
                    return $name;
                }
                return 'General';
            })

            ->column('Title', 'title')

            ->column('File', 'file',function ($file){

            	return '<a href="'.base_url().$file.'" target="_blank">'.$file.'';

            })

            ->column('Actions', 'id', function ($id) use ($action) {

                $option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="Edit" data-original-title = "Edit"><i class="la la-pencil-square "></i></a>';

                $option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_confirm(this);"  class="on-default text-danger confirm_model" data-toggle="tooltip" data-placement="bottom" title="Delete" data-original-title = "Delete Field" data-rediret-url="'.current_url().'"  data-table="'.$this->table_name.'" data-href="admin/training-management"><i class="la la-times-circle"></i></a>';

                return $option;

            });


        $training->set_options(["columnDefs" => "[ { targets: [3,4], sortable: false}]"]);


        $training->datatable($this->table_name);


        $training->init();


        $data['datatable'] = true;


        $data['export'] = true;


        $data['export_columns'] = [0,1,2,3];


        $data['add_url'] = base_url('admin/training-management/add');

        if(!empty($data['video_record'])){
            
            $data['edit_url'] = base_url('admin/training-management/edit-video/'.$data['video_record']['id']);

            $data['delete_url'] = base_url('admin/training-management/delete-video/'.$data['video_record']['id']);

        }

        $data['title'] = $this->title;


        $data['export_title'] = $this->title;

		$this->renderAdmin('training/index',$data);
    }

    public function upload_video($id){

        $current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {
            // _pre($_POST);

            $request = $this->input->post();

            if(isset($_FILES['video']['tmp_name']) && file_exists($_FILES['video']['tmp_name']) || is_uploaded_file($_FILES['video']['tmp_name'])) {
                if(in_array($_FILES['video']['type'],['video/mp4'])) {
                    $video_is_uploaded = image_upload('video', 'training/', TRUE, 'mp4', '50000');
                    if(isset($video_is_uploaded['status']) && $video_is_uploaded['status']) {
                        @unlink(FCPATH.'/'.$request['old_video_url']);
                        $file = $video_is_uploaded['uploaded_path'];
                    }else if( isset($video_is_uploaded['error']) ) {
                        $this->session->set_flashdata('error', ucfirst($video_is_uploaded['error']));
                        redirect('admin/training-management/edit-video/'.$id);
                    }
                }else{
                    $this->session->set_flashdata('error', "Please upload mp4 file only");
                    redirect('admin/training-management/edit-video/'.$id);
                }
            }else{
                $file = $request['old_video_url'];
            }

            $edit_training_video = [

                //'category_id'   => ($request['category_id'] != '' && $request['category_id'] != 0) ? $request['category_id'] : 0,

                'title'         => $request['title'],

                'description'   => $request['description'],

                'video_url'     => $file,

                'updated_at'    => $current_date

            ];

            $this->comman->update_record($this->table_name, $edit_training_video,$id);

            $this->session->set_flashdata('success', 'Video edited sucessfully');

            redirect('admin/training-management');

        }else{
            $data['title'] = 'Edit Video';

            $data['video'] =  $this->comman->get_record_byid('training',$id);

            // $data['categories']   = $this->comman->get_record_by_condition('category', ['status' => STATUS_ACTIVE, 'deleted_at' => null]);

            $this->renderAdmin('training/edit_video',$data);

        }
        // echo "<pre>";
        // print_r($_FILES);exit();
    }
    
    public function upload_training() {
        $status = true;
        $message = '';
        $content = '';
        
        // echo "<pre>";
        // print_r($_FILES);exit();
        
        if(!empty($this->input->post('title')) || !empty($this->input->post('description'))) {
            $is_video_upload = false;
            if(isset($_FILES['video']['tmp_name']) && file_exists($_FILES['video']['tmp_name']) || is_uploaded_file($_FILES['video']['tmp_name'])) {
                $is_video_upload = true;
                if(in_array($_FILES['video']['type'],['video/mp4'])) {
                    $video_is_uploaded = image_upload('video', 'training/', TRUE, 'mp4', '50000');
                    if(isset($video_is_uploaded['status']) && $video_is_uploaded['status']) {
                        @unlink(FCPATH.'/'.$this->input->post('old_video_url'));
                        @unlink(FCPATH.'/'.$this->input->post('thumbnail_url'));
                        $this->comman->update_record($this->table_name, ['video_url' => $video_is_uploaded['uploaded_path'], 'thumbnail' => '','title'=>$this->input->post('title'),'description' => $this->input->post('description') ], $this->input->post('video_record_id'));
                        $message = 'Video uploaded successfully';
                        $content = $video_is_uploaded['uploaded_path'];
                    } else if( isset($video_is_uploaded['error']) ) {
                        $message = ucfirst($video_is_uploaded['error']);
                        $status = false;
                    }
                } else {
                    $message = 'Please upload mp4 file only';
                    $status = false;
                }
            }
            $is_pdf_upload = false;
            if(isset($_FILES['pdf']['tmp_name']) && file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name'])) {
                $is_pdf_upload = true;
        //            if(!empty($this->input->post('category_id'))) {
                    if(in_array($_FILES['pdf']['type'],['application/pdf'])) {
                        $pdf_is_uploaded = image_upload('pdf', 'training/', TRUE, 'pdf|PDF', '5000');
                        if(isset($pdf_is_uploaded['status']) && $pdf_is_uploaded['status']) {
                            $this->comman->insert_record($this->table_name, ['category_id' => ($this->input->post('category_id')) ?? 0, 'file' => $pdf_is_uploaded['uploaded_path'],'created_at' => current_date()]);
                            $message = 'File uploaded successfully';
                        } else if( isset($pdf_is_uploaded['error']) ) {
                            $message = ucfirst($pdf_is_uploaded['error']);
                            $status = false;
                        }
                    } else {
                        $message = 'Please upload pdf file only';
                        $status = false;
                    }
            //            } else {
            //                $message = 'Please select category id';
            //                $status = false;
            //            }
            }
            
            if(!$is_video_upload && !$is_pdf_upload) {
                $message = 'Please upload pdf or video';
                $status = false;
            }
        } else {
            $message = 'Please enter title and description';
            $status = false;
        }
        echo json_encode(['status' => $status, 'message' => $message, 'content' => $content]);
    }

    public function add(){

       // echo "here";exit;

        $current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

            $request = $this->input->post();

            if($request['type'] == "pdf" && isset($_FILES['pdf']['tmp_name']) && file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name'])){
                
                if(isset($_FILES['pdf']['tmp_name']) && file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name'])) {
                    if(in_array($_FILES['pdf']['type'],['application/pdf'])) {
    
                        $pdf_is_uploaded = image_upload('pdf', 'training/', TRUE, 'pdf|PDF', '5000');
                        if(isset($pdf_is_uploaded['status']) && $pdf_is_uploaded['status']) {
    
                            $create_training_pdf = [
    
                                'category_id'   => ($request['category_id'] != '' && $request['category_id'] != 0) ? $request['category_id'] : 0,
            
                                'title'         => $request['title'],
            
                                'description'   => $request['description'],
    
                                'file'          => $pdf_is_uploaded['uploaded_path'],
            
                                'created_at'    => $current_date
            
                            ];
    
                            $this->comman->insert_record($this->table_name, $create_training_pdf);
                            $this->session->set_flashdata('success', 'File uploaded successfully');
    
                            redirect('admin/training-management');
                            // $message = 'File uploaded successfully';
    
                        } else if( isset($pdf_is_uploaded['error']) ) {
                            $this->session->set_flashdata('error', ucfirst($pdf_is_uploaded['error']));
                            redirect('admin/training-management');
                            // $message = ucfirst($pdf_is_uploaded['error']);
                            // $status = false;
                        }
    
                        // echo "add";exit;
    
                    }else{
                        // echo "add error";exit;
                        //$message = 'Please upload pdf file only';
                        $this->session->set_flashdata('error', "Please upload pdf file only");
                        redirect('admin/training-management/add');
                    }
                }

            }
            else if ($request['type'] == "video" && isset($_FILES['video']['tmp_name']) && file_exists($_FILES['video']['tmp_name']) || is_uploaded_file($_FILES['video']['tmp_name'])){
                
                $file = '';
                if(isset($_FILES['video']['tmp_name']) && file_exists($_FILES['video']['tmp_name']) || is_uploaded_file($_FILES['video']['tmp_name'])) {
                    if(in_array($_FILES['video']['type'],['video/mp4'])) {
                        $video_is_uploaded = image_upload('video', 'training/', TRUE, 'mp4', '50000');
                        if(isset($video_is_uploaded['status']) && $video_is_uploaded['status']) {
                            @unlink(FCPATH.'/'.$request['old_video_url']);
                            $file = $video_is_uploaded['uploaded_path'];
                        }else if( isset($video_is_uploaded['error']) ) {
                            $this->session->set_flashdata('error', ucfirst($video_is_uploaded['error']));
                            redirect('admin/training-management/edit-video/1');
                        }
                    }else{
                        $this->session->set_flashdata('error', "Please upload mp4 file only");
                        redirect('admin/training-management/edit-video/1');
                    }
                }
                // else{
                //     $file = $request['old_video_url'];
                // }
    
                $add_training_video = [
    
                    //'category_id'   => ($request['category_id'] != '' && $request['category_id'] != 0) ? $request['category_id'] : 0,
    
                    'title'         => $request['title'],
    
                    'description'   => $request['description'],

                    'type'          => "video",
    
                    'video_url'     => $file,
    
                    'updated_at'    => $current_date
    
                ];
    
                $this->comman->insert_record($this->table_name, $add_training_video);
                $this->session->set_flashdata('success', 'File uploaded successfully');
                redirect('admin/training-management');

            }else{
                $this->session->set_flashdata('error', "Please upload ".$request['type']);
                redirect('admin/training-management/add');
            }

            // _pre($_POST);

        }else{
            $data['title'] = 'Add PDF';

            $data['categories']   = $this->comman->get_record_by_condition('category', ['status' => STATUS_ACTIVE, 'deleted_at' => null]);

            $data['video']   = $this->comman->get_record_by_condition('training', ['type' => "video", 'deleted_at' => null]);

            $this->renderAdmin('training/add',$data);

        }
    }

    public function edit($id = ''){

        $training_pdf = $this->comman->get_record_byid('training',$id);
        
        $current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

            $request = $this->input->post();

            if(isset($_FILES['pdf']['tmp_name']) && file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name'])) {

                if(in_array($_FILES['pdf']['type'],['application/pdf'])) {

                    $pdf_is_uploaded = image_upload('pdf', 'training/', TRUE, 'pdf|PDF', '5000');
                    if(isset($pdf_is_uploaded['status']) && $pdf_is_uploaded['status']) {
                        $file = $pdf_is_uploaded['uploaded_path'];
                    }else if( isset($pdf_is_uploaded['error'])){
                        $this->session->set_flashdata('error', ucfirst($pdf_is_uploaded['error']));
                        redirect('admin/training-management/edit/'.$id);
                    }

                }else{
                    $this->session->set_flashdata('error', "Please upload pdf file only");
                    redirect('admin/training-management/edit/'.$id);
                }

            }else{
                $file = $request['old_file'];
            }

            $edit_training_pdf = [

                'category_id'   => ($request['category_id'] != '' && $request['category_id'] != 0) ? $request['category_id'] : 0,

                'title'         => $request['title'],

                'description'   => $request['description'],

                'file'          => $file,

                'updated_at'    => $current_date

            ];

            $this->comman->update_record($this->table_name, $edit_training_pdf,$id);

            $this->session->set_flashdata('success', 'PDF edited sucessfully');

            redirect('admin/training-management');
        }

        $data['title'] = 'Edit '.$this->title;

        $data['training_pdf'] = $training_pdf;

        // _pre($data['training_pdf']);

        $this->renderAdmin('training/edit',$data);

    }

    public function delete($id) {
    	// print_r($id);exit();
        $this->comman->delete_recordbyid($this->table_name,$id);
        echo 1;
    }

    public function delete_video($id){
        $video = $this->db->select('*')->from('training')->where('id',$id)->get()->row_array();
        @unlink(FCPATH.'/'.$video['video_url']);
        $this->comman->delete_recordbyid('training',$id);
        redirect('admin/training-management');
       
    }
}
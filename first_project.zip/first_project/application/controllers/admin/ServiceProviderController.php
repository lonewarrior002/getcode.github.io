<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ServiceProviderController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Advisors';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'users';
        $this->customer_grp   = $this->config->item('roles', 'ion_auth')['service_provider'];
	}

	public function index($filter = '') {

        $this->load->library('Datatables');
    

        if(!empty(trim($filter))){
            // $null = NULL;
            if($filter == 'approved'){
                $where = "approve_advisor_detail = '1'";
            }elseif($filter == 'pending'){
                $where = "change_params is NULL AND approve_advisor_detail = '0'";
            }else{
                $where = "change_params != 'NULL' AND approve_advisor_detail = '0' AND change_params != 'is_change_availability'";
            }
            $data['filter_record'] = $filter;

        }else{
            $where = '1=1';
            $data['filter_record'] = false;
        }

        $service_provider = new Datatables;

		$service_provider->select('u.id, u.email, u.full_name, u.nick_name, u.phone, u.active, u.created_on, u.approve_advisor_detail, u.category_id, u.change_params, u.advisor_withdrawal_amount', false)->from($this->table_name.' u')

                ->join('users_groups ug', 'u.id = ug.user_id')

                ->where('ug.group_id', $this->customer_grp)

                ->where('u.deleted_at', NULL)

                ->where($where);
                // ->group_start()
                //     ->where('pul.user_id','u.id')
                // ->group_end();


		$action['edit'] = base_url('admin/service-provider/edit/');

		$action['delete'] = base_url('admin/service-provider/delete/');

        $action['category_view'] = base_url('admin/service-provider/category-view/');



		$service_provider

			->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Name', 'full_name')
                                                        
			->column('Nick Name', 'nick_name')

			->column('Email', 'email')

			->column('Phone', 'phone')

            ->column('Created On', 'created_on', function ($created_on) {

                return __date($created_on, true);

            })
			->column('Total Earning', 'id', function ($id) {

                return round(($this->db->query('SELECT sum(amount) as total_amt FROM `wallet` WHERE amount_type = "withdraw" AND user_id = '.$id.' GROUP BY user_id')->row_array()['total_amt']),2) ?? 0;

            })
			->column('Pending Payout', 'advisor_withdrawal_amount')

			->column('Status', 'active', function($active, $row) {

                if ($active == 1) {

					return '<h5 class="mb-0 mt-0"><span onclick="change_advisor_status(this);" class="badge badge-success cursor-pointer font-15 status_' . $row['id'] . '" data-table="users" data-status = '.$active.' data-id="' . $row['id'] . '">Active</span></h5>';

				} else {

					return '<h5 class="mb-0 mt-0"><span onclick="change_advisor_status(this);" class="badge badge-danger cursor-pointer font-15 status_' . $row['id'] . '" data-table="users" data-status = '.$active.' data-id="' . $row['id'] . '">Inactive</span></h5>';

                }

            })
            
			->column('Approve Profile', 'approve_advisor_detail', function($approve_advisor_detail, $row) {
                
                $html = '';

               if ($approve_advisor_detail == 1) {
                  // onclick="approve_advisor_profile(this);" 
                    $html .= '<h5 class="mb-0 mt-0 profile_update"><span class="badge badge-success font-15 approve_status_' . $row['id'] . '" data-status="'.$approve_advisor_detail.'" data-id="' . $row['id'] . '" data-category_id="'.$row['category_id'].'">Approve</span></h5>&nbsp;&nbsp';

                }
                else if($row['change_params'] != '') {

                    $html .= '<h5 class="mb-0 mt-0 profile_update"><span class="badge badge-danger font-15 approve_status_' . $row['id'] . '" data-status="'.$approve_advisor_detail.'" data-id="' . $row['id'] . '" data-category_id="'.$row['category_id'].'" data-table="users">Pending</span></h5>&nbsp;&nbsp';

                    if($row['change_params'] != '' && $row['change_params'] != 'is_change_availability'){

                        $html .='<a href="javascript:void(0);" data-user_id = "'.$row['id'].'" data-params = "'.$row['change_params'].'" class="on-default profile_update_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Profile Update Detail" data-original-title = "View profile update Detail"><i class="la la-eye"></i></a>';
                    }

                }else{

                    $html .= '<h5 class="mb-0 mt-0 profile_update"><span onclick="approve_advisor_profile(this);" class="badge badge-danger cursor-pointer font-15 approve_status_' . $row['id'] . '" data-status="'.$approve_advisor_detail.'" data-id="' . $row['id'] . '" data-category_id="'.$row['category_id'].'" data-table="users">Pending</span></h5>&nbsp;&nbsp';
                }

                return $html;

            })
            
            // ->column('Changed Fields', 'change_params', function ($change_params, $row) {

            //     return '<span class="change_params_'.$row['id'].'">'.((!is_null($change_params) && !empty($change_params)) ? $change_params : '-').'</span>';

            // })

            // ->column('Action', 'id', function ($id) use ($action) {

            	

            //     return '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="" data-original-title = "Edit Field"><i class="la la-pencil-square "></i></a>';

            // });

			->column('Actions', 'id', function ($id, $row) use ($action) {

				$option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" title="Edit"><i class="la la-pencil-square "></i></a>';

				$option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_advisor(this);"  class="on-default text-danger confirm_model" data-toggle="tooltip" data-id='. $id .' data-placement="bottom" title="Delete" data-original-title = "Delete" data-rediret-url="'.current_url().'" data-error-msg="pending orders" data-table="'.$this->table_name.'"><i class="la la-times-circle"></i></a>&nbsp;&nbsp';

                // if($row['change_params'] == 'is_change_availability'){
                    $option .= '<a href="' . $action['category_view'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Category Details" data-original-title = "View Category Details"><i class="la la-paper-plane "></i></a>';
                // }

				return $option;

			});

        $service_provider->set_options(["columnDefs" => "[ { targets: [10], sortable: false}]"]);

        $service_provider->searchable('u.id,u.full_name, u.nick_name, u.email, u.phone');

		$service_provider->datatable($this->table_name);

		$service_provider->init();

		$data['datatable'] = true;

        $data['export'] = true;

		$data['export_columns'] = [0,1,2,3,4,5,6,7,8,9];

        $data['export_title'] = $this->title;



//		$data['add_url'] = base_url('admin/delivery-person/add');

        $data['title'] = $this->title;

		$this->renderAdmin('service_provider/index', $data);

    }

    public function delete($id) {

        $this->comman->update_record($this->table_name, ['deleted_at' => current_date()], $id);
        
        $this->db->where('user_id', $id)->delete('tokens');

        echo 1;

    }

    public function edit($id = ''){

    	if (isset($_POST) && !empty($_POST)) {
    		
    		$request = $this->input->post();

                $update_customer = [

                    //'faq_type_id'   => $request['faq_type_id'],

                    'full_name'   	=> trim($request['full_name']),

                    'nick_name'   	=> trim($request['nick_name']),

                    'email'   		=> $request['email'],

                    'phone'   		=> $request['phone'],

                    'dob'			=> $request['dob'],

                    'advisor_description' => $request['advisor_description'],

                    'updated_at'    => current_date()

                ];

                if(file_exists($_FILES['profile_picture']['tmp_name']) || is_uploaded_file($_FILES['profile_picture']['tmp_name'])) {

                    $image_is_uploaded = image_upload('profile_picture', 'images/users/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG');

                    if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                        $update_customer['profile_picture'] = $image_is_uploaded['uploaded_path'];

                        $status = true;

                    } else if( isset($image_is_uploaded['error']) ) {

                        $status  = false;

                        $this->session->set_flashdata('error', ucfirst($image_is_uploaded['error']));

                        redirect('admin/service-provider/edit/'.$id);
                        
                        // $this->session->set_flashdata('error', $image_is_uploaded['error']);

                    }

                } 

                $this->comman->update_record($this->table_name, $update_customer,$id);

                $paypal_update['account_detail'] =  $request['account_detail'];
                $this->db->update("advisor_payment_detail", $paypal_update, array('user_id' => $id));

                $this->session->set_flashdata('success', 'Advisor updated sucessfully');

                redirect('admin/service-provider');

    	}else{

    		$data['title'] = 'Edit '.$this->title;

	    	$customer = $this->comman->get_record_byid('users',$id);
	    	$advisor_account_detail = $this->comman->get_record_by_condition('advisor_payment_detail', ['user_id'=>$id], 'account_detail');
            $availibility = [];
            $data['columns'] = [];
            if(!empty($customer['category_id'])) {
                $availibility = $this->db->select('category.name, availability.type, availability.price')->from('category')
                                ->join('availability', 'category.id = availability.category_id')
                                ->where('availability.user_id = '.$id.' AND availability.category_id IN ('.$customer['category_id'].')')
                                ->get()->result_array();
                $data['columns'] = array_unique(array_column($availibility, 'name'));
            }
	        $data['customer'] = $customer;
	        $data['advisor_account_detail'] = $advisor_account_detail;
	        $data['availibility'] = $availibility;
//            _pre($data);
	        $this->renderAdmin('service_provider/edit',$data);
    	}

    }
    
    public function approve_status($id) {
        
        $data = $this->db->select('approve_advisor_detail, email')->get_where('users', ['id' => $id])->row();
		$status = STATUS_ACTIVE;
        if($data->approve_advisor_detail == STATUS_ACTIVE) {
            $status = STATUS_INACTIVE;
        }
        $this->comman->update_record('users', ['approve_advisor_detail' => $status], $id);
        if($status) {
            $this->comman->update_record('users', ['change_params' => null], $id);
            $title = SITENAME;
            $description = 'Profile Approved';
    		send_push($id, 'users', $title , $description, 'profile_approved', ['approve_advisor_detail' => $status]);
            
            $template = file_get_contents(base_url('email_templates/profile_approved.html'));
            $message  = create_email_template($template);
            $subject = $this->config->item('site_title', 'ion_auth') . ' - Profile Approved' ;
            sendEmail($subject, $data->email, $message);
        } else {
            $title = SITENAME;
            $description = 'Profile Under Approval';
    		send_push($id, 'users', $title , $description, 'profile_under_approval', ['approve_advisor_detail' => $status]);
        }

        $notification_data = array(
            'sent_to'       => $id,   
            'sent_by'       => 1,   
            'title'         => $title,               
            'description'   =>  $description,               
            'created_at'    => current_date()
        );
        $this->comman->insert_record('notification',$notification_data);

		echo $status;
		
	}


    public function profile_update_details_popup(){

        $user_id = $this->input->post('user_id');

        $params = $this->input->post('params');
        $new = explode(',',$params);
        $change_params = "'".implode("','",$new)."'";

        $data['profile_details'] = $this->db->query('SELECT * FROM profile_update_log WHERE id IN ( SELECT MAX(id) as id FROM profile_update_log where status = 0 AND user_id = '.$user_id.' AND field_name IN ('.$change_params.') GROUP BY field_name)')->result_array();

        echo json_encode(['view' => $this->load->view('admin/pages/service_provider/view_update_details_popup', $data)]);

    }

    public function category_view($id,$month = '',$year = ''){

            $months = array("January", "February", "March","April","May","June","July","August","September","October","November","December");
            $i = 0;
            $year_arr = 2020;
            for ($i=0; $i < 21; $i++) { 
                $years[] = $year_arr;
                $year_arr ++;
            }
            
            // $years = array("2020", "2021", "2022","2023","2024","2025");
            if($month != '' && $year != ''){
                $month = $month;
                $year = $year;
                $from = date('Y-m-01',strtotime($month.' '.$year)).' 00:00:00';
                $to = date('Y-m-t',strtotime($month.' '.$year)).' 23:59:59';

            }else{

                $month = date('F');
                $year = date('Y');

                $from = date('Y-m-01').' 00:00:00';
                $to  = date('Y-m-t').' 23:59:59';
            }

            if($from != '' && $to != ''){$where = 'pcl.created_at BETWEEN "'.$from.'" AND "'.$to.'"';}else{$where = "1=1";}

            
            $category = $this->db->select('pcl.*,DATE(pcl.created_at) as date,category.name,old_category.name as old_category_name')->from('price_change_log as pcl')
                        ->join('category','pcl.new_category_id = category.id')
                        ->join('category as old_category','pcl.current_category_id = old_category.id','left')
                        ->where('pcl.user_id',$id)
                        ->where($where)
                        ->order_by('pcl.created_at','DESC')
                        ->order_by( 'FIELD (pcl.type,"chat","audio","video")')
                        ->get()->result_array();

            // _pre($id);
            $category_dates =  array_column($category,'date');
            $row = [];
            foreach ($category as $key => $value) {
                foreach ($category_dates as $k => $value1) {
                    if($value['date'] == $value1) {
                        $row[$value1]['type'][$key] = $value;
                    }
                }   
            }
            // _pre($row);
            $data['category'] = $row;
            $data['months'] = $months;
            $data['month'] = $month;
            $data['years'] = $years;
            $data['year'] = $year;
            $data['user_id'] = $id;
            $data['title'] = $this->title;

            $this->renderAdmin('service_provider/category_view',$data);


    }

    public function profile_update_save(){

        $data['user_id']                        = $_POST['user_id'];
        $data['advisor_description_record_id']  = $_POST['advisor_description_record_id'];
        $data['advisor_description_status']     = $_POST['advisor_description_status'];
        $data['advisor_description_new_value']  = $_POST['advisor_description_new_value'];
        $data['reason_advisor_description']     = $_POST['reason_advisor_description'];
        $data['profile_picture_record_id']      = $_POST['profile_picture_record_id'];
        $data['profile_picture_status']         = $_POST['profile_picture_status'];
        $data['reason_profile_picture']         = $_POST['reason_profile_picture'];
        $data['profile_picture_new_value']      = $_POST['profile_picture_new_value'];

            // _pre($data);
        $update_data = array();
        $get_user_detail = $this->comman->get_record_byid('users', $data['user_id'], 'profile_picture,email');

        $mail_data_advisor = '-';
        if($data['advisor_description_status'] == 'accept'){
            $update_data['advisor_description'] = $data['advisor_description_new_value'];
            $advisor_status = 1;
            $advisor_reason = NULL;
            $description = 'Profile Approved';
        }else{$mail_data_advisor = $data['reason_advisor_description']; $advisor_status = 2; $advisor_reason = $data['reason_advisor_description'];$description = 'Profile Rejected';}

        $mail_data_profile_picture = '-';
        if($data['profile_picture_status'] == 'accept'){
            $update_data['profile_picture'] = $data['profile_picture_new_value'];
            $profile_picture_status = 1;
            $reason_profile_picture = NULL;
            $description = 'Profile Approved';
            @unlink(FCPATH.$get_user_detail['profile_picture']);
        }else{$mail_data_profile_picture = $data['reason_profile_picture']; $profile_picture_status = 2; $reason_profile_picture = $data['reason_profile_picture'];$description = 'Profile Rejected';}

        if(count(array_filter($update_data)) > 0){
            $this->comman->update_record($this->table_name,$update_data, $data['user_id']);
        }

        $users['change_params'] = NULL;
        $users['approve_advisor_detail'] = 1;
        $this->comman->update_record($this->table_name,$users, $data['user_id']);

        $update = array(
            array(
                'id' => $data['advisor_description_record_id'],
                'status' => $advisor_status ,
                'reason' => $advisor_reason,
                'updated_at' => current_date()
            ),
            array(
                'id' => $data['profile_picture_record_id'] ,
                'status' => $profile_picture_status,
                'reason' => $reason_profile_picture,
                'updated_at' => current_date()
            )
        );

        $this->db->update_batch('profile_update_log', $update, 'id');

        $html = '';
        $html .= "<table class='o_block' border='1' width='100%' cellspacing='0' cellpadding='0' border='0' role='presentation' style='max-width: 632px;margin: 0 auto;background-color: #ffffff;'>
                    <tbody>
                        <tr style='color:#424651;'>
                            <th align=center style='padding: 1%;'> <b>FIELD NAME</b></td>
                            <th align=center style='padding: 1%;'><b>STATUS</b></td>
                            <th align=center style='padding: 1%;'><b>REASON(if rejected)</b></td>
                        </tr>";
        if($data['advisor_description_record_id'] != '' && $data['advisor_description_status'] != ''){
            $html .= "<tr>";
            $html .=  "<td align=left style='padding: 1% 1% 1% 4%;'>Advisor Description</td>";
            $html .=  "<td align=center>".$data['advisor_description_status']."</td>";
            $html .=  "<td align=center style='padding: 1% 1% 1% 4%;'>".$mail_data_advisor."</td>";
            $html .=  "</tr>";
        }
        
        if($data['profile_picture_record_id'] != '' && $data['profile_picture_status'] != ''){
            $html .= "<tr>";
            $html .=  "<td align=left style='padding: 1% 1% 1% 4%;'>Profile Picture</td>";
            $html .=  "<td align=center>".$data['profile_picture_status']."</td>";
            $html .=  "<td align=center style='padding: 1% 1% 1% 4%;'>".$mail_data_profile_picture."</td>";
            $html .=  "</tr>";
        }

        $html .=  "</tbody>
                </table>";

        $template = file_get_contents(base_url('email_templates/profile_approved_2.html'));
        $message  = create_email_template($template);
        $message  = str_replace('##TABLE##',$html, $message);
        $subject = $this->config->item('site_title', 'ion_auth') . ' - '.$description ;
        sendEmail($subject, $get_user_detail['email'], $message);

        $push_values = array(
            'advisor_description_status' => $data['advisor_description_status'],
            'reason_advisor_description' => $data['reason_advisor_description'],
            'advisor_new_value' => $data['advisor_description_new_value'],
            'profile_picture_status' => $data['profile_picture_status'],
            'reason_profile_picture' => $data['reason_profile_picture'],
            'profile_picture_new_value' => $data['profile_picture_new_value']
        );

        send_push($data['user_id'], 'users', SITENAME , $description , 'profile_approved', $push_values );
        $notification_data = array(
            'sent_to'       => $data['user_id'],   
            'sent_by'       => 1,   
            'title'         => SITENAME,               
            'description'   => $description,               
            'created_at'    => current_date()
        );
        $this->comman->insert_record('notification',$notification_data);

        echo json_encode(['status' => TRUE, 'message' => 'Profile Approved sucessfully.']);

    }

    public function delete_advisor(){

        $request = $this->input->post();

        $booking_details = $this->db->select('id')->from('booking_request')
                            ->where('advisor_id',$request['id'])
                            ->where('status != 2')
                            ->group_start()
                                ->group_start()
                                    ->where('status',1)
                                    ->where('type','video')
                                    ->or_where('type','audio')
                                ->group_end()
                                ->or_group_start()
                                    ->where('type','chat')
                                    ->where('status',1)
                                    ->where('is_session_running',1)
                                ->group_end()
                                ->or_group_start()
                                    ->where('status',0)
                                ->group_end()
                            ->group_end()
                            ->where('end_time IS NULL')
                            ->where('DATE(created_at) = "'.date('Y-m-d').'"')
                            ->order_by('id','DESC')
                            ->limit(1)
                            ->get()->result_array();

                            // _pre($booking_details);
        if(count($booking_details) != 0){
            $status = false;
        }else{
            $this->comman->update_record('users', ['deleted_at' => current_date()],$request['id']);
            $this->db->where('user_id', $request['id'])->delete('tokens');
            send_push($request['id'], 'users', SITENAME , 'Session Expired', 'logout');
            $status = true;
        }
        echo json_encode(['status' => $status]);
    }

    public function change_advisor_status(){

        $request = $this->input->post();

        $booking_details = $this->db->select('id')->from('booking_request')
                            ->where('advisor_id',$request['id'])
                            ->where('status != 2')
                            ->group_start()
                                ->group_start()
                                    ->where('status',1)
                                    ->where('type','video')
                                    ->or_where('type','audio')
                                ->group_end()
                                ->or_group_start()
                                    ->where('type','chat')
                                    ->where('status',1)
                                    ->where('is_session_running',1)
                                ->group_end()
                                ->or_group_start()
                                    ->where('status',0)
                                ->group_end()
                            ->group_end()
                            ->where('end_time IS NULL')
                            ->where('DATE(created_at) = "'.date('Y-m-d').'"')
                            ->order_by('id','DESC')
                            ->limit(1)
                            ->get()->result_array();

        if(count($booking_details) != 0){
            $status = false;
        }else{
            $status = true;
        }

        if($status == true){
            // send_push($request['id'], 'users', SITENAME , 'Session Expired', 'logout');
            if($request['active'] == 1){$update_data = ['active' => 0];}else{$update_data = ['active' => 1];}
            if($request['active'] == 1){ send_push($request['id'], 'users', SITENAME , 'Session Expired', 'logout');}
            $this->comman->update_record_by_condition('users', $update_data, ['id' => $request['id']] );
        }
        echo json_encode(['status' => $status, 'advisor_status' => $request['active']]);
    }
}
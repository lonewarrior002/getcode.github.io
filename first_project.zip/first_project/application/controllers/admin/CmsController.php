<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CmsController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = '';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'advisor_rating';
	}

	function index(){
        $data['template'] = $this->comman->get_record_by_condition('settings', ['name' => 'privacy_policy'], 'name, value, file')[0];
        if (isset($_POST) && !empty($_POST)) {
            $request = $this->input->post();
            $status = true;
            
            if(file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name']) ) {
                $pdf_is_uploaded = image_upload('pdf', 'files/', FALSE, 'pdf|PDF', 2048, 'privacy_policy');

                if(isset($pdf_is_uploaded['status']) && $pdf_is_uploaded['status']) {

                    $arr['file'] = $pdf_is_uploaded['uploaded_path'];

                } else if( isset($pdf_is_uploaded['error']) ) {

                    $status  = false;

                    $this->session->set_flashdata('error', ucfirst($pdf_is_uploaded['error']));

                }
            } else {
                $status  = false;
                
                $this->session->set_flashdata('error', 'Pdf file required');
            }
            if($status) {
                $arr['value'] = addslashes(preg_replace('/\s+/', ' ', $request['value']));
                $arr['updated_at'] = current_date();

                $this->comman->update_record_by_condition('settings', $arr, ['name' => 'privacy_policy']);
                $this->session->set_flashdata('success', 'Policy save successfully');
                redirect('admin/privacy-policy');
            }
		}
		$data['title'] = 'Privacy Policy';

		$this->renderAdmin('cms/privacy_policy',$data);
	}
    
    public function customer_terms() {
        
        $data['template'] = $this->comman->get_record_by_condition('settings', ['name' => 'customer_terms'], 'name, value, file')[0];
        if (isset($_POST) && !empty($_POST)) {
            $request = $this->input->post();
            $status = true;
            
            if(file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name']) ) {
                $pdf_is_uploaded = image_upload('pdf', 'files/', FALSE, 'pdf|PDF', 2048, 'customer_terms');

                if(isset($pdf_is_uploaded['status']) && $pdf_is_uploaded['status']) {

                    $arr['file'] = $pdf_is_uploaded['uploaded_path'];
                    

                } else if( isset($pdf_is_uploaded['error']) ) {

                    $status  = false;

                    $this->session->set_flashdata('error', ucfirst($pdf_is_uploaded['error']));

                }
            } else {
                $status  = false;
                
                $this->session->set_flashdata('error', 'Pdf file required');
            }
            if($status) {
                $arr['value'] = addslashes(preg_replace('/\s+/', ' ', $request['value']));
                $arr['updated_at'] = current_date();

                $this->comman->update_record_by_condition('settings', $arr, ['name' => 'customer_terms']);
                $this->session->set_flashdata('success', 'Customer Terms save successfully');
                redirect('admin/customer-terms');
            }
		}
		$data['title'] = 'Customer Terms & Conditions';

		$this->renderAdmin('cms/customer_terms',$data);
    }
    
    public function advisor_terms() {
        $data['template'] = $this->comman->get_record_by_condition('settings', ['name' => 'advisor_terms'], 'name, value, file')[0];
        if (isset($_POST) && !empty($_POST)) {
            $request = $this->input->post();
            $status = true;
            
            if(file_exists($_FILES['pdf']['tmp_name']) || is_uploaded_file($_FILES['pdf']['tmp_name']) ) {
                $pdf_is_uploaded = image_upload('pdf', 'files/', FALSE, 'pdf|PDF', 2048, 'advisor_terms');

                if(isset($pdf_is_uploaded['status']) && $pdf_is_uploaded['status']) {

                    $arr['file'] = $pdf_is_uploaded['uploaded_path'];

                } else if( isset($pdf_is_uploaded['error']) ) {

                    $status  = false;

                    $this->session->set_flashdata('error', ucfirst($pdf_is_uploaded['error']));

                }
            } else {
                $status  = false;
                
                $this->session->set_flashdata('error', 'Pdf file required');
            }
            if($status) {
                $arr['value'] = addslashes(preg_replace('/\s+/', ' ', $request['value']));
                $arr['updated_at'] = current_date();

                $this->comman->update_record_by_condition('settings', $arr, ['name' => 'advisor_terms']);
                $this->session->set_flashdata('success', 'Advisor Terms save successfully');
                redirect('admin/advisor-terms');
            }
		}
		$data['title'] = 'Advisor Terms & Conditions';

		$this->renderAdmin('cms/advisor_terms',$data);
    }
}

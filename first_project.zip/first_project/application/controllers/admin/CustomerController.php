<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CustomerController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Customers';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'users';
        $this->customer_grp   = $this->config->item('roles', 'ion_auth')['customer'];
	}

	public function index() {

        $this->load->library('Datatables');

        $patient = new Datatables;

		$patient->select('u.id, u.email, u.full_name, u.phone, u.active, u.created_on', false)->from($this->table_name.' u')

                ->join('users_groups ug', 'u.id = ug.user_id')

                ->where('ug.group_id', $this->customer_grp)

                ->where('u.deleted_at', NULL);



		$action['edit'] = base_url('admin/customer/edit/');

		$action['delete'] = base_url('admin/customer/delete/');



		$patient

			->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Name', 'full_name')

			->column('Email', 'email')

			->column('Phone', 'phone')

            ->column('Created On', 'created_on', function ($created_on) {

                return __date($created_on, true);

            })

			->column('Status', 'active', function($active, $row) {

                if ($active == 1) {

					return '<h5 class="mb-0 mt-0"><span onclick="change_customer_status(this);" class="badge badge-success cursor-pointer font-15 status_' . $row['id'] . '" data-table="users" data-status = '.$active.' data-id="' . $row['id'] . '">Active</span></h5>';

				} else {

					return '<h5 class="mb-0 mt-0"><span onclick="change_customer_status(this);" class="badge badge-danger cursor-pointer font-15 status_' . $row['id'] . '" data-table="users" data-status = '.$active.' data-id="' . $row['id'] . '">Inactive</span></h5>';

                }

            })

            // ->column('Action', 'id', function ($id) use ($action) {

            	

            //     return '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="" data-original-title = "Edit Field"><i class="la la-pencil-square "></i></a>';

            // });

			->column('Actions', 'id', function ($id) use ($action) {

				$option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" title="Edit"><i class="la la-pencil-square "></i></a>';

				$option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_customer(this);"  class="on-default text-danger confirm_model" title="Delete" data-rediret-url="'.current_url().'" data-error-msg="pending orders" data-id='. $id .' data-table="'.$this->table_name.'"><i class="la la-times-circle"></i></a>';

				return $option;

			});

            

        $patient->set_options(["columnDefs" => "[ { targets: [6], sortable: false}]"]);

        $patient->searchable('u.id,u.full_name, u.email, u.phone');

		$patient->datatable($this->table_name);

		$patient->init();

		$data['datatable'] = true;

        $data['export'] = true;

		$data['export_columns'] = [0,1,2,3,4,5];

        $data['export_title'] = $this->title;

        //		$data['add_url'] = base_url('admin/delivery-person/add');

        $data['title'] = $this->title;

		$this->renderAdmin('customer/index', $data);

    }

    public function delete($id) {

        $this->comman->update_record($this->table_name, ['deleted_at' => current_date()], $id);
        $this->db->where('user_id', $id)->delete('tokens');

        echo 1;

    }

    public function edit($id = ''){

    	if (isset($_POST) && !empty($_POST)) {

    		// print_r($_FILES);exit();
    		
    		$request = $this->input->post();

                $update_customer = [

                    //'faq_type_id'   => $request['faq_type_id'],

                    'full_name'   	=> trim($request['full_name']),

                    'email'   		=> $request['email'],

                    'phone'   		=> $request['phone'],

                    'dob'			=> $request['dob'],

                    'updated_at'    => current_date()

                ];

                if(file_exists($_FILES['profile_picture']['tmp_name']) || is_uploaded_file($_FILES['profile_picture']['tmp_name'])) {

                    $image_is_uploaded = image_upload('profile_picture', 'images/users/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG');

                    // print_r($image_is_uploaded);exit();

                    if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                        $update_customer['profile_picture'] = $image_is_uploaded['uploaded_path'];

                    } else if( isset($image_is_uploaded['error']) ) {

                        //$status  = false;

                        $this->session->set_flashdata('error', ucfirst($image_is_uploaded['error']));

                        redirect('admin/customer/edit/'.$id);

                    }

                }
                // _pre($update_customer);
                $this->comman->update_record($this->table_name, $update_customer,$id);

                $this->session->set_flashdata('success', 'Customer updated sucessfully');

                redirect('admin/customer');

    	}else{

    		$data['title'] = 'Edit '.$this->title;

	    	$customer = $this->comman->get_record_byid('users',$id);

	        $data['customer'] = $customer;

	        $this->renderAdmin('customer/edit',$data);
    	}

    }

    public function delete_customer(){

        $request = $this->input->post();

        $booking_details = $this->db->select('id')->from('booking_request')
                            ->where('user_id',$request['id'])
                            ->where('status != 2')
                            ->group_start()
                                ->group_start()
                                    ->where('status',1)
                                    ->where('type','video')
                                    ->or_where('type','audio')
                                ->group_end()
                                ->or_group_start()
                                    ->where('type','chat')
                                    ->where('status',1)
                                    ->where('is_session_running',1)
                                ->group_end()
                                ->or_group_start()
                                    ->where('status',0)
                                ->group_end()
                            ->group_end()
                            ->where('end_time IS NULL')
                            ->where('DATE(created_at) = "'.date('Y-m-d').'"')
                            ->order_by('id','DESC')
                            ->limit(1)
                            ->get()->result_array();
    //    _pre($this->db->last_query());
                            // _pre($booking_details);
        if(count($booking_details) != 0){
            $status = false;
        }else{
            $this->comman->update_record('users', ['deleted_at' => current_date()],$request['id']);
            $this->db->where('user_id', $request['id'])->delete('tokens');
            send_push($request['id'], 'users', SITENAME , 'Session Expired', 'logout');
            $status = true;
        }
        echo json_encode(['status' => $status,"booking_details"=>$booking_details]);
    }

    public function change_customer_status(){

        $request = $this->input->post();

        $booking_details = $this->db->select('id')->from('booking_request')
                            ->where('user_id',$request['id'])
                            ->where('status != 2')
                            ->group_start()
                                ->group_start()
                                    ->where('status',1)
                                    ->where('type','video')
                                    ->or_where('type','audio')
                                ->group_end()
                                ->or_group_start()
                                    ->where('type','chat')
                                    ->where('status',1)
                                    ->where('is_session_running',1)
                                ->group_end()
                                ->or_group_start()
                                    ->where('status',0)
                                ->group_end()
                            ->group_end()
                            ->where('end_time IS NULL')
                            ->where('DATE(created_at) = "'.date('Y-m-d').'"')
                            ->order_by('id','DESC')
                            ->limit(1)
                            ->get()->result_array();

        if(count($booking_details) != 0){
            $status = false;
        }else{
            $status = true;
        }

        if($status == true){
           
            if($request['active'] == 1){$update_data = ['active' => 0];}else{$update_data = ['active' => 1];}
            if($request['active'] == 1){ send_push($request['id'], 'users', SITENAME , 'Session Expired', 'logout');}
            $this->comman->update_record_by_condition('users', $update_data, ['id' => $request['id']] );
            $this->comman->update_record('users', ['device_token' => NULL, 'device_type' => 0], $request['id']);
            // echo "here";exit;
        }
        echo json_encode(['status' => $status, 'customer_status' => $request['active']]);
    }

}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Reports';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->advisor_grp   = $this->config->item('roles', 'ion_auth')['service_provider'];
        $this->customer_grp   = $this->config->item('roles', 'ion_auth')['customer'];
        $this->table_name = 'booking_request';
	}

    public function index($filter = '',$filter1 = '',$filter2 = '')
    {
    	$data['title'] = $this->title;

        $this->load->library('Datatables');

        $session_report = new Datatables;

        if($filter == '1' || $filter == 1 && $filter1 != '' && $filter2 != ''){
    		$From = $filter1." 00:00:00";
        	$To = $filter2." 23:59:59";
        	$where = 'booking_request.created_at BETWEEN "'.$From.'" AND "'.$To.'"';
        	$data['from'] = $filter1; $data['to'] = $filter2;
        	$data['category_filter'] = '';
        	$data['advisor_filter'] = '';
        	$data['service'] = '';
            $data['session_status_filter'] = '';
        	$data['filter'] = 1; 
    	}
        else if($filter == '3'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'category.id = "'.$filter1.'"';
            }
            $data['category_filter'] = $filter1;
            $data['advisor_filter'] = '';
            $data['service'] = '';
            $data['session_status_filter'] = '';
            $data['filter'] = 3;
        }else if($filter == '4'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.type = "'.$filter1.'"';
            }
            $data['category_filter'] = '';
            $data['advisor_filter'] = '';
            $data['session_status_filter'] = '';
            $data['service'] = $filter1;
            $data['filter'] = 4;
        }else if($filter == '5'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.status = "'.$filter1.'"';
            }
            $data['category_filter'] = '';
            $data['advisor_filter'] = '';
            $data['service'] = '';
            $data['session_status_filter'] = $filter1;
            $data['filter'] = 5;
        }else{
            $where = "1=1";
            $data['filter'] = 0;
            $data['from'] = ''; $data['to'] = ''; 
            $data['category_filter'] = '';
            $data['advisor_filter'] = '';
            $data['session_status_filter'] = '';
            $data['service'] = '';
        }

        $session_report->select('booking_request.*,advisor.full_name as advisor_name,customer.full_name as customer_name,category.name as category_name',false)
                        ->from('booking_request')
                        ->join('users as advisor','booking_request.advisor_id = advisor.id')
                        ->join('users as customer','booking_request.user_id = customer.id')
                        ->join('category', 'booking_request.category_id = category.id')
                        ->group_start()
                            ->group_start()
                                ->where('booking_request.status','1')
                                ->where('booking_request.end_time IS NOT NULL')
                                ->where('booking_request.is_session_running','1')
                                ->where($where)
                            ->group_end()
                            ->or_group_start()
                                ->where('booking_request.status','2')
                                //->where('booking_request.is_session_running','1')
                                ->where('booking_request.reject_call_detail','2')
                                ->where($where)
                            ->group_end()
                        ->group_end()
                        // ->where($where)
                        ->order_by('booking_request.id','DESC');

        // _pre($this->db->last_query());

        $action['delete'] = base_url('admin/payment/delete/');

        $session_report

            ->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

            ->column('#', 'id')

            ->column('Advisor Name', 'advisor_name')
                                                        
            ->column('Customer Name', 'customer_name')

            ->column('Session Type', 'type', function ($type) {
                return ucfirst($type);
            })

            ->column('Session Status', 'status', function ($status) {

                if($status == '0'){
                    $option = '<span class="badge badge-warning">Pending</span>';
                }else if($status == '2'){
                    $option = '<span class="badge badge-danger">Rejected</span>';
                }else{
                    $option = '<span class="badge badge-info">Completed</span>';
                }

                return $option;

            })

            ->column('Category', 'category_name')

            ->column('Total Amount', 'total', function ($total, $row) {
                return ($row['status'] == '1') ? $total : " - ";
            })

            ->column('Session Minute', 'session_minute', function ($session_minute, $row) {

                if($row['promocode_minute'] != 0){
                    $session_minute = $row['promocode_minute'];
                }

                return ($row['status'] == '1') ? $session_minute : " - ";
            })

            ->column('Booking Minute', 'minute', function ($minute) {
                return $minute." min"; 
            })

            ->column('Created On', 'created_at', function ($created_on) {

                return __date(strtotime( $created_on), true);

            })

            ->column('Action', 'id', function ($id, $row) use ($action) {


                $option = '<a href="javascript:void(0);" data-booking_id="'.$id.'" data-advisor_id="'.$row['advisor_id'].'" class="on-default payment_details_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Session Details" data-original-title="View payment details"><i class="la la-eye"></i></a>';

                return $option;

            });

        $set_options = "function ( row, data, start, end, display ) {
                            var api = this.api(), data;
                            // console.log(data);
                            // computing column Total of the rate result 
                            var Amount_total = api
                                .column( 6 , { page: 'current'} )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );
                           
                            $( api.column( 6 ).footer() ).html('Total = $'+Amount_total.toFixed(2));
                           
                        }";
        $session_report->set_options(['footerCallback' => $set_options]);

        $session_report->set_options(["columnDefs" => "[ { targets: [3], sortable: false}]","lengthMenu" => "[ [10, 25, 50,100, -1], [10, 25, 50,100,'All'] ]"]);

        $session_report->searchable('customer.full_name,advisor.full_name,booking_request.id');

        $session_report->datatable($this->table_name);

        $session_report->init();

        $data['datatable'] = true;

        $data['export'] = true;

        $data['export_columns'] = [0,1,2,3,4,5,6,7,8,9];

        $data['export_title'] = $this->title;

        $data['title'] = $this->title;

        $data['advisors'] = $this->db->select('users.full_name,users.id')
                            ->from('users')
                            ->join('users_groups ug', 'users.id = ug.user_id')
                            ->where('ug.group_id', $this->advisor_grp)
                            ->where('users.deleted_at', NULL)
                            ->order_by('users.id','DESC')
                            ->get()->result_array();

        $data['category'] = $this->db->select('name,id')->from('category')->where('deleted_at Is NULL AND status = 1')->get()->result_array();

        // $this->renderAdmin('report/advisor/index', $data);

    	$this->renderAdmin('report/index',$data);
    }

    public function advisor($filter = '',$filter1 = '',$filter2 = ''){

    	if($filter == '1' || $filter == 1 && $filter1 != '' && $filter2 != ''){
    		$From = $filter1." 00:00:00";
        	$To = $filter2." 23:59:59";
        	$where = 'booking_request.created_at BETWEEN "'.$From.'" AND "'.$To.'"';
        	$data['from'] = $filter1; $data['to'] = $filter2;
        	$data['category_filter'] = '';
        	$data['advisor_filter'] = '';
        	$data['service'] = '';
        	$data['filter'] = 1; 
    	}
    	else if($filter == 2 && $filter1 != ''){
    		if($filter1 == 'all'){
    			$where = "1=1";
    		}else{
    			$where = 'booking_request.advisor_id = "'.$filter1.'"';
    		}
    		$data['from'] = ''; $data['to'] = ''; 
    		$data['advisor_filter'] = $filter1;
    		$data['category_filter'] = '';
    		$data['service'] = '';
        	$data['filter'] = 2;
    	}
    	else if($filter == 3 && $filter1 != ''){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'category.id = "'.$filter1.'"';
            }
        	$data['from'] = ''; $data['to'] = ''; 
        	$data['category_filter'] = $filter1;
        	$data['advisor_filter'] = '';
        	$data['service'] = '';
        	$data['filter'] = 3;
    	}
    	else if($filter == 4 && $filter1 != ''){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.type = "'.$filter1.'"';
            }
        	$data['from'] = ''; $data['to'] = ''; 
        	$data['category_filter'] = '';
        	$data['advisor_filter'] = '';
        	$data['service'] = $filter1;
        	$data['filter'] = 4;
    	}
    	else{
    		$where = "1=1";
        	$data['filter'] = 0;
        	$data['from'] = ''; $data['to'] = ''; 
        	$data['category_filter'] = '';
        	$data['advisor_filter'] = '';
        	$data['service'] = '';
    	}

    	$this->load->library('Datatables');

    	$advisor_report = new Datatables;

    	$advisor_report->select('booking_request.*,advisor.full_name as advisor_name,customer.full_name as customer_name,category.name as category_name',false)
    					->from('booking_request')
    					->join('users as advisor','booking_request.advisor_id = advisor.id')
    					->join('users as customer','booking_request.user_id = customer.id')
    					->join('category', 'booking_request.category_id = category.id')
    					->where('booking_request.end_time IS NOT NULL')
                        ->where('booking_request.is_session_running','1')
                        ->where('booking_request.status','1')
    					->where($where)
    					->order_by('booking_request.id','DESC');

    	$action['delete'] = base_url('admin/payment/delete/');

    	$advisor_report

			->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Advisor Name', 'advisor_name')
                                                        
			->column('Customer Name', 'customer_name')

			->column('Session Type', 'type')

			->column('Category', 'category_name')

			->column('Advisor Commison ($)', 'advisor_commission')

            ->column('Created On', 'created_at', function ($created_on) {

                return __date(strtotime( $created_on), true);

            })

			->column('Action', 'id', function ($id, $row) use ($action) {


        		$option = '<a href="javascript:void(0);" data-booking_id="'.$id.'" data-advisor_id="'.$row['advisor_id'].'" class="on-default payment_details_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Session Details" data-original-title="View payment details"><i class="la la-eye"></i></a>';

				return $option;

			});

		$set_options = "function ( row, data, start, end, display ) {
                            var api = this.api(), data;
                            // console.log(data);
                            // computing column Total of the rate result 
                            var Amount_total = api
                                .column( 5 , { page: 'current'} )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );
                           
                            $( api.column( 5 ).footer() ).html('Total = $'+Amount_total.toFixed(2));
                           
                        }";
        $advisor_report->set_options(['footerCallback' => $set_options]);

        $advisor_report->set_options(["columnDefs" => "[ { targets: [3], sortable: false}]","lengthMenu" => "[ [10, 25, 50,100, -1], [10, 25, 50,100,'All'] ]"]);

        $advisor_report->searchable('customer.full_name,advisor.full_name,booking_request.id');

		$advisor_report->datatable($this->table_name);

		$advisor_report->init();

		$data['datatable'] = true;

        $data['export'] = true;

		$data['export_columns'] = [0,1,2,3,4,5,6];

        $data['export_title'] = $this->title;

        $data['title'] = $this->title;

        $data['advisors'] = $this->db->select('users.full_name,users.id')
        					->from('users')
        					->join('users_groups ug', 'users.id = ug.user_id')
                			->where('ug.group_id', $this->advisor_grp)
                			->where('users.deleted_at', NULL)
                			->order_by('users.id','DESC')
        					->get()->result_array();

       	$data['category'] = $this->db->select('name,id')->from('category')->where('deleted_at Is NULL AND status = 1')->get()->result_array();

		$this->renderAdmin('report/advisor/index', $data);

    	// _pre($query);
    }

    public function customer($filter = '',$filter1 = '',$filter2 = ''){

        if($filter == '1' || $filter == 1 && $filter1 != '' && $filter2 != ''){
            $From = $filter1." 00:00:00";
            $To = $filter2." 23:59:59";
            $where = 'booking_request.created_at BETWEEN "'.$From.'" AND "'.$To.'"';
            $data['from'] = $filter1; $data['to'] = $filter2;
            $data['category_filter'] = '';
            $data['customer_filter'] = '';
            $data['service'] = '';
            $data['filter'] = 1; 
        }
        else if($filter == 2 && $filter1 != ''){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.user_id = "'.$filter1.'"';
            }
            $data['from'] = ''; $data['to'] = ''; 
            $data['customer_filter'] = $filter1;
            $data['category_filter'] = '';
            $data['service'] = '';
            $data['filter'] = 2;
        }
        else if($filter == 3 && $filter1 != ''){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'category.id = "'.$filter1.'"';
            }
            $data['from'] = ''; $data['to'] = ''; 
            $data['category_filter'] = $filter1;
            $data['customer_filter'] = '';
            $data['service'] = '';
            $data['filter'] = 3;
        }
        else if($filter == 4 && $filter1 != ''){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.type = "'.$filter1.'"';
            }
            $data['from'] = ''; $data['to'] = ''; 
            $data['category_filter'] = '';
            $data['customer_filter'] = '';
            $data['service'] = $filter1;
            $data['filter'] = 4;
        }
        else{
            $where = "1=1";
            $data['filter'] = 0;
            $data['from'] = ''; $data['to'] = ''; 
            $data['category_filter'] = '';
            $data['customer_filter'] = '';
            $data['service'] = '';
        }

        $this->load->library('Datatables');

        $advisor_report = new Datatables;

        $advisor_report->select('booking_request.*,advisor.full_name as advisor_name,customer.full_name as customer_name,category.name as category_name',false)
                        ->from('booking_request')
                        ->join('users as advisor','booking_request.advisor_id = advisor.id')
                        ->join('users as customer','booking_request.user_id = customer.id')
                        ->join('category', 'booking_request.category_id = category.id')
                        ->where('booking_request.end_time IS NOT NULL')
                        ->where('booking_request.is_session_running','1')
                        ->where('booking_request.status','1')
                        ->where($where)
                        ->order_by('booking_request.id','DESC');

        $action['delete'] = base_url('admin/payment/delete/');

        $advisor_report

            ->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

            ->column('#', 'id')

            ->column('Customer Name', 'customer_name')

            ->column('Advisor Name', 'advisor_name')
                                                        
            ->column('Session Type', 'type')

            ->column('Category', 'category_name')

            ->column('Total Amount ($)', 'total')

            ->column('Revenue ($)', 'admin_commission')

            ->column('Created On', 'created_at', function ($created_on) {

                return __date(strtotime( $created_on), true);

            })

            ->column('Action', 'id', function ($id, $row) use ($action) {


                $option = '<a href="javascript:void(0);" data-booking_id="'.$id.'" data-advisor_id="'.$row['advisor_id'].'" class="on-default payment_details_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Session Details" data-original-title="View payment details"><i class="la la-eye"></i></a>';

                return $option;

            });

        $set_options = "function ( row, data, start, end, display ) {
                            var api = this.api(), data;
                            // console.log(data);
                            // computing column Total of the rate result 
                            var Amount_total = api
                                .column( 5 , { page: 'current'} )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );
                            var Admin_total = api
                                .column( 6 , { page: 'current'}  )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );
                           
                            $( api.column( 5 ).footer() ).html('Total = $'+Amount_total.toFixed(2));
                            $( api.column( 6 ).footer() ).html('Total = $'+Admin_total.toFixed(2));
                           
                        }";
        $advisor_report->set_options(['footerCallback' => $set_options]);

        $advisor_report->set_options(["columnDefs" => "[ { targets: [3], sortable: false}]","lengthMenu" => "[ [10, 25, 50,100, -1], [10, 25, 50,100,'All'] ]"]);

        $advisor_report->searchable('customer.full_name,advisor.full_name,booking_request.id');

        $advisor_report->datatable($this->table_name);

        $advisor_report->init();

        $data['datatable'] = true;

        $data['export'] = true;

        $data['export_columns'] = [0,1,2,3,4,5,6,7];

        $data['export_title'] = $this->title;

        $data['title'] = $this->title;

        $data['customers'] = $this->db->select('users.full_name,users.id')
                            ->from('users')
                            ->join('users_groups ug', 'users.id = ug.user_id')
                            ->where('ug.group_id', $this->customer_grp)
                            ->where('users.deleted_at', NULL)
                            ->order_by('users.id','DESC')
                            ->get()->result_array();

        $data['category'] = $this->db->select('name,id')->from('category')->where('deleted_at Is NULL AND status = 1')->get()->result_array();

        $this->renderAdmin('report/customer/index', $data);

        // _pre($query);
    }

    public function revenue($filter = '',$filter1 = '',$filter2 = '')
    {
    	$data['title'] = $this->title;

        $this->load->library('Datatables');

        $session_report = new Datatables;

        if($filter == '1' || $filter == 1 && $filter1 != '' && $filter2 != ''){
            // echo "<pre>";
            $filter1_split = explode("T", $filter1);
            $filter2_split = explode("T", $filter2);
    		$From = $filter1_split[0]." ".$filter1_split[1].":00";
        	$To = $filter2_split[0]." ".$filter2_split[1].":00";
        	$where = 'booking_request.created_at BETWEEN "'.$From.'" AND "'.$To.'"';
        	$data['from'] = $filter1; $data['to'] = $filter2;
        	$data['category_filter'] = '';
        	$data['advisor_filter'] = '';
        	$data['service'] = '';
            $data['session_status_filter'] = '';
        	$data['filter'] = 1; 
    	}
        else if($filter == '3'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'category.id = "'.$filter1.'"';
            }
            $data['category_filter'] = $filter1;
            $data['advisor_filter'] = '';
            $data['service'] = '';
            $data['session_status_filter'] = '';
            $data['filter'] = 3;
        }else if($filter == '4'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.type = "'.$filter1.'"';
            }
            $data['category_filter'] = '';
            $data['advisor_filter'] = '';
            $data['session_status_filter'] = '';
            $data['service'] = $filter1;
            $data['filter'] = 4;
        }else if($filter == '5'){
            if($filter1 == 'all'){
                $where = "1=1";
            }else{
                $where = 'booking_request.status = "'.$filter1.'"';
            }
            $data['category_filter'] = '';
            $data['advisor_filter'] = '';
            $data['service'] = '';
            $data['session_status_filter'] = $filter1;
            $data['filter'] = 5;
        }else{
            $where = "1=1";
            $data['filter'] = 0;
            $data['from'] = ''; $data['to'] = ''; 
            $data['category_filter'] = '';
            $data['advisor_filter'] = '';
            $data['session_status_filter'] = '';
            $data['service'] = '';
        }
        // _pre($where);
        $session_report->select('booking_request.*,advisor.full_name as advisor_name,customer.full_name as customer_name,category.name as category_name',false)
                        ->from('booking_request')
                        ->join('users as advisor','booking_request.advisor_id = advisor.id')
                        ->join('users as customer','booking_request.user_id = customer.id')
                        ->join('category', 'booking_request.category_id = category.id')
                        ->where('booking_request.status','1')
                        ->where('booking_request.is_session_running','1')
                        ->where('booking_request.end_time IS NOT NULL')
                        ->where($where)
                        ->order_by('booking_request.id','DESC');

        // _pre($this->db->last_query());

        $action['delete'] = base_url('admin/payment/delete/');

        $session_report

            ->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

            ->column('#', 'id')

            ->column('Advisor Name', 'advisor_name')
                                                        
            ->column('Customer Name', 'customer_name')

            ->column('Session Type', 'type', function ($type) {
                return ucfirst($type);
            })

            // ->column('Session Status', 'status', function ($status) {

            //     if($status == '0'){
            //         $option = '<span class="badge badge-warning">Pending</span>';
            //     }else if($status == '2'){
            //         $option = '<span class="badge badge-danger">Rejected</span>';
            //     }else{
            //         $option = '<span class="badge badge-info">Completed</span>';
            //     }

            //     return $option;

            // })

            ->column('Category', 'category_name')

            ->column('Total Amount($)', 'total', function ($total, $row) {
                return ($row['total'] != '') ? $total : " - ";
            })

            ->column('Advisor Amount($)', 'advisor_commission', function ($advisor_commission, $row) {
                return ($row['advisor_commission'] != '') ? $advisor_commission : " - ";
            })

            ->column('Admin Amount($)', 'admin_commission', function ($admin_commission, $row) {
                return ($row['admin_commission'] != '') ? $admin_commission : " - ";
            })

            ->column('Session Minute', 'session_minute', function ($session_minute, $row) {

                if($row['promocode_minute'] != 0){
                    $session_minute = $row['promocode_minute'];
                }

                return ($row['status'] == '1') ? $session_minute : " - ";
            })

            // ->column('Booking Minute', 'minute', function ($minute) {
            //     return $minute." min"; 
            // })

            ->column('Created On', 'created_at', function ($created_on) {

                return __date(strtotime( $created_on), true);

            })

            ->column('Action', 'id', function ($id, $row) use ($action) {


                $option = '<a href="javascript:void(0);" data-booking_id="'.$id.'" data-advisor_id="'.$row['advisor_id'].'" class="on-default payment_details_modal text-secondary" data-toggle="tooltip" data-placement="bottom" title="View Session Details" data-original-title="View payment details"><i class="la la-eye"></i></a>';

                return $option;

            });

        $set_options = "function ( row, data, start, end, display ) {
                            var api = this.api(), data;
                            // console.log(data);
                            // computing column Total of the rate result 
                            var Amount_total = api
                                .column( 5 , { page: 'current'} )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );
                            var Advisor_total = api
                                .column( 6 , { page: 'current'}  )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );
                            var Admin_total = api
                                .column( 7 , { page: 'current'}  )
                                .data()
                                .reduce( function (a, b) {
                                    var a = parseFloat(a) || 0;
                                    var b = parseFloat(b) || 0;
                                    return a + b;
                                }, 0 );    
                           
                            $( api.column( 5 ).footer() ).html('Total = $'+Amount_total.toFixed(2));
                            $( api.column( 6 ).footer() ).html('Total = $'+Advisor_total.toFixed(2));
                            $( api.column( 7 ).footer() ).html('Revenue = $'+Admin_total.toFixed(2));
                           
                        }";
        $session_report->set_options(['footerCallback' => $set_options]);

        $session_report->set_options(["columnDefs" => "[ { targets: [3], sortable: false}]","lengthMenu" => "[ [10, 25, 50,100, -1], [10, 25, 50,100,'All'] ]"]);

        $session_report->searchable('customer.full_name,advisor.full_name,booking_request.id');

        $session_report->datatable($this->table_name);

        $session_report->init();

        $data['datatable'] = true;

        $data['export'] = true;

        $data['export_columns'] = [0,1,2,3,4,5,6,7,8,9];

        $data['export_title'] = $this->title;

        $data['title'] = $this->title;

        $data['advisors'] = $this->db->select('users.full_name,users.id')
                            ->from('users')
                            ->join('users_groups ug', 'users.id = ug.user_id')
                            ->where('ug.group_id', $this->advisor_grp)
                            ->where('users.deleted_at', NULL)
                            ->order_by('users.id','DESC')
                            ->get()->result_array();

        $data['category'] = $this->db->select('name,id')->from('category')->where('deleted_at Is NULL AND status = 1')->get()->result_array();

        // $this->renderAdmin('report/advisor/index', $data);

    	$this->renderAdmin('report/revenue/index',$data);
    }
}
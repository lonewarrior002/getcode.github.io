<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TestimonialController extends MY_Controller {
	protected $title;
	
	function __construct() {
		parent::__construct();
		
		if (!$this->ion_auth->is_admin()) {
			redirect('admin/login');
		}
		$this->title = 'Testimonials';
        $this->login_user_id = $this->session->userdata()['admin']['user_id'];
        $this->table_name = 'testimonials';
        $this->customer_grp   = $this->config->item('roles', 'ion_auth')['customer'];
        $this->service_provider_grp  = $this->config->item('roles', 'ion_auth')['service_provider'];
	}

    public function index() {

        $this->load->library('Datatables');

        $patient = new Datatables;

		$patient->select('t.*,users.full_name as customer_name', false)->from($this->table_name.' t')

                ->join('users', 't.user_id = users.id')

                ->where('t.deleted_at', NULL)->limit(3);



		$action['edit'] = base_url('admin/testimonial/edit/');

		$action['delete'] = base_url('admin/testimonial/delete/');



		$patient

			->style(['class' => 'table table-striped table-bordered nowrap dt-responsive'])

			->column('#', 'id')

			->column('Name', 'customer_name')

			->column('Review', 'review')

            ->column('Created On', 'created_at', function ($created_on) {

                return __date(strtotime($created_on), true);

            })

			// ->column('Status', 'status', function($active, $row) {

            //     if ($active == 1) {

			// 		return '<h5 class="mb-0 mt-0"><span onclick="fun_change_state(this);" class="badge badge-success cursor-pointer font-15 status_' . $row['id'] . '" data-table="testimonials" data-id="' . $row['id'] . '">Active</span></h5>';

			// 	} else {


			// 		return '<h5 class="mb-0 mt-0"><span onclick="fun_change_state(this);" class="badge badge-danger cursor-pointer font-15 status_' . $row['id'] . '" data-table="testimonials" data-id="' . $row['id'] . '">Inactive</span></h5>';

            //     }

            // })

            // ->column('Action', 'id', function ($id) use ($action) {

            	

            //     return '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" data-toggle="tooltip" data-placement="bottom" title="" data-original-title = "Edit Field"><i class="la la-pencil-square "></i></a>';

            // });

			->column('Actions', 'id', function ($id) use ($action) {

				$option = '<a href="' . $action['edit'] . $id . '" class="on-default text-secondary" title="Edit"><i class="la la-pencil-square "></i></a>';

				$option .= '<a data-href="' . $action['delete'] . $id . '" href="javascript:void(0);" onclick="delete_confirm(this);"  class="on-default text-danger confirm_model" data-toggle="tooltip" data-placement="bottom" title="Delete" data-original-title = "Delete Field" data-rediret-url="'.current_url().'"  data-table="'.$this->table_name.'" data-href="testimonials"><i class="la la-times-circle"></i></a>';

				return $option;

			});

            

        $patient->set_options(["columnDefs" => "[ { targets: [4], sortable: false}]"]);

        $patient->searchable('u.id,u.full_name, u.email, u.phone');

		$patient->datatable($this->table_name);

		$patient->init();

		$data['datatable'] = true;

        $data['export'] = true;

		$data['export_columns'] = [0,1,2,3];

        $data['export_title'] = $this->title;

        $data['add_url'] = base_url('admin/testimonial/add');

        $data['testimonials'] = $this->db->select('id')->from('testimonials')->where('status',1)->where('deleted_at IS NULL')->get()->result_array();

        $data['title'] = $this->title;

		$this->renderAdmin('testimonial/index', $data);

    }

    public function add(){

		$current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

            $request = $this->input->post();

            $create_testimonial = [

                'user_id'   => $request['user_id'],

                'user_type'   => $request['user_type'],

                'review'   => $request['review'],

                'created_at'   => $current_date

            ];

            $this->comman->insert_record($this->table_name, $create_testimonial);

            $this->session->set_flashdata('success', 'Testimonial added sucessfully');

            redirect('admin/testimonial');

            // _pre($create_testimonial);
        }

        $data['title'] = 'Add '.$this->title;

        $this->renderAdmin('testimonial/add',$data);
    }

    public function edit($id = ''){

        $testimonial = $this->comman->get_record_byid('testimonials',$id);

        $current_date = current_date();

        if (isset($_POST) && !empty($_POST)) {

            $request = $this->input->post();

            $edit_testimonial = [

                'user_id'   => $request['user_id'],

                'user_type'   => $request['user_type'],

                'review'   => $request['review'],

                'updated_at'   => $current_date

            ];

            $this->comman->update_record($this->table_name, $edit_testimonial,$id);

            $this->session->set_flashdata('success', 'Testimonial edited sucessfully');

            redirect('admin/testimonial');

            // _pre($_POST);

        }

        $data['title'] = 'Edit '.$this->title;

        $data['testimonial'] = $testimonial;

        $this->renderAdmin('testimonial/edit',$data);

    }

    public function get_dropdown_data(){

    	$user_type=$this->input->post('user_type');

    	if($user_type == 'customer'){

    		$data=$this->db->select('u.id,u.full_name,ug.group_id', false)->from('users as u')

              ->join('users_groups ug', 'u.id = ug.user_id')

              ->where('ug.group_id', $this->customer_grp)

              ->where('u.active',1)
                                                            
              ->order_by('u.id', 'desc')

              ->get()->result_array();

    	}
    	else if($user_type == 'advisor'){

    		$data=$this->db->select('u.id,u.full_name,ug.group_id', false)->from('users as u')

              ->join('users_groups ug', 'u.id = ug.user_id')

              ->where('ug.group_id', $this->service_provider_grp)

              ->where('u.active',1)
                                                            
              ->order_by('u.id', 'desc')

              ->get()->result_array();
    	} else {

    		$data = $this->comman->get_all_record('users','full_name');

    	}

    	// _pre($data);

        echo json_encode($data);
    }

    public function delete($id) {
        $this->comman->update_record($this->table_name, ['deleted_at' => current_date()], $id);
        echo 1;
    }

}
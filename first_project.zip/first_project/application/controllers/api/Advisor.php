<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Advisor extends REST_Controller {

    function __construct() {

        header('Access-Control-Allow-Origin: *');

        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

        parent::__construct();

        $this->load->model('ion_auth_model');

    }

    public function init_get($app_version = '',$type = '', $user_id = '') {

        if(isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {              

            $auth = validate_key($_SERVER['HTTP_KEY']); 

            if($auth) {

                $postFields['app_version'] = $app_version;        

                $postFields['type'] = $type;               

                $errorPost = ValidatePostFields($postFields);

                if(empty($errorPost)) {

                    $update['app_version'] = $app_version;
                    $where = array('id' => $user_id);
                    $this->db->update('users',$update,$where);

                    $MaintenanceMode = (array)$this->db->get_where('appsetting',array('app_name' => 'maintenance_mode'))->row();

                    $AppVersion = (array)$this->db->get_where('appsetting',array('app_name' => $type))->row();

                    $current_version = (Int)str_replace('.', '',$AppVersion['app_version']);

                    $app_version = (Int)str_replace('.', '', $app_version);

                    if($MaintenanceMode['updates'] == 1) {

                        $response['status'] = FALSE;

                        $response['update'] = FALSE;

                        $response['maintenance'] = TRUE;

                        $response['message'] = 'Server under maintenance, please try again after some time';

                    } else if($app_version < $current_version && $AppVersion['updates'] == 0) {

                        $response['status'] = TRUE;

                        $response['update'] = FALSE;

                        $response['message'] = SITENAME.' app new version available';
                        
                        $response['category_count'] = $this->comman->get_record_by_condition('settings', ['name' => 'category_count'], 'value')[0]['value'];
                        
                        $response['device_token'] = '';
                        if(!empty($user_id)) {
                            $profile = $this->comman->get_record_byid('users', $user_id, 'device_token');
                            $response['device_token'] = $profile['device_token'];
                        }
                        
                        $response['current_time'] = current_date();

                    } else if($app_version < $current_version && $AppVersion['updates'] == 1) {

                        $response['status'] = FALSE;

                        $response['update'] = TRUE;

                        $response['message'] = SITENAME.' app new version available, please upgrade your application';

                    } else {

                        $response['status'] = TRUE;
                        
                        $response['category_count'] = $this->comman->get_record_by_condition('settings', ['name' => 'category_count'], 'value')[0]['value'];
                        
                        $response['device_token'] = '';
                        if(!empty($user_id)) {
                            $profile = $this->comman->get_record_byid('users', $user_id, 'device_token');
                            $response['device_token'] = $profile['device_token'];
                        }
                        
                        $response['current_time'] = current_date();
                        
                    }

                    

                } else {

                    $response['status'] = FALSE;

                    $response['message'] = $errorPost;

                }

            } else {

                $response['status'] = FALSE;

                $response['message'] = 'Authorization failed';

            }

            

        } else {

            $response['status'] = FALSE;

            $response['message'] = 'Authorization key is required';

        }

        

        $this->response($response);

    }
    
    public function set_post_register_detail_post() {
        
        $this->form_validation->set_rules('user_id', 'user id', 'required|trim');
        
        $this->form_validation->set_rules('availability', 'availability', 'required|trim');
        
        $this->form_validation->set_rules('account_detail', 'account detail', 'required|trim');
        
        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $data['status'] = TRUE;
            
            $request = $this->post();
            
            $availability_arr = json_decode($request['availability'], true);

            $insert_arr = [];

            $current_date = current_date();
            
            $category_ids = [];
            $price_change_log = [];
            $availability = [];
            foreach ($availability_arr as $key => $value) {
                $insert_arr[$key] = $value;
                $insert_arr[$key]['user_id']    = $request['user_id'];
                $insert_arr[$key]['created_at'] = $current_date;
                $category_ids[] = $value['category_id'];
                
                $price_change_log[$key]['user_id']             = $request['user_id'];
                $price_change_log[$key]['current_category_id'] = 0;
                $price_change_log[$key]['new_category_id']     = $value['category_id'];
                $price_change_log[$key]['type']                = $value['type'];
                $price_change_log[$key]['current_price']       = 0;
                $price_change_log[$key]['new_price']           = $value['price'];
                $price_change_log[$key]['created_at']          = $current_date;
                
                $availability[$key]['category_id'] = $value['category_id'];
                $availability[$key]['type']        = $value['type'];
                $availability[$key]['price']       = $value['price'];
                $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));
            }
            $this->db->insert_batch('availability', $insert_arr);
            $this->db->insert_batch('price_change_log', $price_change_log);
            
            $this->comman->insert_record('advisor_payment_detail', ['user_id' => $request['user_id'], 'account_detail' => $request['account_detail'], 'created_at' => $current_date ]);
            
            $this->comman->update_record('users', ['category_id' => implode(',', array_unique($category_ids))], $request['user_id']);
            
            $data['profile'] = $this->comman->get_record_byid('users', $request['user_id']);
            $data['profile']['api_key'] = $this->db->get_where('tokens', array('user_id' => $request['user_id']))->row()->token;
            $data['availability'] = $availability;
            
            $data['message'] = 'Your request to become an advisor is under approval with admin';
        }
        $this->response($data);
    }

    public function profile_update_post(){

        $this->form_validation->set_rules('user_id', 'user_id', 'required|trim');

        $this->form_validation->set_rules('full_name', 'full name', 'required|trim');        
        
        $this->form_validation->set_rules('nick_name', 'nick name', 'required|trim');        

//        $this->form_validation->set_rules('email', 'email', 'required|trim|callback_isexists[' . $this->post('user_id') . ']');        
//
//        $this->form_validation->set_rules('phone', 'phone', 'required|trim|callback_isexists[' . $this->post('user_id') . ']');
        
        $this->form_validation->set_rules('advisor_description', 'advisor description', 'required|trim');
        
        $this->form_validation->set_rules('is_change_availability', 'is change availability', 'required|trim|in_list[0,1]');
        
        $this->form_validation->set_rules('availability', 'availability', 'trim');
        
        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();
            
            $current_date = current_date();
            
                $user_data = array(

                    'full_name'    => $request['full_name'],               

                    'nick_name'    => $request['nick_name'],               

    //                'email'        => $request['email'],               
    //
    //                'phone'        => $request['phone'],

                    //'advisor_description' => $request['advisor_description'],

                    'updated_at'   => $current_date

                );

                $get_user_detail = $this->comman->get_record_byid('users', $request['user_id'], 'nick_name,advisor_description,profile_picture,category_id');
                
                if(!empty($request['is_change'])) {
                	$fields = array('advisor_description','profile_picture','nick_name');
                	$params = explode(',', $request['is_change']);
                	$field_available = array_intersect($fields,$params);
                	if(count($field_available)){
                    	$user_data['approve_advisor_detail'] = STATUS_INACTIVE;
                    	$data['message'] = 'Profile updated successfully. Please wait for admin approval.';
                    } else {
                        $data['message'] = 'Profile updated successfully.';
                    }
                    $user_data['change_params'] = $request['is_change'];
                }

                // if(isset($request['remove_image']) && $request['remove_image'] == 1) {

                //     $update_data['profile_picture'] = '';
                //     // $get_user_detail = $this->comman->get_record_byid('users', $request['user_id'], 'profile_picture');
                //     @unlink(FCPATH.$get_user_detail['profile_picture']);

                // } 

                if (isset($_FILES['profile_picture']) && !empty($_FILES['profile_picture'])) {

                    $image_is_uploaded = image_upload('profile_picture', 'images/users/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG', '5000');

                    if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                       $update_data['profile_picture'] = $image_is_uploaded['uploaded_path'];

                    }  else if( isset($image_is_uploaded['error']) ) {

                       $data['status'] = FALSE;

                       $data['message'] = ucfirst($image_is_uploaded['error']);

                       $this->response($data);

                       die();

                    }

                }
                $availability = [];
                if($request['is_change_availability']) {

                    if(!isset($request['availability']) || !count(json_decode($request['availability'], true)) ) {
                        $data['status'] = FALSE;

                        $data['message'] = 'Availability field is required';

                        $this->response($data);

                        die();
                    } else {
                        $existing_category_ids = $this->comman->get_record_byid('users', $request['user_id'], 'category_id')['category_id'];
                        $existing_category_ids = explode(',', $existing_category_ids);

                        $availability_arr = json_decode($request['availability'], true);
                        $current_category_ids = array_unique(array_column($availability_arr,'current_category_id'));

                        if(count($existing_category_ids) != count($current_category_ids) && count($existing_category_ids) > count($current_category_ids)) {
                            $remove_category_ids = array_diff($existing_category_ids, $current_category_ids);
                            $this->db->where('user_id', $request['user_id'])->where_in('category_id',$remove_category_ids)->delete('availability');
                            $this->db->where('user_id', $request['user_id'])
                                ->where_in('current_category_id',$remove_category_ids)
                                ->or_group_start()
                                ->where('current_category_id',0)
                                ->where_in('new_category_id',$remove_category_ids)
                                ->group_end()
                                ->delete('price_change_log');
                        } 
                        $insert_arr   = [];
                        $update_arr   = [];

                        $category_ids = [];
                        $price_change_log = [];
                        foreach ($availability_arr as $key => $value) {
                            if(empty($value['current_category_id']) || $value['current_category_id'] == '0') {
                                $insert_arr[$key]['user_id']     = $request['user_id'];
                                $insert_arr[$key]['category_id'] = $value['new_category_id'];
                                $insert_arr[$key]['type']        = $value['type'];
                                $insert_arr[$key]['price']       = $value['new_price'];
                                $insert_arr[$key]['created_at']  = $current_date;
                            } else if( ($value['current_category_id'] != $value['new_category_id']) || ($value['current_price'] != $value['new_price']) ) {
                                $update_arr[$key]['user_id']     = $request['user_id'];
                                $update_arr[$key]['category_id'] = $value['new_category_id'];
                                $update_arr[$key]['type']        = $value['type'];
                                $update_arr[$key]['price']       = $value['new_price'];
                                $update_arr[$key]['updated_at']  = $current_date;

                                $existing_record = $this->db->select('id')->from('availability')->where('user_id', $request['user_id'])->where('category_id', $value['current_category_id'])->where('type', $value['type'])->get()->row_array();
                                $update_arr[$key]['id']  = $existing_record['id'];
                            }

                            $category_ids[] = $value['new_category_id'];

                            $availability[$key]['category_id'] = $value['new_category_id'];
                            $availability[$key]['type']        = $value['type'];
                            $availability[$key]['price']       = $value['new_price'];
                            $availability[$key]['last_updated_date'] = $value['last_updated_date'];

                            if( $value['current_price'] != $value['new_price'] ) {
                                $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));

                                $price_change_log[$key]['user_id']             = $request['user_id'];
                                $price_change_log[$key]['current_category_id'] = $value['current_category_id'];
                                $price_change_log[$key]['new_category_id']     = $value['new_category_id'];
                                $price_change_log[$key]['type']                = $value['type'];
                                $price_change_log[$key]['current_price']       = $value['current_price'];
                                $price_change_log[$key]['new_price']           = $value['new_price'];
                                $price_change_log[$key]['created_at']          = $current_date;
                            } else if(isset($update_arr[$key])) {
                                $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));

                                $price_change_log[$key]['user_id']             = $request['user_id'];
                                $price_change_log[$key]['current_category_id'] = $value['current_category_id'];
                                $price_change_log[$key]['new_category_id']     = $value['new_category_id'];
                                $price_change_log[$key]['type']                = $value['type'];
                                $price_change_log[$key]['current_price']       = $value['current_price'];
                                $price_change_log[$key]['new_price']           = $value['new_price'];
                                $price_change_log[$key]['created_at']          = $current_date;
                            }

                        }
    //                    echo '<pre>';
    //                    echo '-------------$update_arr-------------------';
    //                    print_r($update_arr);
    //                    echo '-------------$insert_arr-------------------';
    //                    print_r($insert_arr);
    //                    echo '------------$price_change_log-----------------';
    //                    print_r($price_change_log);
    //                    die();
                        if(count($update_arr)) {
                            $this->db->update_batch('availability', $update_arr, 'id');
                        }
                        if(count($insert_arr)) {
                            $this->db->insert_batch('availability', $insert_arr);
                        }
                        if(count($price_change_log)) {
                            $this->db->insert_batch('price_change_log', $price_change_log);
                        }

                        $user_data['category_id'] = implode(',', array_unique($category_ids));
                    }
                } else {
                    $availability_arr = json_decode($request['availability'], true);
                    foreach ($availability_arr as $key => $value) {
                        $availability[$key]['category_id'] = $value['new_category_id'];
                        $availability[$key]['type']        = $value['type'];
                        $availability[$key]['price']       = $value['new_price'];
                        $availability[$key]['last_updated_date'] = $value['last_updated_date'];
                    }
                }


                $change_fields = explode(',', $request['is_change']);

                if(!empty(array_filter($change_fields))){

                    // if(in_array('nick_name',$change_fields)){

                    //     $update_log[0]['user_id'] = $request['user_id'];
                    //     $update_log[0]['field_name'] = 'nick_name';
                    //     $update_log[0]['old_value'] = $get_user_detail['nick_name'];
                    //     $update_log[0]['new_value'] = $request['nick_name'];
                    //     $update_log[0]['status'] = 0;
                    //     $update_log[0]['created_at'] = $current_date;
                    // }
                	$update_log = array();
                    $profile_picture = 0;
                    $advisor_description = 0;
                    if(in_array('advisor_description',$change_fields)){
                         
                        $update_log[0]['user_id'] = $request['user_id'];   
                        $update_log[0]['field_name'] = 'advisor_description';
                        $update_log[0]['old_value'] = $get_user_detail['advisor_description'];
                        $update_log[0]['new_value'] = $request['advisor_description'];
                        $update_log[0]['status'] = 0;
                        $update_log[0]['created_at'] = $current_date;

                        $advisor_description = 1;
                    }

                    if(in_array('profile_picture',$change_fields)){
                        $update_log[1]['user_id'] = $request['user_id'];    
                        $update_log[1]['field_name'] = 'profile_picture';
                        $update_log[1]['old_value'] = $get_user_detail['profile_picture'];
                        $update_log[1]['new_value'] = $update_data['profile_picture'];
                        $update_log[1]['status'] = 0;
                        $update_log[1]['created_at'] = $current_date;

                        $profile_picture = 1;
                    }

                    if(!empty($update_log) && count($update_log)){

                        $update_log = array_values($update_log);
                        $this->db->insert_batch('profile_update_log', $update_log);

                        ($get_user_detail['profile_picture'] != '') ? $old_image = "<img src='".base_url($get_user_detail['profile_picture'])."' style='height: 90px; object-fit: cover;'>" : $old_image = '-';

                        ($update_data['profile_picture'] != '' && $profile_picture == 1) ? $new_image = "<img src='".base_url($update_data['profile_picture'])."' style='height: 90px; object-fit: cover;'>" : $new_image = '-';

                        $html = '';
                        $html .= "<table class='o_block' border='1' width='100%' cellspacing='0' cellpadding='0' border='0' role='presentation' style='max-width: 632px;margin: 0 auto;background-color: #ffffff;'>
                                    <tbody>
                                        <tr style='color:#424651;'>
                                            <th align=center style='padding: 1%;'> <b>FIELD NAME</b></td>
                                            <th align=center style='padding: 1%;'><b>OLD VALUE</b></td>
                                            <th align=center style='padding: 1%;'><b>NEW VALUE</b></td>
                                        </tr>";

                        if($advisor_description == 1){
                            $html .= "<tr>";
                            $html .=  "<td align=left style='padding: 1% 1% 1% 4%;'>Advisor Description</td>";
                            $html .=  "<td align=center>".$get_user_detail['advisor_description']."</td>";
                            $html .=  "<td align=center style='padding: 1% 1% 1% 4%;'>".$request['advisor_description']."</td>";
                            $html .=  "</tr>";
                        }
                        
                        if($profile_picture == 1){
                            $html .= "<tr>";
                            $html .=  "<td align=left style='padding: 1% 1% 1% 4%;'>Profile Picture</td>";
                            $html .=  "<td align=center>".$old_image."</td>";
                            $html .=  "<td align=center style='padding: 1% 1% 1% 4%;'>".$new_image."</td>";
                            $html .=  "</tr>";
                        }

                        $html .=  "</tbody>
                                </table>";

                        $template = file_get_contents(base_url('email_templates/admin_approval.html'));
                        $message  = create_email_template($template);
                        $message  = str_replace('##TABLE##',$html, $message);
                        $message = str_replace('##USERNAME##',$get_user_detail['nick_name'],$message);
                        $subject = $this->config->item('site_title', 'ion_auth') . ' - Profile Approval' ;
                        //sendEmail($subject, "support@templebliss.co", $message);

                    }

                }

    //            $availability_arr = json_decode($request['availability'], true);
    //            
    //            $insert_arr   = [];
    //            $availability = [];
    //            $category_ids = [];
    //            $price_change_log = [];
    //            foreach ($availability_arr as $key => $value) {
    //                
    //                $insert_arr[$key]['user_id']     = $request['user_id'];
    //                $insert_arr[$key]['category_id'] = $value['category_id'];
    //                $insert_arr[$key]['type']        = $value['type'];
    //                $insert_arr[$key]['price']       = $value['new_price'];
    //                $insert_arr[$key]['created_at']  = $current_date;
    //                
    //                $category_ids[] = $value['category_id'];
    //                
    //                $availability[$key]['category_id'] = $value['category_id'];
    //                $availability[$key]['type']        = $value['type'];
    //                $availability[$key]['price']       = $value['new_price'];
    //                $availability[$key]['last_updated_date'] = $value['last_updated_date'];
    //                if($value['current_price'] != $value['new_price']) {
    //                    $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));
    //                    
    //                    $price_change_log[$key]['user_id']       = $request['user_id'];
    //                    $price_change_log[$key]['category_id']   = $value['category_id'];
    //                    $price_change_log[$key]['type']          = $value['type'];
    //                    $price_change_log[$key]['current_price'] = $value['current_price'];
    //                    $price_change_log[$key]['new_price']     = $value['new_price'];
    //                    $price_change_log[$key]['created_at']    = $current_date;
    //                }
    //            }
    //            $this->db->where('user_id', $request['user_id'])->delete('availability');
    //            
    //            $this->db->insert_batch('availability', $insert_arr);
    //            $this->db->insert_batch('price_change_log', $price_change_log);

    //            $user_data['category_id'] = implode(',', array_unique($category_ids));
                $response = $this->ion_auth->update($request['user_id'], $user_data);
    //            $this->comman->update_record('users', ['category_id' => implode(',', array_unique($category_ids))], $request['user_id']);

                if($response) {

                    $data['status'] = TRUE;

                    $data['profile'] = $this->comman->get_record_byid('users', $request['user_id']);

                    $data['availability'] = $availability;

//                    $data['message'] = 'Profile updated successfully.';

                } else {

                    $data['status'] = FALSE;

                    $data['message'] = $this->ion_auth->errors();

                }

        }

        $this->response($data);

    }

    // this one is old api
    // public function profile_update2_post(){

    //     $this->form_validation->set_rules('user_id', 'user_id', 'required|trim');

    //     $this->form_validation->set_rules('full_name', 'full name', 'required|trim');        
        
    //     $this->form_validation->set_rules('nick_name', 'nick name', 'required|trim');        

    //     $this->form_validation->set_rules('advisor_description', 'advisor description', 'required|trim');
        
    //     $this->form_validation->set_rules('is_change_availability', 'is change availability', 'required|trim|in_list[0,1]');
        
    //     $this->form_validation->set_rules('availability', 'availability', 'trim');
        
    //     if ($this->form_validation->run() == FALSE) {

    //         $data['status'] = FALSE;

    //         $data['message'] = validation_errors_response();

    //     } else {

    //         $request = $this->post();
            
    //         $current_date = current_date();
            
    //             $user_data = array(

    //                 'full_name'    => $request['full_name'],               

    //                 'nick_name'    => $request['nick_name'],               

    //             //                'email'        => $request['email'],               
    //             //
    //             //                'phone'        => $request['phone'],

    //                 'advisor_description' => $request['advisor_description'],

    //                 'updated_at'   => $current_date

    //             );

    //             $get_user_detail = $this->comman->get_record_byid('users', $request['user_id'], 'nick_name,advisor_description,profile_picture,category_id');

    //             if(!empty($request['is_change'])) {
    //                 $user_data['approve_advisor_detail'] = STATUS_INACTIVE;
    //                 $user_data['change_params'] = $request['is_change'];
    //             }

    //             if(isset($request['remove_image']) && $request['remove_image'] == 1) {

    //                 $user_data['profile_picture'] = '';
    //                 @unlink(FCPATH.$get_user_detail['profile_picture']);

    //             } 

    //             if (isset($_FILES['profile_picture']) && !empty($_FILES['profile_picture'])) {

    //                 $image_is_uploaded = image_upload('profile_picture', 'images/users/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG', '5000');

    //                 if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

    //                    $user_data['profile_picture'] = $image_is_uploaded['uploaded_path'];

    //                 }  else if( isset($image_is_uploaded['error']) ) {

    //                    $data['status'] = FALSE;

    //                    $data['message'] = ucfirst($image_is_uploaded['error']);

    //                    $this->response($data);

    //                    die();

    //                 }

    //             }

    //             $availability = [];
    //             if($request['is_change_availability']) {

    //                 if(!isset($request['availability']) || !count(json_decode($request['availability'], true)) ) {
    //                     $data['status'] = FALSE;

    //                     $data['message'] = 'Availability field is required';

    //                     $this->response($data);

    //                     die();
    //                 } else {
    //                     $existing_category_ids = $this->comman->get_record_byid('users', $request['user_id'], 'category_id')['category_id'];
    //                     $existing_category_ids = explode(',', $existing_category_ids);

    //                     $availability_arr = json_decode($request['availability'], true);
    //                     $current_category_ids = array_unique(array_column($availability_arr,'current_category_id'));

    //                     if(count($existing_category_ids) != count($current_category_ids) && count($existing_category_ids) > count($current_category_ids)) {
    //                         $remove_category_ids = array_diff($existing_category_ids, $current_category_ids);
    //                         $this->db->where('user_id', $request['user_id'])->where_in('category_id',$remove_category_ids)->delete('availability');
    //                         $this->db->where('user_id', $request['user_id'])
    //                             ->where_in('current_category_id',$remove_category_ids)
    //                             ->or_group_start()
    //                             ->where('current_category_id',0)
    //                             ->where_in('new_category_id',$remove_category_ids)
    //                             ->group_end()
    //                             ->delete('price_change_log');
    //                     } 
    //                     $insert_arr   = [];
    //                     $update_arr   = [];

    //                     $category_ids = [];
    //                     $price_change_log = [];
    //                     foreach ($availability_arr as $key => $value) {
    //                         if(empty($value['current_category_id']) || $value['current_category_id'] == '0') {
    //                             $insert_arr[$key]['user_id']     = $request['user_id'];
    //                             $insert_arr[$key]['category_id'] = $value['new_category_id'];
    //                             $insert_arr[$key]['type']        = $value['type'];
    //                             $insert_arr[$key]['price']       = $value['new_price'];
    //                             $insert_arr[$key]['created_at']  = $current_date;
    //                         } else if( ($value['current_category_id'] != $value['new_category_id']) || ($value['current_price'] != $value['new_price']) ) {
    //                             $update_arr[$key]['user_id']     = $request['user_id'];
    //                             $update_arr[$key]['category_id'] = $value['new_category_id'];
    //                             $update_arr[$key]['type']        = $value['type'];
    //                             $update_arr[$key]['price']       = $value['new_price'];
    //                             $update_arr[$key]['updated_at']  = $current_date;

    //                             $existing_record = $this->db->select('id')->from('availability')->where('user_id', $request['user_id'])->where('category_id', $value['current_category_id'])->where('type', $value['type'])->get()->row_array();
    //                             $update_arr[$key]['id']  = $existing_record['id'];
    //                         }

    //                         $category_ids[] = $value['new_category_id'];

    //                         $availability[$key]['category_id'] = $value['new_category_id'];
    //                         $availability[$key]['type']        = $value['type'];
    //                         $availability[$key]['price']       = $value['new_price'];
    //                         $availability[$key]['last_updated_date'] = $value['last_updated_date'];

    //                         if( $value['current_price'] != $value['new_price'] ) {
    //                             $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));

    //                             $price_change_log[$key]['user_id']             = $request['user_id'];
    //                             $price_change_log[$key]['current_category_id'] = $value['current_category_id'];
    //                             $price_change_log[$key]['new_category_id']     = $value['new_category_id'];
    //                             $price_change_log[$key]['type']                = $value['type'];
    //                             $price_change_log[$key]['current_price']       = $value['current_price'];
    //                             $price_change_log[$key]['new_price']           = $value['new_price'];
    //                             $price_change_log[$key]['created_at']          = $current_date;
    //                         } else if(isset($update_arr[$key])) {
    //                             $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));

    //                             $price_change_log[$key]['user_id']             = $request['user_id'];
    //                             $price_change_log[$key]['current_category_id'] = $value['current_category_id'];
    //                             $price_change_log[$key]['new_category_id']     = $value['new_category_id'];
    //                             $price_change_log[$key]['type']                = $value['type'];
    //                             $price_change_log[$key]['current_price']       = $value['current_price'];
    //                             $price_change_log[$key]['new_price']           = $value['new_price'];
    //                             $price_change_log[$key]['created_at']          = $current_date;
    //                         }

    //                     }
    //                     //                    echo '<pre>';
    //                     //                    echo '-------------$update_arr-------------------';
    //                     //                    print_r($update_arr);
    //                     //                    echo '-------------$insert_arr-------------------';
    //                     //                    print_r($insert_arr);
    //                     //                    echo '------------$price_change_log-----------------';
    //                     //                    print_r($price_change_log);
    //                     //                    die();
    //                     if(count($update_arr)) {
    //                         $this->db->update_batch('availability', $update_arr, 'id');
    //                     }
    //                     if(count($insert_arr)) {
    //                         $this->db->insert_batch('availability', $insert_arr);
    //                     }
    //                     if(count($price_change_log)) {
    //                         $this->db->insert_batch('price_change_log', $price_change_log);
    //                     }

    //                     $user_data['category_id'] = implode(',', array_unique($category_ids));
    //                 }
    //             } else {
    //                 $availability_arr = json_decode($request['availability'], true);
    //                 foreach ($availability_arr as $key => $value) {
    //                     $availability[$key]['category_id'] = $value['new_category_id'];
    //                     $availability[$key]['type']        = $value['type'];
    //                     $availability[$key]['price']       = $value['new_price'];
    //                     $availability[$key]['last_updated_date'] = $value['last_updated_date'];
    //                 }
    //             }


    //             $change_fields = explode(',', $request['is_change']);

    //             if(in_array('nick_name',$change_fields)){

    //                 $update_log[0]['user_id'] = $request['user_id'];
    //                 $update_log[0]['field_name'] = 'nick_name';
    //                 $update_log[0]['old_value'] = $get_user_detail['nick_name'];
    //                 $update_log[0]['new_value'] = $request['nick_name'];
    //                 $update_log[0]['status'] = 0;
    //                 $update_log[0]['created_at'] = $current_date;
    //             }

    //             if(in_array('advisor_description',$change_fields)){
                     
    //                 $update_log[1]['user_id'] = $request['user_id'];   
    //                 $update_log[1]['field_name'] = 'advisor_description';
    //                 $update_log[1]['old_value'] = $get_user_detail['advisor_description'];
    //                 $update_log[1]['new_value'] = $request['advisor_description'];
    //                 $update_log[1]['status'] = 0;
    //                 $update_log[1]['created_at'] = $current_date;

    //             }

    //             if(in_array('profile_picture',$change_fields)){
    //                 $update_log[2]['user_id'] = $request['user_id'];    
    //                 $update_log[2]['field_name'] = 'profile_picture';
    //                 $update_log[2]['old_value'] = $get_user_detail['profile_picture'];
    //                 $update_log[2]['new_value'] = $user_data['profile_picture'];
    //                 $update_log[2]['status'] = 0;
    //                 $update_log[2]['created_at'] = $current_date;

    //             }

    //             if(count($update_log)){
    //                 $update_log = array_values($update_log);
    //                 $this->db->insert_batch('profile_update_log', $update_log);
    //             }

                
    //             //            $availability_arr = json_decode($request['availability'], true);
    //             //            
    //             //            $insert_arr   = [];
    //             //            $availability = [];
    //             //            $category_ids = [];
    //             //            $price_change_log = [];
    //             //            foreach ($availability_arr as $key => $value) {
    //             //                
    //             //                $insert_arr[$key]['user_id']     = $request['user_id'];
    //             //                $insert_arr[$key]['category_id'] = $value['category_id'];
    //             //                $insert_arr[$key]['type']        = $value['type'];
    //             //                $insert_arr[$key]['price']       = $value['new_price'];
    //             //                $insert_arr[$key]['created_at']  = $current_date;
    //             //                
    //             //                $category_ids[] = $value['category_id'];
    //             //                
    //             //                $availability[$key]['category_id'] = $value['category_id'];
    //             //                $availability[$key]['type']        = $value['type'];
    //             //                $availability[$key]['price']       = $value['new_price'];
    //             //                $availability[$key]['last_updated_date'] = $value['last_updated_date'];
    //             //                if($value['current_price'] != $value['new_price']) {
    //             //                    $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($current_date));
    //             //                    
    //             //                    $price_change_log[$key]['user_id']       = $request['user_id'];
    //             //                    $price_change_log[$key]['category_id']   = $value['category_id'];
    //             //                    $price_change_log[$key]['type']          = $value['type'];
    //             //                    $price_change_log[$key]['current_price'] = $value['current_price'];
    //             //                    $price_change_log[$key]['new_price']     = $value['new_price'];
    //             //                    $price_change_log[$key]['created_at']    = $current_date;
    //             //                }
    //             //            }
    //             //            $this->db->where('user_id', $request['user_id'])->delete('availability');
    //             //            
    //             //            $this->db->insert_batch('availability', $insert_arr);
    //             //            $this->db->insert_batch('price_change_log', $price_change_log);

    //             //            $user_data['category_id'] = implode(',', array_unique($category_ids));
    //             // $response = $this->ion_auth->update($request['user_id'], $user_data);
    //             $response = true;
    //             //            $this->comman->update_record('users', ['category_id' => implode(',', array_unique($category_ids))], $request['user_id']);

    //             if($response) {

    //                 $data['status'] = TRUE;

    //                 $data['profile'] = $this->comman->get_record_byid('users', $request['user_id']);

    //                 $data['availability'] = $availability;

    //                 $data['message'] = 'Profile updated successfully. Please wait for admin approval.';

    //             } else {

    //                 $data['status'] = FALSE;

    //                 $data['message'] = $this->ion_auth->errors();

    //             }

    //     }

    //     $this->response($data);
    // }

    public function change_password_post() {

        $this->form_validation->set_rules('old_password', 'Old Password', 'required');

        $this->form_validation->set_rules('new_password', 'New Password', 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[new_confirm_password]');

        $this->form_validation->set_rules('new_confirm_password', 'Confirm New Password', 'required');

        $this->form_validation->set_rules('user_id', 'user id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $id = $this->post('user_id');

            $user = $this->ion_auth->user($id)->row();

            if (empty($user)) {

                $data['status'] = FALSE;

                $data['message'] = "User not exist.";

            } else {

                $response = $this->ion_auth->change_password($user->email, $this->post('old_password'), $this->post('new_password'), $id);

                if ($response) {

                    $data['status'] = TRUE;

                    $data['message'] = "Your password changed successfully.";

                } else {

                    $data['status'] = FALSE;

                    $data['message'] = strip_tags($this->ion_auth->errors());

                }

            }

        }

        $this->response($data);

    }
    
    //this api is old one
    public function change_availibilty_post() {
        
        $this->form_validation->set_rules('type', 'type', 'trim|required');

        $this->form_validation->set_rules('user_id', 'user id', 'trim|required');
        
        $this->form_validation->set_rules('status', 'status', 'trim|required|in_list[0,1]');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {
            
            $request = $this->post();
            $current_date = current_date();
            $availability = $this->db->select('id')->from('availability')->where('user_id',$request['user_id'])->where('status',1)->get()->result_array();
            if(count($availability) == 0){
                
                $user_data = $this->db->select('notify_me_customers,nick_name')->from('users')->where('id',$request['user_id'])->get()->row_array();
                if($user_data['notify_me_customers'] != '' && $user_data['notify_me_customers'] != null){
                    $customer_ids = explode(',',$user_data['notify_me_customers']);
                    if($request['user_id'] == 470){
                        $cron_data['type'] = "change_availability";
                        $cron_data['created_at'] = current_date();;
                        $this->comman->insert_record("cron_log", $cron_data);
                    }
                    
                    foreach ($customer_ids as $key => $value) {
                        $send_push_data['user_id'] = $value;
                        $send_push_data['advisor_id'] = $request['user_id'];
                        // send_push($value, 'users', "Advisor is online" , $user_data['nick_name'].' is online now. Do you want to connect?', 'notify_me',$send_push_data);
                        send_push($value, 'users', "Advisor is online" , $user_data['nick_name'].' is online now. Do you want to connect?', 'general',$send_push_data);
                    }
                    $this->comman->update_record_by_condition('users', ['notify_me_customers' => null], ['id' => $request['user_id']]);
                }
                
            }

            $this->comman->update_record_by_condition('availability', ['status' => $request['status']], ['user_id' => $request['user_id'], 'type' => $request['type']]);
            
            $data['status'] = TRUE;
            
            $data['message'] = '';

        }

        $this->response($data);
    }

    //currently using this api
    public function change_availibilty1_post() {
        
        // $this->form_validation->set_rules('type', 'type', 'trim|required');

        $this->form_validation->set_rules('user_id', 'user id', 'trim|required');
        
        $this->form_validation->set_rules('status', 'status', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {
            
            $request = $this->post();
            $current_date = current_date();
            $availability = $this->db->select('id')->from('availability')->where('user_id',$request['user_id'])->where('status',1)->get()->result_array();
            if(count($availability) == 0){
                
                $user_data = $this->db->select('notify_me_customers,nick_name')->from('users')->where('id',$request['user_id'])->get()->row_array();
                if($user_data['notify_me_customers'] != '' && $user_data['notify_me_customers'] != null){
                    $customer_ids = explode(',',$user_data['notify_me_customers']);
                    // if($request['user_id'] == 425){
                    //     $cron_data['type'] = "change_availability";
                    //     $cron_data['created_at'] = current_date();;
                    //     $this->comman->insert_record("cron_log", $cron_data);
                    // }
                    foreach ($customer_ids as $key => $value) {
                        $send_push_data['user_id'] = $value;
                        $send_push_data['advisor_id'] = $request['user_id'];
                        $title = "Advisor is online";
                        $description = $user_data['nick_name'].' is online now. Do you want to Connect?';

                        send_push($value, 'users', $title, $description, 'notify_me',$send_push_data); 

                        $notification[$key]['sent_to'] = $request['user_id'];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                    }
                    $this->comman->update_record_by_condition('users', ['notify_me_customers' => null], ['id' => $request['user_id']]);
                    if(!empty(array_values($notification))){
                        $this->db->insert_batch('notification',$notification);
                    }
                }
                
            }

            $status = json_decode($request['status'],true);
            if(!empty($status)){
                foreach($status as $key => $value) {
                    $this->comman->update_record_by_condition('availability', ['status' => $value['status']], ['user_id' => $request['user_id'], 'type' => $value['type']]);
                }    
                // send_push($request['user_id'], 'users', "TempleBliss", "Due to not active, Your availability mode set to off", 'general'); 
            }
            
            $data['status'] = TRUE;
            
            $data['message'] = '';

        }

        $this->response($data);
    }

    //this api is old one
    public function change_availibilty_old_post() {
        
        //$this->form_validation->set_rules('type', 'type', 'trim|required');

        $this->form_validation->set_rules('user_id', 'user id', 'trim|required');
        
        $this->form_validation->set_rules('status', 'status', 'trim|required|in_list[0,1]');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {
            
            $request = $this->post();

            // $availability = $this->db->select('id')->from('availability')->where('user_id',$request['user_id'])->where('status',1)->get()->result_array();
            // if(count($availability) == 0){
            //     $user_data = $this->db->select('notify_me_customers')->from('users')->where('id',$request['user_id'])->get()->row_array();
            //     if($user_data['notify_me_customers'] != '' && $user_data['notify_me_customers'] != null){
            //         $customer_ids = explode(',',$user_data['notify_me_customers']);
            //         foreach ($customer_ids as $key => $value) {
            //             $send_push_data['user_id'] = $value;
            //             $send_push_data['advisor_id'] = $request['user_id'];
            //             send_push($value, 'users', "Advisor is online" , 'This Advisor is online now. Do you want to connect?', 'general',$send_push_data);
            //         }
            //         $this->comman->update_record_by_condition('users', ['notify_me_customers' => null], ['id' => $request['user_id']]);
            //     }
                
            // }

            $status = json_decode('[{"type":"audio","status":"0"},{"type":"video","status":"1"}]',true) ;
            
            foreach($status as $key => $value) {
                $this->comman->update_record_by_condition('availability', ['status' => $value['status']], ['user_id' => $request['user_id'], 'type' => $value['type']]);
            }
            _pre($status);

            //$this->comman->update_record_by_condition('availability', ['status' => $request['status']], ['user_id' => $request['user_id'], 'type' => $request['type']]);
            
            $data['status'] = TRUE;
            
            $data['message'] = '';

        }

        $this->response($data);
    }
    
    public function category_list_get(){
        $data['category_count'] = $this->comman->get_record_by_condition('settings', ['name' => 'category_count'], 'value')[0]['value'];
        $category = $this->comman->get_record_by_condition('category', ['status' => STATUS_ACTIVE, 'deleted_at' => null]);
        
        foreach ($category as $key => $value) {
            $row[$key] = $value;
            $row[$key]['price_range'] = json_decode($value['price_range'], true);
        }
        
        $data['category'] = $row;

        $data['status'] = TRUE;

        $this->response($data);

    }
    
    public function user_profile_post() {

        $this->form_validation->set_rules('user_id', 'user id', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {
            $request = $this->post();
            
            $profile = $this->comman->get_record_byid('users', $request['user_id']);
            $profile['api_key'] = $this->comman->get_record_by_condition('tokens', ['user_id' => $request['user_id']], 'token')[0]['token'];
        
            $data['status'] = TRUE;
            $data['profile'] = $profile;
            $registerd_categories = $this->comman->get_record_by_condition('availability', ['user_id' => $request['user_id']], 'category_id, type, price,created_at,updated_at');
            foreach ($registerd_categories as $key => $value) {
                $latest_row = $this->db->select('created_at')->from('price_change_log')->where('user_id', $request['user_id'])->where('new_category_id', $value['category_id'])->where('type', $value['type'])->order_by('id', 'desc')->get()->row_array();

                $availability[$key] = $value;
                $availability[$key]['last_updated_date'] =  date('Y-m-d', strtotime($value['created_at']));
                if($value['updated_at'] != ''){
                    $availability[$key]['last_updated_date'] =  date('Y-m-d', strtotime($value['updated_at']));
                }
                //$availability[$key]['last_updated_date'] = date('Y-m-d');
                if(!empty($latest_row)) {
                    $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($latest_row['created_at']));
                }
            }
            $data['availability'] = $availability;
        }
        $this->response($data);
    }
    
    public function training_section_get($advisor_id = '',$token = ''){
//        $data['training'] = $this->comman->get_all_record('training', 'id,video_url,file');
        $data['training'] = $this->db->query('SELECT id, title, description, CASE WHEN video_url IS NOT NULL THEN video_url ELSE "" END AS video_url, CASE WHEN file IS NOT NULL THEN file ELSE "" END AS file,thumbnail FROM training')->result_array();
        $data['status'] = TRUE;

        if(!empty($token) && !empty($advisor_id)){
            $this->comman->update_record('users', ['voip_device_token' => $token], $advisor_id);
        }
        
        $data['message'] = '';

        $this->response($data);

    }
    
    
    public function isexists($str = NULL, $id = NULL) {

        $this->db->select('t1.*');

        $this->db->group_start();

        $this->db->where('t1.email', trim($str));

        $this->db->or_where('t1.phone', trim($str));

        $this->db->group_end();

        $this->db->where('t1.deleted_at', NULL);

        $this->db->where('t2.group_id', SERVICE_PROVIDER);

        if(!is_null($id)) {

            $this->db->where_not_in('t1.id', $id);

        }

        $this->db->from('users t1');

        $this->db->join('users_groups t2', 't1.id = t2.user_id');

        $this->db->limit(1);

        $sql_query = $this->db->get();

        if ($sql_query->num_rows() > 0) {

            $this->form_validation->set_message('isexists', (is_numeric($str)) ? "The phone is already exists": "The email is already exists");

            return false;

        } else {

            return true;

        }

    }
    
    public function save_video_thumb_post() {
        
        $this->form_validation->set_rules('record_id', 'record_id', 'required|trim');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            if (isset($_FILES['thumbnail']) && !empty($_FILES['thumbnail'])) {

                $image_is_uploaded = image_upload('thumbnail', 'training/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG', '5000');

                if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                   $path = $image_is_uploaded['uploaded_path'];
                   
                   $this->comman->update_record('training', ['thumbnail' => $path], $request['record_id']);
                   
                   $data['status'] = TRUE;

                   $data['message'] = '';

                }  else if( isset($image_is_uploaded['error']) ) {

                   $data['status'] = FALSE;

                   $data['message'] = ucfirst($image_is_uploaded['error']);

                   $this->response($data);

                   die();

                }

            } else {
                $data['status'] = FALSE;

                $data['message'] = 'Thumbnail is required';
            }
        }
        $this->response($data);
    }
    
    // currently using this api
    public function session_list_post() {
        
        $this->form_validation->set_rules('user_id', 'user id', 'required');

        $this->form_validation->set_rules('page', 'page', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            if($request['page'] == 0)
            {
                $request['page'] = 1;
            }

            if($request['page'] == 1)
            {
                $start = 0;
            }
            else
            {
                $start = ($request['page'] - 1) * $this->config->item('page_item');;
            }
            $limit = $this->config->item('page_item'); 
            
            $session_list = $this->db->query('SELECT booking_request.id as booking_id, advisor.id as customer_id, advisor.profile_picture, advisor.full_name,booking_request.type,booking_request.created_at as booking_date,category.name as category_name,booking_request.offer_id,booking_request.promocode_minute, booking_request.session_minute as total_minutes, booking_request.total as total_price,booking_request.advisor_commission, CASE WHEN booking_request.end_time IS NULL THEN false ELSE true END AS is_session_end,(SELECT COUNT(chat_history.id) from chat_history where chat_history.booking_id = booking_request.id AND chat_history.message_type = "free" AND chat_history.receiver_id = '.$request['user_id'].' AND chat_history.read_status = 0) as post_unread_message_count,(SELECT COUNT(chat_history.id) from chat_history where chat_history.booking_id = booking_request.id AND chat_history.message_type = "free" AND chat_history.receiver_id = '.$request['user_id'].') as post_message_available, booking_request.note 
            FROM `booking_request` 
            left join category on booking_request.category_id = category.id 
            LEFT JOIN chat_history on booking_request.id = chat_history.booking_id 
            join users AS advisor on booking_request.user_id = advisor.id 
            WHERE booking_request.advisor_id = '.$request['user_id'].' AND booking_request.status = 1 AND booking_request.is_session_running = 1 AND booking_request.end_time IS NOT NULL  GROUP BY booking_request.id ORDER BY booking_id DESC LIMIT '.$start.','.$limit.'')->result_array();
            $response['status'] = false;
            $response['message'] = 'Sessions not availible';
            if(count($session_list)) {
                $response['status'] = true;
                $response['message'] = '';
            }
            if(!empty($session_list)){
                foreach ($session_list as $key => $value) {
                   $row[$key] = $value;
                   $row[$key]['total_minutes'] = ($value['promocode_minute'] != 0) ? $value['promocode_minute'] : $value['total_minutes'];
                }
                $session_list = $row;
            }
            $response['session_list'] = $session_list;
        
        }
        $this->response($response);
    }

    // public function session_list1_post() {
        
    //     $this->form_validation->set_rules('user_id', 'user id', 'required');

    //     $this->form_validation->set_rules('page', 'page', 'trim|required');

    //     if ($this->form_validation->run() == FALSE) {

    //         $response['status'] = FALSE; 

    //         $response['message'] = validation_errors_response();

    //     } else {

    //         $request = $this->post();

    //         if($request['page'] == 0)
    //         {
    //             $request['page'] = 1;
    //         }

    //         if($request['page'] == 1)
    //         {
    //             $start = 0;
    //         }
    //         else
    //         {
    //             $start = ($request['page'] - 1) * $this->config->item('page_item');;
    //         }
    //         $limit = $this->config->item('page_item'); 
            
    //         $session_list = $this->db->query('SELECT booking_request.id as booking_id, advisor.id as customer_id, advisor.profile_picture, advisor.full_name,booking_request.type,booking_request.created_at as booking_date, booking_request.session_minute as total_minutes, booking_request.total as total_price,booking_request.advisor_commission, CASE WHEN booking_request.end_time IS NULL THEN false ELSE true END AS is_session_end,(SELECT COUNT(chat_history.id) from chat_history where chat_history.booking_id = booking_request.id AND chat_history.message_type = "free" AND chat_history.read_status = 0) as post_unread_message_count ,booking_request.note 
    //         FROM `booking_request` 
    //         LEFT JOIN chat_history on booking_request.id = chat_history.booking_id    
    //         join users AS advisor on booking_request.user_id = advisor.id 
    //         WHERE booking_request.advisor_id = '.$request['user_id'].' AND booking_request.status = 1 AND booking_request.is_session_running = 1 AND booking_request.end_time IS NOT NULL  GROUP BY booking_request.id ORDER BY booking_id DESC LIMIT '.$start.','.$limit.'')->result_array();
    //         $response['status'] = false;
    //         $response['message'] = 'Sessions not availible';
    //         if(count($session_list)) {
    //             $response['status'] = true;
    //             $response['message'] = '';
    //         }
    //         $response['session_list'] = $session_list;
        
    //     }
    //     $this->response($response);
    // }
    
    public function chat_history_post() {
        
        $this->form_validation->set_rules('booking_id', 'booking id', 'required');
        $this->form_validation->set_rules('chat_type', 'chat type', 'required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
        
            $chat_history = $this->db->query('SELECT chat_history.id as chat_id, booking_request.created_at as booking_date, chat_history.message, chat_history.sender_type, chat_history.receiver_type, chat_history.created_at as message_date, chat_history.read_status, booking_request.id as booking_id, chat_history.sender_id, chat_history.receiver_id, sender.full_name, CASE WHEN sender.nick_name IS NOT NULL THEN sender.nick_name ELSE "" END AS nick_name, sender.profile_picture, booking_request.note FROM `chat_history` join booking_request on chat_history.booking_id = booking_request.id join users as sender on chat_history.sender_id = sender.id WHERE booking_request.id = '.$request['booking_id'].' AND chat_history.message_type="'.$request['chat_type'].'" ORDER BY chat_history.id DESC')->result_array();
            
            $response['status'] = true;
            $response['message'] = 'Chat not availible';
            if(count($chat_history)) {
                $response['status'] = true;
                $response['message'] = '';
            }
            $response['chat_history'] = $chat_history;
        }
        $this->response($response);
    }
    
    public function rating_review_post() {
        
        $this->form_validation->set_rules('user_id', 'user id', 'required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
        
            $review_history = $this->db->select('advisor_rating.rating, advisor_rating.note, users.full_name, users.profile_picture, advisor_rating.created_at')->from('advisor_rating')->join('users', 'advisor_rating.user_id = users.id')->where('advisor_id', $request['user_id'])->order_by('advisor_rating.id','desc')->get()->result_array();
            
            $response['status'] = true;
            $response['message'] = 'Review not availible';
            if(count($review_history)) {
                $response['status'] = true;
                $response['message'] = '';
            }
            $response['review_history'] = $review_history;
        }
        $this->response($response);
    }
    
    public function my_earning2_post(){ 

        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,SUM(wallet.amount) as total_withdrawed_amount')
                        ->from('users')
                        ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
                        ->where('users.id',$request['advisor_id'])
                        ->get()->row_array();
            $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
            $my_earning['total_earning'] = (string)$total;
            $my_earning['available_for_withdraw'] = ( $my_earning['pending_withdraw_amount'] >= 100) ? $my_earning['pending_withdraw_amount'] : "0";

            $booking_request = $this->db->select('booking_request.type,booking_request.minute,booking_request.end_time,booking_request.advisor_commission,customer.full_name as customer_name,customer.profile_picture')->from('booking_request')
                            ->join('users as advisor','booking_request.advisor_id = advisor.id','left')
                            ->join('users as customer','booking_request.user_id = customer.id','left')
                            ->where('booking_request.advisor_id',$request['advisor_id'])
                            ->where('booking_request.end_time IS NOT NULL')
                            ->get()->result_array();

            $data['status'] = TRUE;
            $data['my_earning_details'] = $my_earning;
            $data['customer_booking_details'] = $booking_request;
        }

        $this->response($data);
    }

    //this my_earning1 was main api before we make below my_earning function
    // public function my_earning1_post(){ 

    //     $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

    //     $this->form_validation->set_rules('filter', 'filter', 'trim|in_list[complete,pending,available]');

    //     $this->form_validation->set_rules('page', 'page', 'trim|required');

    //     if ($this->form_validation->run() == FALSE) {

    //         $data['status'] = FALSE;

    //         $data['message'] = validation_errors_response();

    //     } else {

    //         $request = $this->post();

    //         $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,CAST(SUM(amount) AS DECIMAL(10,2)) as total_withdrawed_amount')
    //                     ->from('users')
    //                     ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
    //                     ->where('users.id',$request['advisor_id'])
    //                     ->get()->row_array();
    //         $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
    //                     // _pre($total);
    //         $my_earning['total_earning'] = (string)$total;
    //         $my_earning['available_for_withdraw'] = ( $my_earning['pending_withdraw_amount'] >= 100) ? $my_earning['pending_withdraw_amount'] : "0";

    //         if(isset( $request['filter']) && $request['filter'] == 'complete'){
    //             $where = "advisor_amount_log.status = 1";
    //             $status = true;
    //         }else if(isset( $request['filter']) && $request['filter'] == 'available'){
    //             if($my_earning['available_for_withdraw'] != "0" && $my_earning['pending_withdraw_amount'] >= 100){
    //                 $where = "advisor_amount_log.status = 0";
    //                 $status = true;
    //             }else{
    //                 $status = false;
    //             }
    //         }else{
    //             $where = "advisor_amount_log.status = 0";
    //             $status = true;
    //         }

    //         if($status == true){

    //             if($request['page'] == 0)
    //             {
    //                 $request['page'] = 1;
    //             }

    //             if($request['page'] == 1)
    //             {
    //                 $start = 0;
    //             }
    //             else
    //             {
    //                 $start = ($request['page'] - 1) * $this->config->item('page_item');;
    //             }
    //             $limit = $this->config->item('page_item');  

    //             $booking_details = $this->db->select('booking_request.id as booking_id,booking_request.type,booking_request.minute,booking_request.session_minute,booking_request.end_time,booking_request.advisor_commission,customer.full_name as customer_name,customer.profile_picture')->from('advisor_amount_log')
    //                         ->join('booking_request','advisor_amount_log.booking_id = booking_request.id','left')
    //                         ->join('users as advisor','booking_request.advisor_id = advisor.id','left')
    //                         ->join('users as customer','booking_request.user_id = customer.id','left')
    //                         ->where('advisor_amount_log.advisor_id',$request['advisor_id'])
    //                         ->where('booking_request.end_time IS NOT NULL')
    //                         ->where($where)
    //                         ->where('booking_request.status != 2')
    //                         ->order_by('booking_request.id','desc')
    //                         ->limit($limit, $start)
    //                         ->get()->result_array();
    //         }else{
    //             $booking_details = [];
    //         }

    //         $data['status'] = TRUE;
    //         $data['my_earning_details'] = $my_earning;
    //         // $data['customer_booking_details'] = $booking_request;
    //         $data['booking_details'] = $booking_details;
    //     }

    //     $this->response($data);
    // }

    // currently using this api
    public function my_earning_post(){ 

        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        $this->form_validation->set_rules('filter', 'filter', 'trim|in_list[complete,pending,available]');

        $this->form_validation->set_rules('page', 'page', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,CAST(SUM(amount) AS DECIMAL(10,2)) as total_withdrawed_amount')
                        ->from('users')
                        ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
                        ->where('users.id',$request['advisor_id'])
                        ->get()->row_array();
            $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
                        // _pre($total);
            $my_earning['total_earning'] = (string)$total;

            $my_earning['payment_fee'] = $this->get_payment_fee();
            
            //( $my_earning['pending_withdraw_amount'] >= 100) ? $my_earning['pending_withdraw_amount'] : "0"
            //REPLACE(FORMAT(SUM(row1),2),',','')
            $where = "advisor_amount_log.status = 0 AND DATE(booking_request.end_time) <= DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)";
            $available = $this->db->select('FORMAT(SUM(booking_request.advisor_commission),2) as advisor_available_amount')->from('booking_request')
                                    ->join('advisor_amount_log','booking_request.id = advisor_amount_log.booking_id')
                                    ->where('booking_request.advisor_id',$request['advisor_id'])
                                    ->where('booking_request.status != 2')
                                    ->where('booking_request.end_time IS NOT NULL')
                                    ->where('booking_request.is_session_running',1)
                                    ->where($where)->get()->row_array();
                                    // _pre($this->db->last_query());
            $my_earning['available_for_withdraw'] = (!empty($available) && $available['advisor_available_amount'] != 0 && $available['advisor_available_amount'] !=     null) ? str_replace(',','', $available['advisor_available_amount']) : "0";
            // $my_earning['available_for_withdraw'] = '0';

            if(isset( $request['filter']) && $request['filter'] == 'complete'){
                $where = "advisor_amount_log.status = 1";
                $status = true;
            }else if(isset( $request['filter']) && $request['filter'] == 'available'){
                if($my_earning['pending_withdraw_amount'] != "0"){
                    $where = "advisor_amount_log.status = 0 AND DATE(booking_request.end_time) <= DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)";
                    // $available = $this->db->select('SUM(booking_request.advisor_commission) as advisor_available_amount')->from('booking_request')
                    //                         ->join('advisor_amount_log','booking_request.id = advisor_amount_log.booking_id')
                    //                         ->where('booking_request.advisor_id',$request['advisor_id'])
                    //                         ->where('booking_request.status != 2')
                    //                         ->where('booking_request.end_time IS NOT NULL')
                    //                         ->where('booking_request.is_session_running',1)
                    //                         ->where($where)->get()->row_array();
                    //                         // _pre($this->db->last_query());
                    // $my_earning['available_for_withdraw'] = (!empty($available) && $available['advisor_available_amount'] != 0 && $available['advisor_available_amount'] != null) ? $available['advisor_available_amount'] : "0";
                    $status = true;
                }else{
                    $status = false;
                }
            }else{ // advisor_amount_log.status = 0
                $where = "advisor_amount_log.status = 0 AND DATE(booking_request.end_time) > DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)";
                $status = true;
            }
            $row = [];
            //_pre($where);
            if($status == true){

                if($request['page'] == 0)
                {
                    $request['page'] = 1;
                }

                if($request['page'] == 1)
                {
                    $start = 0;
                }
                else
                {
                    $start = ($request['page'] - 1) * $this->config->item('page_item');;
                }
                $limit = $this->config->item('page_item');  
                $available_amount = 0;
                $booking_details = $this->db->select('booking_request.id as booking_id,booking_request.type,booking_request.minute,booking_request.session_minute,booking_request.end_time,booking_request.advisor_commission,customer.full_name as customer_name,customer.profile_picture,advisor_amount_log.created_at as withdrawal_date,advisor_amount_log.status as withdrawal_status')->from('advisor_amount_log')
                            ->join('booking_request','advisor_amount_log.booking_id = booking_request.id','left')
                            ->join('users as advisor','booking_request.advisor_id = advisor.id','left')
                            ->join('users as customer','booking_request.user_id = customer.id','left')
                            ->where('advisor_amount_log.advisor_id',$request['advisor_id'])
                            ->where('booking_request.end_time IS NOT NULL')
                            ->where($where)
                            ->where('booking_request.status != 2')
                            ->where('booking_request.is_session_running',1)
                            ->order_by('booking_request.id','desc')
                            ->limit($limit, $start)
                            ->get()->result_array();
                            // _pre($this->db->last_query());
                foreach($booking_details as $key => $value){
                    $row[$key] = $value;
                    $row[$key]['time_ago'] = $this->get_timeago($value['end_time']);
                    $available_amount = $available_amount + (float)$value['advisor_commission'];
                    if( $request['filter'] == 'complete'){
                        $row[$key]['payment_date'] = $this->get_payment_time($value['booking_id'],$request['advisor_id'],"time");
                        $row[$key]['payment_fee'] = $this->get_payment_time($value['booking_id'],$request['advisor_id'],"fee");
                        $row[$key]['time_ago'] = $this->get_timeago($value['withdrawal_date']);    
                    }
                }
            }else{
                $booking_details = [];
            }
            // $my_earning['available'] = $available_amount;
            $data['status'] = TRUE;
            $data['my_earning_details'] = $my_earning;
            // $data['customer_booking_details'] = $booking_request;
            $data['booking_details'] = $row;
        }

        $this->response($data);
    }

    public function get_payment_fee(){
        $payment_fee = $this->db->select('value')->from('settings')->where('name','admin_paypal_commission')->get()->row_array();

        return $payment_fee['value'];
    }

    public function get_payment_time($booking_id,$advisor_id,$type){
        
        if($type == "time"){

            $payment_time = $this->db->query('SELECT created_at FROM paypal_transaction_log WHERE FIND_IN_SET( '.$booking_id.' , booking_id ) AND status = 1 AND user_id = '.$advisor_id)->row_array();
            return date('Y-m-d',strtotime($payment_time['created_at']));

        }else{
            $payment_fee = $this->db->query('SELECT admin_commission FROM admin_paypal_commission_log WHERE FIND_IN_SET( '.$booking_id.' , booking_id ) AND advisor_id = '.$advisor_id)->row_array();
            return $payment_fee['admin_commission'];
        }

        // return $this->db->last_query();
    }

    public function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
    
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;
    
        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }
    
        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

    public function get_timeago( $ptime )
    {
        $etime = time() - strtotime($ptime);

        if( $etime < 1 )
        {
            return 'less than '.$etime.' second ago';
        }

        $a = array( 12 * 30 * 24 * 60 * 60  =>  'year',
                    30 * 24 * 60 * 60       =>  'month',
                    24 * 60 * 60            =>  'day',
                    60 * 60             =>  'hour',
                    60                  =>  'minute',
                    1                   =>  'second'
        );

        foreach( $a as $secs => $str )
        {
            $d = $etime / $secs;

            if( $d >= 1 )
            {
                $r = round( $d );
                return  $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
            }
        }
    }


    public function withdraw_old_post(){

        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        $this->form_validation->set_rules('amount', 'amount', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 

            $advisor_details = $this->db->select('advisor_withdrawal_amount,account_detail as email')->from('users')->join('advisor_payment_detail', 'users.id= advisor_payment_detail.user_id')->where('users.id', $request['advisor_id'])->get()->row_array();

            if($advisor_details['advisor_withdrawal_amount'] >= 100){

                $admin_details = $this->db->select('value')->from('settings')->where('name','admin_paypal_commission')->get()->row_array();
                $amount = $request['amount'] - (int)$admin_details['value'];
                // _pre($amount);
                $token = get_token();
                $response = payout($advisor_details['email'],$amount,$token);

                if(isset(json_decode($response['response'],true)['error'])){
                    $data['status'] = FALSE;
                    $data['error'] = json_decode($response['response'],true)['error'];
                }else{

                    if(!isset(json_decode($response['response'],true)['name'])){
                        $withdrawal_log['user_id']          = $request['advisor_id'];
                        $withdrawal_log['batch_id']         = $response['batch_id'];
                        $withdrawal_log['initiate_response']= $response['response'];
                        $withdrawal_log['token']            = $token;
                        $withdrawal_log['created_at']       = current_date();
                        $withdrawal_log_id = $this->comman->insert_record('withdrawal_log',$withdrawal_log);

                        $payout_batch_id = json_decode($response['response'],true)['batch_header']['payout_batch_id'];
                        sleep(6);
                        $payment_status =  payment_status($payout_batch_id,$token);
                        
                        if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'SUCCESS'){

                            $withdrawal_amount = $advisor_details['advisor_withdrawal_amount'] - $request['amount'];
                            $update_data['advisor_withdrawal_amount'] = $withdrawal_amount;
                            $this->comman->update_record('users', $update_data, $request['advisor_id']);

                            $wallet_data['user_id']     = $request['advisor_id'];
                            $wallet_data['amount_type'] = "withdraw";
                            $wallet_data['amount']      = $amount;
                            $wallet_data['created_at']  = current_date();
                            $this->comman->insert_record('wallet',$wallet_data);

                            $booking_ids = $this->db->select('booking_id')->from('advisor_amount_log')
                                                    ->where('advisor_id',$request['advisor_id'])
                                                    ->where('status',0)
                                                    ->get()->result_array();
                            $ids = implode(',',array_column($booking_ids,'booking_id')); 

                            $admin_paypal_commission['advisor_id']       = $request['advisor_id'];
                            $admin_paypal_commission['booking_id']       = $ids;
                            $admin_paypal_commission['amount']           = $request['amount'];
                            $admin_paypal_commission['admin_commission'] = $admin_details['value'];
                            $admin_paypal_commission['created_at']       = current_date();
                            $this->comman->insert_record('admin_paypal_commission_log',$admin_paypal_commission);
                            // _pre($ids);
                            $withdrawal_update['booking_ids'] = $ids;

                            $advisor_amount_log['status'] = 1;
                            $this->db->update('advisor_amount_log', $advisor_amount_log, ['advisor_id' => $request['advisor_id'],'status' => 0]);

                            $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,SUM(wallet.amount) as total_withdrawed_amount')
                                        ->from('users')
                                        ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
                                        ->where('users.id',$request['advisor_id'])
                                        ->get()->row_array();
                            $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
                            $my_earning['total_earning'] = (string)$total;
                            $my_earning['available_for_withdraw'] = ( $my_earning['pending_withdraw_amount'] >= 100) ? $my_earning['pending_withdraw_amount'] : "0";

                            $data['status'] = TRUE;
                            $data['my_earning_details'] = $my_earning;
                            $data['message'] = "Amount Withdrawed Successfully";
                            $withdrawal_update['status'] = 1;
                        }else{
                            $data['status'] = FALSE;
                            $data['message'] = "Transferred failed due to technical reason.";
                            $withdrawal_update['status'] = 2;
                        }
                        $withdrawal_update['success_response'] = $payment_status;
                        $this->comman->update_record('withdrawal_log', $withdrawal_update, $withdrawal_log_id);
                    }else{
                        $data['status'] = FALSE;
                        $data['message'] = "Transferred failed due to ".json_decode($response['response'],true)['name'];
                    }
                }
            }else{
                $data['status'] = FALSE;
                $data['message'] = "withdrawal amount should be minimun at least 100";
            }
        }

        $this->response($data);

    }

    // public function withdraw1_post(){

    //     $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

    //     $this->form_validation->set_rules('amount', 'amount', 'required');

    //     if ($this->form_validation->run() == FALSE) {

    //         $data['status'] = FALSE;

    //         $data['message'] = validation_errors_response();

    //     } else {
 
    //         $request = $this->post();
            
    //         $current_date = current_date();

    //         $advisor_details = $this->db->select('advisor_withdrawal_amount,account_detail as email')->from('users')->join('advisor_payment_detail', 'users.id= advisor_payment_detail.user_id')->where('users.id', $request['advisor_id'])->get()->row_array();

    //         if($advisor_details['advisor_withdrawal_amount'] >= 100){

    //             $admin_details = $this->db->select('value')->from('settings')->where('name','admin_paypal_commission')->get()->row_array();
    //             $amount = $request['amount'] - (int)$admin_details['value'];
    //             // _pre($amount);
    //             $token = get_token();
    //             $response = payout($advisor_details['email'],$amount,$token);

    //             if(isset(json_decode($response['response'],true)['error'])){
    //                 $data['status'] = FALSE;
    //                 $data['error'] = json_decode($response['response'],true)['error'];
    //             }else{

    //                 if(!isset(json_decode($response['response'],true)['name'])){

    //                     $withdrawal_log['user_id']          = $request['advisor_id'];
    //                     $withdrawal_log['batch_id']         = $response['batch_id'];
    //                     $withdrawal_log['initiate_response']= $response['response'];
    //                     $withdrawal_log['token']            = $token;
    //                     $withdrawal_log['created_at']       = $current_date;
    //                     $withdrawal_log_id = $this->comman->insert_record('withdrawal_log',$withdrawal_log);

    //                     $payout_batch_id = json_decode($response['response'],true)['batch_header']['payout_batch_id'];
    //                     sleep(6);
    //                     $payment_status =  payment_status($payout_batch_id,$token);
                        
    //                     if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'SUCCESS'){

    //                         $withdrawal_amount = $advisor_details['advisor_withdrawal_amount'] - $request['amount'];
    //                         $update_data['advisor_withdrawal_amount'] = $withdrawal_amount;
    //                         $this->comman->update_record('users', $update_data, $request['advisor_id']);

    //                         $wallet_data['user_id']     = $request['advisor_id'];
    //                         $wallet_data['amount_type'] = "withdraw";
    //                         $wallet_data['amount']      = $amount;
    //                         $wallet_data['created_at']  = $current_date;
    //                         $this->comman->insert_record('wallet',$wallet_data);

    //                         $booking_ids = $this->db->select('booking_id')->from('advisor_amount_log')
    //                                                 ->where('advisor_id',$request['advisor_id'])
    //                                                 ->where('status',0)
    //                                                 ->get()->result_array();
    //                         $ids = implode(',',array_column($booking_ids,'booking_id')); 

    //                         $admin_paypal_commission['advisor_id']       = $request['advisor_id'];
    //                         $admin_paypal_commission['booking_id']       = $ids;
    //                         $admin_paypal_commission['amount']           = $request['amount'];
    //                         $admin_paypal_commission['admin_commission'] = $admin_details['value'];
    //                         $admin_paypal_commission['created_at']       = $current_date;
    //                         $this->comman->insert_record('admin_paypal_commission_log',$admin_paypal_commission);
    //                         // _pre($ids);
    //                         $withdrawal_update['booking_ids'] = $ids;

    //                         $advisor_amount_log['status'] = 1;
    //                         $this->db->update('advisor_amount_log', $advisor_amount_log, ['advisor_id' => $request['advisor_id'],'status' => 0]);

    //                         $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,SUM(wallet.amount) as total_withdrawed_amount')
    //                                     ->from('users')
    //                                     ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
    //                                     ->where('users.id',$request['advisor_id'])
    //                                     ->get()->row_array();
    //                         $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
    //                         $my_earning['total_earning'] = (string)$total;
    //                         $my_earning['available_for_withdraw'] = ( $my_earning['pending_withdraw_amount'] >= 100) ? $my_earning['pending_withdraw_amount'] : "0";

    //                         $data['status'] = TRUE;
    //                         $data['my_earning_details'] = $my_earning;
    //                         $data['message'] = "Amount Withdrawed Successfully";
    //                         $withdrawal_update['status'] = 1;
    //                     }
    //                     else if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'PENDING'){
    
    //                         $booking_ids = $this->db->select('booking_id')->from('advisor_amount_log')
    //                                                 ->where('advisor_id',$request['advisor_id'])
    //                                                 ->where('status',0)
    //                                                 ->get()->result_array();
    //                         $ids = implode(',',array_column($booking_ids,'booking_id')); 
    
    //                         $withdrawal_update['user_id'] = $request['advisor_id'];
    //                         $withdrawal_update['status'] = 3;
    //                         $withdrawal_update['booking_ids'] = $ids;
    
    //                         $advisor_update['id'] =$request['advisor_id'];
    //                         $advisor_update['advisor_withdrawal_amount'] = 0;
    
    //                         $paypal_transaction_log['user_id'] = $request['advisor_id'];
    //                         $paypal_transaction_log['amount'] =$amount;
    //                         $paypal_transaction_log['payout_item_id'] = json_decode($payment_status,true)['items'][0]['payout_item_id'];
    //                         $paypal_transaction_log['status'] = 0;
    //                         $paypal_transaction_log['created_at'] =  $current_date;
    
    //                         $advisor_amount_log['advisor_id'] =$request['advisor_id'];
    //                         $advisor_amount_log['status'] = 3;
    //                         $advisor_amount_log['updated_at'] = $current_date;
    
    //                     }
    //                     else{
    //                         $data['status'] = FALSE;
    //                         $data['message'] = "Transferred failed due to technical reason.";
    //                         $withdrawal_update['status'] = 2;
    //                     }
    //                     $withdrawal_update['success_response'] = $payment_status;
    //                     $this->comman->update_record('withdrawal_log', $withdrawal_update, $withdrawal_log_id);
    //                 }else{
    //                     $data['status'] = FALSE;
    //                     $data['message'] = "Transferred failed due to ".json_decode($response['response'],true)['name'];
    //                 }
    //             }
    //         }else{
    //             $data['status'] = FALSE;
    //             $data['message'] = "withdrawal amount should be minimun at least 100";
    //         }
    //     }

    //     $this->response($data);

    // }

    // currently using this api
    public function withdraw_post(){

        // $data['status'] = FALSE;
        // $data['message'] = "Withdrawal request unavailable.Please try again after some time";

        // $this->response($data);

        // exit();

        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        $this->form_validation->set_rules('amount', 'amount', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            //$request['amount'] = 1;
           
            $current_date = current_date();

            $advisor_details = $this->db->select('advisor_withdrawal_amount,account_detail as email')->from('users')->join('advisor_payment_detail', 'users.id= advisor_payment_detail.user_id')->where('users.id', $request['advisor_id'])->get()->row_array();

            //if($advisor_details['advisor_withdrawal_amount'] >= 100){

                $admin_details = $this->db->select('value')->from('settings')->where('name','admin_paypal_commission')->get()->row_array();
                $amount = $request['amount'];
                if($request['amount'] > (int)$admin_details['value']){
                    $amount = $request['amount'] - (int)$admin_details['value'];
                }
                // _pre($amount);
                $token = get_token();
                $response = payout($advisor_details['email'],$amount,$token);

                if(isset(json_decode($response['response'],true)['error'])){
                    $data['status'] = FALSE;
                    $data['error'] = json_decode($response['response'],true)['error'];
                }else{

                    if(!isset(json_decode($response['response'],true)['name'])){
                        $withdrawal_log['user_id']          = $request['advisor_id'];
                        $withdrawal_log['batch_id']         = $response['batch_id'];
                        $withdrawal_log['initiate_response']= $response['response'];
                        $withdrawal_log['token']            = $token;
                        $withdrawal_log['created_at']       = $current_date;
                        $withdrawal_log_id = $this->comman->insert_record('withdrawal_log',$withdrawal_log);

                        $payout_batch_id = json_decode($response['response'],true)['batch_header']['payout_batch_id'];
                        sleep(6);
                        $payment_status =  payment_status($payout_batch_id,$token);
                        
                        if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'SUCCESS'){

                            $withdrawal_amount = $advisor_details['advisor_withdrawal_amount'] - $request['amount'];
                            $update_data['advisor_withdrawal_amount'] = $withdrawal_amount;
                            $this->comman->update_record('users', $update_data, $request['advisor_id']);

                            $wallet_data['user_id']     = $request['advisor_id'];
                            $wallet_data['amount_type'] = "withdraw";
                            $wallet_data['amount']      = $amount;
                            $wallet_data['created_at']  = $current_date;
                            $this->comman->insert_record('wallet',$wallet_data);
 
                            $available = $this->available($request['advisor_id'],'booking_id');
                            $ids = implode(',',array_column($available,'id'));

                            $admin_paypal_commission['advisor_id']       = $request['advisor_id'];
                            $admin_paypal_commission['booking_id']       = $ids;
                            $admin_paypal_commission['payout_item_id']   = json_decode($payment_status,true)['items'][0]['payout_item_id'];
                            $admin_paypal_commission['payout_batch_id']  = $payout_batch_id;
                            $admin_paypal_commission['amount']           = $request['amount'];
                            $admin_paypal_commission['admin_commission'] = $admin_details['value'];
                            $admin_paypal_commission['created_at']       = $current_date;
                            $this->comman->insert_record('admin_paypal_commission_log',$admin_paypal_commission);

                            $paypal_transaction_log['user_id'] = $request['advisor_id'];
                            $paypal_transaction_log['booking_id'] = $ids;
                            $paypal_transaction_log['amount'] = $amount;
                            $paypal_transaction_log['payout_item_id'] = json_decode($payment_status,true)['items'][0]['payout_item_id'];
                            $paypal_transaction_log['payout_batch_id'] = $payout_batch_id;
                            $paypal_transaction_log['items'] = json_encode(json_decode($payment_status,true)['items'][0],true);
                            $paypal_transaction_log['status'] = 1;
                            $paypal_transaction_log['token'] = $token;
                            $paypal_transaction_log['created_at'] =  $current_date;
                            $this->comman->insert_record('paypal_transaction_log',$paypal_transaction_log);

                            $withdrawal_update['booking_ids'] = $ids;

                            // $advisor_amount_log['status'] = 1;
                            // $this->db->update('advisor_amount_log', $advisor_amount_log, ['advisor_id' => $request['advisor_id'],'status' => 0]);

                            $this->db->query('UPDATE advisor_amount_log SET status = 1,updated_at = "'.$current_date.'" WHERE booking_id IN('.$ids.')');

                            $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,CAST(SUM(amount) AS DECIMAL(10,2)) as total_withdrawed_amount')
                                        ->from('users')
                                        ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
                                        ->where('users.id',$request['advisor_id'])
                                        ->get()->row_array();
                            $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
                                       
                            $my_earning['total_earning'] = (string)$total;
                            $available = $this->available($request['advisor_id'],'sum');
                            $my_earning['available_for_withdraw'] = (!empty($available) && $available[0]['advisor_available_amount'] != 0 && $available[0]['advisor_available_amount'] != null) ? $available[0]['advisor_available_amount'] : "0";

                            $data['status'] = TRUE;
                            $data['my_earning_details'] = $my_earning;
                            $data['message'] = "Amount Withdrawn Successfully";
                            $withdrawal_update['status'] = 1;
                        }
                        else if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'PENDING' || json_decode($payment_status,true)['items'][0]['transaction_status'] == 'ONHOLD'){

                            $available = $this->available($request['advisor_id'],'booking_id');
                            $ids = implode(',',array_column($available,'id')); 

                            $withdrawal_update['status'] = 3;
                            $withdrawal_update['booking_ids'] = $ids;

                            $withdrawal_amount = $advisor_details['advisor_withdrawal_amount'] - $request['amount'];
                            $update_data['advisor_withdrawal_amount'] = $withdrawal_amount;
                            $this->comman->update_record('users', $update_data, $request['advisor_id']);

                            $paypal_transaction_log['user_id'] = $request['advisor_id'];
                            $paypal_transaction_log['booking_id'] = $ids;
                            $paypal_transaction_log['amount'] = $amount;
                            $paypal_transaction_log['payout_item_id'] = json_decode($payment_status,true)['items'][0]['payout_item_id'];
                            $paypal_transaction_log['payout_batch_id'] = $payout_batch_id;
                            $paypal_transaction_log['items'] = json_encode(json_decode($payment_status,true)['items'][0],true);
                            $paypal_transaction_log['status'] = 0;
                            $paypal_transaction_log['token'] = $token;
                            $paypal_transaction_log['created_at'] =  $current_date;
                            $this->comman->insert_record('paypal_transaction_log',$paypal_transaction_log);

                            $admin_paypal_commission['advisor_id']       = $request['advisor_id'];
                            $admin_paypal_commission['payout_item_id']   = json_decode($payment_status,true)['items'][0]['payout_item_id'];
                            $admin_paypal_commission['payout_batch_id']  = $payout_batch_id;
                            $admin_paypal_commission['booking_id']       = $ids;
                            $admin_paypal_commission['amount']           = $request['amount'];
                            $admin_paypal_commission['admin_commission'] = $admin_details['value'];
                            $admin_paypal_commission['created_at']       = $current_date;
                            $this->comman->insert_record('admin_paypal_commission_log',$admin_paypal_commission);

                            $wallet_data['user_id']     = $request['advisor_id'];
                            $wallet_data['amount_type'] = "withdraw";
                            $wallet_data['amount']      = $amount;
                            $wallet_data['created_at']  = $current_date;
                            $this->comman->insert_record('wallet',$wallet_data);

                            $this->db->query('UPDATE advisor_amount_log SET status = 3,updated_at = "'.$current_date.'" WHERE booking_id IN('.$ids.')');

                            $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,CAST(SUM(amount) AS DECIMAL(10,2)) as total_withdrawed_amount')
                                        ->from('users')
                                        ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
                                        ->where('users.id',$request['advisor_id'])
                                        ->get()->row_array();
                            $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
                                       
                            $my_earning['total_earning'] = (string)$total;
                            $available = $this->available($request['advisor_id'],'sum');
                            $my_earning['available_for_withdraw'] = (!empty($available) && $available[0]['advisor_available_amount'] != 0 && $available[0]['advisor_available_amount'] != null) ? $available[0]['advisor_available_amount'] : "0";

                            $data['status'] = TRUE;
                            $data['my_earning_details'] = $my_earning;
                            $data['message'] = "Withdrawal Amount is Pending, Please wait!";                            

                        }
                        else if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'UNCLAIMED'){

                            sleep(5);

                            $unclaimed = json_decode(cancel_unclaimed_payment(json_decode($payment_status,true)['items'][0]['payout_item_id'],$token),true);
                            if(!empty($unclaimed) && isset($unclaimed['transaction_status']) && $unclaimed['transaction_status'] == "RETURNED"){

                                $available = $this->available($request['advisor_id'],'booking_id');
                                $ids = implode(',',array_column($available,'id'));

                                $paypal_transaction_log['user_id'] = $request['advisor_id'];
                                $paypal_transaction_log['booking_id'] = $ids;
                                $paypal_transaction_log['amount'] = $amount;
                                $paypal_transaction_log['payout_item_id'] = json_decode($payment_status,true)['items'][0]['payout_item_id'];
                                $paypal_transaction_log['payout_batch_id'] = $payout_batch_id;
                                $paypal_transaction_log['items'] = json_encode(json_decode($payment_status,true)['items'][0],true);
                                $paypal_transaction_log['status'] = 3;
                                $paypal_transaction_log['token'] = $token;
                                $paypal_transaction_log['created_at'] =  $current_date;
                                $this->comman->insert_record('paypal_transaction_log',$paypal_transaction_log);

                                $withdrawal_update['status'] = 3;
                                $withdrawal_update['booking_ids'] = $ids;
                                $data['status'] = FALSE;
                                $data['message'] = "Transferred failed! You don't have Paypal account associated with email that you provided. Please first open your Paypal Account.";

                            }else{
                                $data['status'] = FALSE;
                                $data['message'] = "Transferred failed due to technical reason.";
                                $withdrawal_update['status'] = 2;
                            }    
                        }
                        else{
                            $data['status'] = FALSE;
                            $data['message'] = "Transferred failed due to technical reason.";
                            $withdrawal_update['status'] = 2;
                        }
                        $withdrawal_update['success_response'] = $payment_status;
                        $this->comman->update_record('withdrawal_log', $withdrawal_update, $withdrawal_log_id);
                    }else{
                        $data['status'] = FALSE;
                        $data['message'] = "Transferred failed due to ".json_decode($response['response'],true)['name'];
                    }
                }
            // }else{
            //     $data['status'] = FALSE;
            //     $data['message'] = "withdrawal amount should be minimun at least 100";
            // }
        }

        $this->response($data);

    }


    // else if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'UNCLAIMED'){

    //     $withdrawal_amount = $advisor_details['advisor_withdrawal_amount'] - $request['amount'];
    //     $update_data['advisor_withdrawal_amount'] = $withdrawal_amount;
    //     $this->comman->update_record('users', $update_data, $request['advisor_id']);

    //     $available = $this->available($request['advisor_id'],'booking_id');
    //     $ids = implode(',',array_column($available,'id'));

    //     $withdrawal_update['status'] = 3;
    //     $withdrawal_update['booking_ids'] = $ids;

    //     $paypal_transaction_log['user_id'] = $request['advisor_id'];
    //     $paypal_transaction_log['booking_id'] = $ids;
    //     $paypal_transaction_log['amount'] = $amount;
    //     $paypal_transaction_log['payout_item_id'] = json_decode($payment_status,true)['items'][0]['payout_item_id'];
    //     $paypal_transaction_log['payout_batch_id'] = $payout_batch_id;
    //     $paypal_transaction_log['items'] = json_encode(json_decode($payment_status,true)['items'][0],true);
    //     $paypal_transaction_log['status'] = 3;
    //     $paypal_transaction_log['created_at'] =  $current_date;
    //     $this->comman->insert_record('paypal_transaction_log',$paypal_transaction_log);

    //     $wallet_data['user_id']     = $request['advisor_id'];
    //     $wallet_data['amount_type'] = "withdraw";
    //     $wallet_data['amount']      = $amount;
    //     $wallet_data['created_at']  = $current_date;
    //     $this->comman->insert_record('wallet',$wallet_data);

    //     $my_earning = $this->db->select('users.id as advisor_id,users.advisor_withdrawal_amount as pending_withdraw_amount,CAST(SUM(amount) AS DECIMAL(10,2)) as total_withdrawed_amount')
    //                 ->from('users')
    //                 ->join('wallet','users.id = wallet.user_id AND wallet.amount_type = "withdraw"','left')
    //                 ->where('users.id',$request['advisor_id'])
    //                 ->get()->row_array();
    //     $total = $my_earning['pending_withdraw_amount'] + $my_earning['total_withdrawed_amount'];
                   
    //     $my_earning['total_earning'] = (string)$total;
    //     $available = $this->available($request['advisor_id'],'sum');
    //     $my_earning['available_for_withdraw'] = (!empty($available) && $available[0]['advisor_available_amount'] != 0 && $available[0]['advisor_available_amount'] != null) ? $available[0]['advisor_available_amount'] : "0";

    //     $data['status'] = TRUE;
    //     $data['my_earning_details'] = $my_earning;
    //     $data['message'] = "Your withdrawal request is Unclaimed because you dont have paypal account with paypal email you provide to us.To claim, open account within 30 days!";

    // }
    // else if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'BLOCKED'){
        
    //     $data['status'] = FALSE;
    //     $data['message'] = "Your Withdrawal request has been Blocked.Please contact admin!";
    //     $withdrawal_update['status'] = 2;
    // }




        // else if(json_decode($payment_status,true)['items'][0]['transaction_status'] == 'PENDING'){
    
        //     $available = $this->available($request['advisor_id'],'booking_id');
        //     $ids = implode(',',array_column($available,'id')); 

        //     $withdrawal_update['user_id'] = $request['advisor_id'];
        //     $withdrawal_update['status'] = 3;
        //     $withdrawal_update['booking_ids'] = $ids;

        //     $withdrawal_amount = $advisor_details['advisor_withdrawal_amount'] - $request['amount'];
        //     $update_data['advisor_withdrawal_amount'] = $withdrawal_amount;
        //     $this->comman->update_record('users', $update_data, $request['advisor_id']);

        //     $paypal_transaction_log['user_id'] = $request['advisor_id'];
        //     $paypal_transaction_log['amount'] =$amount;
        //     $paypal_transaction_log['payout_item_id'] = json_decode($payment_status,true)['items'][0]['payout_item_id'];
        //     $paypal_transaction_log['status'] = 0;
        //     $paypal_transaction_log['created_at'] =  $current_date;

        //     $advisor_amount_log['advisor_id'] =$request['advisor_id'];
        //     $advisor_amount_log['status'] = 3;
        //     $advisor_amount_log['updated_at'] = $current_date;

        // }

    public function available($id,$type = ''){
 
        //FORMAT(SUM(booking_request.advisor_commission),2)
        $select = "REPLACE(FORMAT(SUM(booking_request.advisor_commission),2), ',', '') as advisor_available_amount";
        if($type == 'booking_id'){
            $select = 'booking_request.id,booking_request.advisor_commission';
        }

        $where = "advisor_amount_log.status = 0 AND DATE(booking_request.end_time) <= DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)";
        $available = $this->db->select($select)->from('booking_request')
                            ->join('advisor_amount_log','booking_request.id = advisor_amount_log.booking_id')
                            ->where('booking_request.advisor_id',$id)
                            ->where('booking_request.status != 2')
                            ->where('booking_request.end_time IS NOT NULL')
                            ->where('booking_request.is_session_running',1)
                            ->where($where)->get()->result_array();

        if($type != 'booking_id'){
            foreach ($available as $key => $value) {
                if($type != 'booking_id'){
                    $row[$key] = $value;
                    $row[$key]['advisor_available_amount'] = str_replace(',','',$value['advisor_available_amount']);
                }
            }
            $available = $row;
        }
                                                    
        return $available;
    } 

    public function save_session_note_post() {

        $this->form_validation->set_rules('booking_id', 'booking id', 'required');
        $this->form_validation->set_rules('note', 'note', 'required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
        
            $this->comman->update_record('booking_request', ['note' => $request['note']], $request['booking_id']);
            
            $response['status'] = true;
            $response['message'] = 'Note Save Successfully';
        }
        $this->response($response);
    }

    public function end_session_post(){

        $this->form_validation->set_rules('booking_id', 'booking id', 'required');

        $this->form_validation->set_rules('type', 'type', 'required|trim|in_list[customer,advisor]');

        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post();
            
            $booking_details = $this->db->select('booking_request.id as booking_id,category.name as category_name,booking_request.advisor_id,booking_request.user_id,booking_request.total,booking_request.advisor_commission,booking_request.session_minute,booking_request.free_minute,booking_request.promocode_minute,booking_request.total,booking_request.offer_id,promocode_log.id as promocode_log_id,promocode_log.total_minute,promocode_log.chargeable_minute,promocode_log.booking_amount,promocode_log.chargeable_amount,advisor_amount')->from('booking_request')
                    ->join('promocode_log','booking_request.id = promocode_log.booking_id','left')
                    ->join('category','booking_request.category_id = category.id','left')
                    ->where('booking_request.id',$request['booking_id'])
                    ->get()->row_array();

                    $customer_data['total_minute'] = ($booking_details['promocode_minute'] != 0) ? $booking_details['promocode_minute'] : $booking_details['session_minute'];
                    $customer_data['category_name'] = $booking_details['category_name'];
                    $customer_data['booking_amount'] =  ($booking_details['offer_id'] != '' && $booking_details['offer_id'] != NULL) ? $booking_details['booking_amount'] : $booking_details['total'];
                    // $customer_data['total_chargeable_amount'] = ($booking_details['offer_id'] != '' && $booking_details['offer_id'] != NULL) ? $booking_details['chargeable_amount'] : $booking_details['total'];
                    $customer_data['total_chargeable_amount'] =  $booking_details['total'];
                    $customer_data['free_minute'] = "0".$booking_details['free_minute'].":00";
                    $customer_data['discount_type'] = '';
                    $customer_data['discount_value'] = '0';

                    $advisor_commission = $this->db->select('value')->from('settings')->where('name','advisor_commission')->get()->row_array();
                    $advisor_data['total_minute'] = ($booking_details['promocode_minute'] != 0) ? $booking_details['promocode_minute'] : $booking_details['session_minute'];
                    $advisor_data['category_name'] = $booking_details['category_name'];
                    $advisor_data['session_earning'] = $booking_details['advisor_commission'];
                    $advisor_data['commission_rate']    = $advisor_commission['value'];
                    $advisor_data['free_minute']    = "0".$booking_details['free_minute'].":00";
                    $advisor_data['advisor_special_day_commission'] = '0';

                    if(!empty($booking_details['offer_id']) && $booking_details['offer_id'] != NULL && $booking_details['offer_id'] != ''){

                        $promocode_details = $this->db->query('SELECT * FROM promocode WHERE id IN('.$booking_details['offer_id'].')')->result_array();
                        
                        foreach ($promocode_details as $key => $value) {
                            // if($value['promocode_for'] == 'customer' && $value['promocode_type'] == 'first_time' && $value['free_minute'] != ''){
                            //     $customer_data['free_minute'] = $value['free_minute'];
                            // }
                            if($value['promocode_for'] == 'customer' && $value['promocode_type'] == 'birthday' && $value['discount_type'] != '' && $value['discount_value'] != ''){
                                $customer_data['discount_type']              = $value['discount_type'];
                                $customer_data['discount_value']             = $value['discount_value'];
                                //$customer_data['booking_amount']             = $booking_details['booking_amount'];
                                //$customer_data['total_chargeable_amount']    = $booking_details['chargeable_amount'];
                            }
                            if($value['promocode_for'] == 'advisor' && $value['discount_value'] != '' && $value['special_day_date'] != ''){
                                $advisor_data['advisor_special_day_commission'] = $value['discount_value'];
                            }
                        }
                    }

            $response['status'] = TRUE;
            $response['data'] = $customer_data;
            $response['message'] = "Session End";
            if($request['type'] == 'advisor'){
                $response['data'] = $advisor_data;
                $response['message'] = "Congratulations! You have earned $".$booking_details['advisor_commission']." from this session";
            }
        }

        $this->response($response);
    }

    public function get_availability_post(){

        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $availability = $this->db->select('category_id, user_id, type, price, status, price as discount_price')->from('availability')->where('user_id',$request['advisor_id'])->get()->result_array();

            $availible_options = array_values(array_filter($availability, function($val){
                return $val['status'] == 1;
            }));

            $data['status'] = TRUE;

            $data['availabile_for'] = implode(',',array_unique(array_column($availible_options, 'type')));
        }

        $this->response($data);
    }

    public function voip_post(){

        $advisor_id = $_POST['advisor_id'];
        $twi_call_sid = $_POST['twi_call_sid'];
        $twi_bridge_token = $_POST['twi_bridge_token'];
        $twi_account_sid = $_POST['twi_account_sid'];
        $twi_from = $_POST['twi_from'];
        $twi_to = $_POST['twi_to'];
        $user_id = $_POST['user_id'];
        $booking_id = $_POST['booking_id'];
        $receiver_token = $_POST['receiver_token'];

        $data['status'] = FALSE;
        $data['advisor_id'] = $advisor_id;

        $token = $this->db->select('voip_device_token')->from('users')->where('id',$advisor_id)->get()->row_array();

        if($advisor_id != '' && $token['voip_device_token'] != '')
        {
            $device_token   = $token['voip_device_token'];
            // $pem_file       = 'assets/voip2.pem';
            $pem_file       = 'assets/TempleblissVOIP.pem';
            $pem_secret     = 'apple';
            // $apns_topic     = 'excellentWebworld.VideoCallTwilioDemo.voip';
            $apns_topic     = 'com.ecg.TempleBliss.voip';
            
            $sample_alert = '{"aps":{"alert":"Video Call","sound":"default","body":"video"},"twi_call_sid":"'.$twi_call_sid.'","twi_bridge_token":"'.$twi_bridge_token.'","twi_message_type":"twilio.video.call","twi_account_sid":"'.$twi_account_sid.'","twi_from":"'.$twi_from.'","twi_to":"'.$twi_to.'","user_id":"'.$user_id.'","advisor_id":"'.$advisor_id.'","booking_id":"'.$booking_id.'","user_name":"'.$twi_from.'","receiver_token":"'.$receiver_token.'"}';
            $url = "https://api.development.push.apple.com/3/device/".$device_token;

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $sample_alert);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("apns-topic: $apns_topic"));
            curl_setopt($ch, CURLOPT_SSLCERT, $pem_file);
            curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pem_secret);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $data['response'] = $response;
            $data['httpcode'] = $httpcode;
            $data['status'] = TRUE;
            $data['token'] = $token['voip_device_token'];
        }

        $this->response($data);

    }

    public function voip_normal_post(){
  
        $advisor_id = $_POST['advisor_id'];
        $user_id = $_POST['user_id'];
        $type = $_POST['type'];
        $start_time = $_POST['start_time'];
        $customer_profile_picture = $_POST['customer_profile_picture'];
        $message = $_POST['message'];
        $default_message = $_POST['default_message'];
        $advisor_profile_picture = $_POST['advisor_profile_picture'];
        $booking_id = $_POST['booking_id'];
        $customer_name = $_POST['customer_name'];
        $twi_from = $_POST['twi_from'];
        $twi_to = $_POST['twi_to'];

        $data['status'] = FALSE;
        $data['advisor_id'] = $advisor_id;

        $token = $this->db->select('voip_device_token')->from('users')->where('id',$advisor_id)->get()->row_array();

        if($advisor_id != '' && $token['voip_device_token'] != '')
        {
            $device_token   = $token['voip_device_token'];
            // $pem_file       = 'assets/voip2.pem';
            $pem_file       = 'assets/TempleblissVOIP.pem';
            $pem_secret     = 'apple';
            // $apns_topic     = 'excellentWebworld.VideoCallTwilioDemo.voip';
            $apns_topic     = 'com.ecg.TempleBliss.voip';
            
            $sample_alert = '{"aps":{"alert":"Video Call","sound":"default","body":"video"},"user_id":"'.$user_id.'","advisor_id":"'.$advisor_id.'","twi_from":"'.$twi_from.'","twi_to":"'.$twi_to.'","twi_message_type":"twilio.chat.call","booking_id":"'.$booking_id.'","type":"'.$type.'","start_time":"'.$start_time.'","customer_profile_picture":"'.$customer_profile_picture.'","advisor_profile_picture":"'.$advisor_profile_picture.'","customer_name":"'.$customer_name.'","default_message":"'.$default_message.'","message":"'.$message.'"}';
            $url = "https://api.development.push.apple.com/3/device/".$device_token;

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $sample_alert);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("apns-topic: $apns_topic"));
            curl_setopt($ch, CURLOPT_SSLCERT, $pem_file);
            curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pem_secret);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $data['response'] = $response;
            $data['httpcode'] = $httpcode;
            $data['status'] = TRUE;
            $data['token'] = $token['voip_device_token'];
        }

        $this->response($data);

    }

}
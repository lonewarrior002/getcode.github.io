<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Auth extends REST_Controller {
    function __construct() {
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        parent::__construct();
        $this->load->model('ion_auth_model');
        $this->load->library('Twilio');
    }
    public function login_post() {
        if (isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {
            $auth = validate_key($_SERVER['HTTP_KEY']);
            if ($auth) {
                $this->form_validation->set_rules('user_name', 'user_name', 'required');
                $this->form_validation->set_rules('password', 'password', 'required');
                $this->form_validation->set_rules('device_token', 'device token', 'required');
                $this->form_validation->set_rules('device_type', 'device type', 'required');
                $this->form_validation->set_rules('role', 'role', 'required|in_list[2,3]');
                if ($this->form_validation->run() == FALSE) {
                    $data['status'] = false;
                    $data['message'] = validation_errors_response();
                } else {
                    $request = $this->post();
                    $login = $this->ion_auth->api_login($request['user_name'], $request['password'], $request['device_token'], $request['device_type'], 0, 0, FALSE, $request['role']);
                    if ($login) {
                        if ($login->active == STATUS_ACTIVE) {
                            $data['status'] = true;
                            $profile = $this->comman->get_record_byid('users', $login->id);
                            $profile['api_key'] = $this->_generate_key($login->id);
                            if($profile['quick_tour'] == 0){
                                $profile['quick_tour'] = "1";
                                $this->comman->update_record('users', ['quick_tour' => 2], $login->id);
                            }
                            $data['profile'] = $profile;
                            $availability = array();
                            
                            if($request['role'] == SERVICE_PROVIDER) {
                                if($profile['approve_advisor_detail'] || $profile['is_logged_in'] || empty($profile['category_id'])) {
                                    if(!empty($profile['category_id'])) {
                                        $this->comman->update_record('users', ['is_logged_in' => 1], $login->id);
                                        $this->comman->insert_record('login_logs', ['user_id' => $login->id, 'created_at' => current_date()]);
                                    }
                                    $availability = [];
                                    if(!empty($profile['category_id'])) {
                                        $registerd_categories = $this->db->select('category_id, type, price,created_at,updated_at')->from('availability')->where('user_id', $login->id)->where('category_id IN ('.$profile['category_id'].')')->get()->result_array();
                                    
                                        foreach ($registerd_categories as $key => $value) {
                                            $latest_row = $this->db->select('created_at')->from('price_change_log')->where('user_id', $login->id)->where('new_category_id', $value['category_id'])->where('type', $value['type'])->order_by('id', 'desc')->get()->row_array();

                                            $availability[$key] = $value;
                                            $availability[$key]['last_updated_date'] =  date('Y-m-d', strtotime($value['created_at']));
                                            if($value['updated_at'] != ''){
                                                $availability[$key]['last_updated_date'] =  date('Y-m-d', strtotime($value['updated_at']));
                                            }
                                                //date('Y-m-d');
                                            if(!empty($latest_row)) {
                                                $availability[$key]['last_updated_date'] = date('Y-m-d', strtotime($latest_row['created_at']));
                                            }
                                        }
                                    }
                                    $data['availability'] = $availability;
                                    $data['message'] = "Login successfully.";
                                    $this->comman->update_record_by_condition('availability', ['status' => STATUS_INACTIVE],['user_id'=>$login->id]);
                                    $this->comman->update_record('users', ['device_token' => $request['device_token']], $login->id);
                                } else {
                                    unset($data['profile']);
                                    $data['status'] = false;
                                    // $existing_user = $this->comman->get_record_by_condition('login_logs', ['user_id' => $login->id]);
                                    $data['message'] = "Your request to become an advisor is under approval within admin";
                                    // if(!empty($existing_user)) {
                                    //     $data['message'] = "Your new edited profile is under review, please wait for the admin approval";
                                    // }
                                }
                            } else {
                                $this->comman->update_record('users', ['is_logged_in' => 1], $login->id);
                                $this->comman->insert_record('login_logs', ['user_id' => $login->id, 'created_at' => current_date()]);
                            }
                        } else {
                            $data['status'] = false;
                            $data['message'] = "This account is not activated!";
                        }
                    } else {
                        $data['status'] = false;
                        $data['message'] = "Incorrect credentials";
                    }
                }

            } else {
                $data['status'] = false;
                $data['message'] = 'Authorization failed';
            }

        } else {
            $data['status'] = false;
            $data['message'] = 'Authorization key is required';
        }
        
        $this->response($data);
    }
    
    public function social_login_post() {
        if (isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {
            $auth = validate_key($_SERVER['HTTP_KEY']);
            if ($auth) {
                $this->form_validation->set_rules('user_name', 'user name', 'trim');
                $this->form_validation->set_rules('device_token', 'device token', 'trim|required');
                $this->form_validation->set_rules('device_type', 'device type', 'trim|required');
                $this->form_validation->set_rules('social_type', 'social type', 'trim|required');
                $this->form_validation->set_rules('social_id', 'social id', 'trim|required');
                if ($this->form_validation->run() == FALSE) {
                    $data['status'] = false;
                    $data['message'] = validation_errors_response();
                } else {
                    $request = $this->post();
                    $grp = $this->config->item('roles', 'ion_auth')['customer'];
                    
                    $query = $this->db->select('t1.*')->from('users t1')
                            ->join('users_groups t2', 't1.id = t2.user_id')
                            ->where('t2.group_id', $grp)
                            ->where('t1.deleted_at', null)
                            ->group_start()
                            ->where('t1.email', ($request['user_name']) ?? '')
//                            ->where('t1.social_type', $request['social_type'])
//                            ->where('t1.social_id', $request['social_id'])
                            ->group_end()
                            ->get();
//                    echo $this->db->last_query();die();
                    if ($query->num_rows() === 1) {
                        $user = $query->row_array();
                        if ($user['active'] == STATUS_ACTIVE) {
                             
                            if($request['device_token'] != $user['device_token']) {
                                send_push($user['id'], 'users', SITENAME , 'Session Expired', 'logout');
                            }
                            $this->db->where('id', $user['id'])->update('users', ['device_token' => $request['device_token'], 'device_type' => $request['device_type'], 'social_type' => $request['social_type'], 'social_id' => $request['social_id']]);

                            $data['status']  = true;
                            //$user = (array)$user;
                            $user['api_key'] = $this->_generate_key($user['id']);
                            $data['is_user_exist'] = true;
                            
                            $data['profile'] = $user;
                            if($user['quick_tour'] == 0){
                                $data['profile']['quick_tour'] = "1";
                                $this->comman->update_record('users', ['quick_tour' => 2], $user['id']);
                            }
                            $data['message'] = "Login successfully.";
                        } else {
                            $data['is_user_exist'] = true;
                            $data['status'] = false;
                            $data['message'] = "This account is not activated!";
                        }
                    } else {
                        if($request['social_type'] != 'apple'){
                            $data['status'] = false;
                            $data['message'] = "User does not exist";
                            $data['is_user_exist'] = false;
                            $data['required_login'] = true;
                        } else {
                            $data = $this->register_apple_user($request);
                        }
                    }
                }
            } else {
                $data['status'] = false;
                $data['message'] = 'Authorization failed';
            }
        } else {
            $data['status'] = false;
            $data['message'] = 'Authorization key is required';
        }
        $this->response($data);
    }
    
    public function register_apple_user($post_arr = []) {
        if(count($post_arr)) {
            $this->form_validation->set_rules('user_name', 'user_name', 'trim|required|callback_isexists[' . CUSTOMER . ']');
            if ($this->form_validation->run() == FALSE) {
                $data['status'] = false;
                $data['message'] = validation_errors_response();
            } else {
                $create_user = [
                    'email'        => strtolower($post_arr['user_name']),
                    'device_type'  => intval($post_arr['device_type']),
                    'device_token' => $post_arr['device_token'],
                    'social_id'    => $post_arr['social_id'],
                    'social_type'  => $post_arr['social_type']
                ];
                $check_for_details = $this->db->query('select first_name, last_name from AppleAccountHolder where apple_id="'.$post_arr['social_id'].'"')->row_array();
                if(!empty($check_for_details) && count($check_for_details) > 0) { 
                    $create_user['first_name'] = $check_for_details['first_name'];
                    $create_user['last_name'] = $check_for_details['last_name'];
                    $create_user['full_name'] = $create_user['first_name'].' '.$create_user['last_name'];
                }

                $user_id = $this->ion_auth->register($post_arr['user_name'], DEFAULT_PASSWORD, $post_arr['user_name'], $create_user, [CUSTOMER]);
                
                if ($user_id != "" && $user_id > 0) {
                    $profile = $this->comman->get_record_byid('users', $user_id);
                    $profile['api_key'] = $this->_generate_key($user_id);
                    $data['status']  = true;
                    $data['profile'] = $profile;
                    $data['message'] = "Register successfully";
                } else {
                    $data['user_id'] = $user_id;
                    $data['status'] = false;
                    $data['message'] = "Something went wrong!";
                }
            }
        } else {
            $data['message'] = 'params missing';
            $data['status'] = false;
        }
        return $data;
    }
    
    public function apple_details_post() {
        if(isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {
            $auth = validate_key($_SERVER['HTTP_KEY']);
            if ($auth) {
                $this->form_validation->set_rules('apple_id', 'apple_id', 'trim|required');
                if ($this->form_validation->run() == FALSE) {
                    $response['status'] = false;
                    $response['message'] = validation_errors_response();
                } else {
                    $post_fields['apple_id'] = $_POST['apple_id'];
                    if(empty($error_post)) {
                        $check_for_details = $this->db->query('select first_name, last_name, email, apple_id from AppleAccountHolder where apple_id="'.$post_fields['apple_id'].'"')->row_array();
                        if(!empty($check_for_details) && count($check_for_details) > 0) {
                            $response['status'] = TRUE;
                            $response['message'] = '';
                            $response['apple_detail'] = $check_for_details;
                        } else {
                            if(isset($_POST['first_name']) && $_POST['first_name'] != '' && isset($_POST['last_name']) && $_POST['last_name'] != '') {
                                $post_fields['first_name'] = $_POST['first_name'];
                                $post_fields['last_name'] = $_POST['last_name'];
                                $post_fields['email'] = (isset($_POST['email']) && !empty($_POST['email'])) ? $_POST['email'] : '';
                                $this->db->insert('AppleAccountHolder', $post_fields);

                                $response['status'] = TRUE;
                                $response['message'] = '';
                                $response['apple_detail'] = $post_fields;
                                
                            } else {
                                $response['status'] = FALSE;
                                // $response['message'] = 'First name & Last name paramters missing';
                                $response['message'] = 'There was an error connecting to the Apple ID server. Go to Setting -> Password & Security->App using your Apple ID->TempleBliss->Stop using apple ID';
                            }
                        }
                    } else {
                        $response['status'] = FALSE;
                        $response['message'] = (count($error_post) == 1) ? $error_post[0] : $error_post;
                    }
                }
            } else {
                $response['status'] = false;
                $response['message'] = 'Authorization failed';
            }
        } else {
            $response['status'] = FALSE;
            $response['message'] = 'Authorization key is required';
        }
        
        $this->response($response);
    }

    public function otp_register_post() {
        
        if (isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {
            $auth = validate_key($_SERVER['HTTP_KEY']);
            if ($auth) {
                $data['status'] = true;
                $request = $this->post();
                
                $this->form_validation->set_rules('role', 'role', 'trim|required|in_list[2,3]');
                $this->form_validation->set_rules('full_name', 'full name', 'trim|required');
                $this->form_validation->set_rules('email', 'email', 'trim|required|callback_isexists[' . $request['role'] . ']');
                $this->form_validation->set_rules('phone', 'Phone', 'trim|required|numeric|callback_isexists[' . $request['role'] . ']');
                $this->form_validation->set_rules('device_token', 'device token', 'trim|required');
                $this->form_validation->set_rules('device_type', 'device type', 'trim|required');
                $this->form_validation->set_rules('password', 'password', 'trim|required|min_length[8]');
                $this->form_validation->set_rules('confirm_password', 'confirm password', 'trim|required|min_length[8]|matches[password]');
                $this->form_validation->set_rules('dob', 'date of birth', 'trim|required');
                $this->form_validation->set_rules('social_type', 'social type', 'trim');
                $this->form_validation->set_rules('social_id', 'social id', 'trim');
//                $this->form_validation->set_rules('category_id', 'category_id', 'trim');
                $this->form_validation->set_rules('nick_name', 'nick_name', 'trim');
                $this->form_validation->set_rules('advisor_description', 'advisor_description', 'trim');
                if ($this->form_validation->run() == FALSE) {
                    $data['status'] = false;
                    $data['message'] = validation_errors_response();
                } else {
                    if($request['role'] == SERVICE_PROVIDER) {
//                        if(!isset($request['category_id']) || empty($request['category_id']) || null($request['category_id']) ) {
//                            $data['status'] = false;
//                            $data['message'] = "Category id field is required.";
//                        } elseif(!isset($request['nick_name']) || empty($request['nick_name']) || null($request['nick_name']) ) {
                        if(!isset($request['nick_name']) || empty($request['nick_name']) || is_null($request['nick_name']) ) {
                            $data['status'] = false;
                            $data['message'] = "Nick name field is required.";
                        } elseif(!isset($request['advisor_description']) || empty($request['advisor_description']) || is_null($request['advisor_description']) ) {
                            $data['status'] = false;
                            $data['message'] = "Description field is required.";
                        }
                    }
                    if($data['status']) {
                        $otp = rand(111111,999999);
                        $subject = $this->config->item('site_name').' - OTP verification';
                        $path = BASE_URL().'email_templates/otp_register.html';
                        $template = file_get_contents($path);                     
                        $template = create_email_template($template);

                        $template = str_replace('##OTP##', $otp, $template);
                        $template = str_replace('##EMAIL##', $request['email'], $template);
                        $sent = sendEmail($subject, $request['email'], $template);

                        if(!in_array(substr($request['phone'], 0 ,1), [0,1,'+']) && strlen($request['phone']) == 10 ) {
//                            $this->twilio->send_sms('1'.$request['phone'], 'RxNowHub code: '.$otp .' Do not share it or use it elsewhere!');
                        }

                        $data['message'] = 'OTP sent successfully.';

                        $data['otp'] = $otp;
                    }
                }
            } else {
                $data['status'] = false;
                $data['message'] = 'Authorization failed';
            }
        } else {
            $data['status'] = false;
            $data['message'] = 'Authorization key is required';
        }
        $this->response($data);
    }
    
    public function register_post() {
        
        if (isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {
            $auth = validate_key($_SERVER['HTTP_KEY']);
            if ($auth) {
                $data['status'] = true;
                $request = $this->post();
                if(isset($request['role']) && !empty($request['role']) && $request['role'] != NULL){
                   $this->form_validation->set_rules('role', 'role', 'trim|required|in_list[2,3]');
                    $this->form_validation->set_rules('full_name', 'full name', 'trim|required');
                    $this->form_validation->set_rules('email', 'email', 'trim|required|callback_isexists[' . $request['role'] . ']');
                    $this->form_validation->set_rules('phone', 'Phone', 'trim|required|numeric|callback_isexists[' . $request['role'] . ']');
                    $this->form_validation->set_rules('device_token', 'device token', 'trim|required');
                    $this->form_validation->set_rules('device_type', 'device type', 'trim|required');
                    $this->form_validation->set_rules('password', 'password', 'trim|required|min_length[8]');
                    $this->form_validation->set_rules('confirm_password', 'confirm password', 'trim|required|min_length[8]|matches[password]');
                    $this->form_validation->set_rules('dob', 'date of birth', 'trim|required');
                    $this->form_validation->set_rules('social_type', 'social type', 'trim');
                    $this->form_validation->set_rules('social_id', 'social id', 'trim');
//                    $this->form_validation->set_rules('category_id', 'category_id', 'trim');
                    $this->form_validation->set_rules('nick_name', 'nick_name', 'trim');
                    $this->form_validation->set_rules('advisor_description', 'advisor_description', 'trim');
                    if ($this->form_validation->run() == FALSE) {
                        $data['status'] = false;
                        $data['message'] = validation_errors_response();
                    } else {
                        $create_user = [];
                        if($request['role'] == SERVICE_PROVIDER) {
//                            if(!isset($request['category_id']) || empty($request['category_id']) || is_null($request['category_id']) ) {
//                                $data['status'] = false;
//                                $data['message'] = "Category id field is required.";
//                            } elseif(!isset($request['nick_name']) || empty($request['nick_name']) || null($request['nick_name']) ) {
                            if(!isset($request['nick_name']) || empty($request['nick_name']) || is_null($request['nick_name']) ) {
                                $data['status'] = false;
                                $data['message'] = "Nick name field is required.";
                            } elseif(!isset($request['advisor_description']) || empty($request['advisor_description']) || is_null($request['advisor_description']) ) {
                                $data['status'] = false;
                                $data['message'] = "Description field is required.";
                            } 
                        }
                        if($data['status']) {
                            
                            $create_user = [
                                'full_name'    => $request['full_name'],
                                'email'        => strtolower($request['email']),
                                'phone'        => $request['phone'],
                                // 'address'      => $request['address'],
                                'password'     => $request['password'],
                                'device_type'  => intval($request['device_type']),
                                'device_token' => $request['device_token'],
                                'dob'          => $request['dob'],
                                'social_id'    => ($request['social_id']) ?? 0,
                                'social_type'  => ($request['social_type']) ?? 0
                            ];
                            if($request['role'] == SERVICE_PROVIDER) {
                                $create_user['nick_name'] = $request['nick_name'];
                                $create_user['advisor_description'] = $request['advisor_description'];
                            }
                            
                            $user_id = $this->ion_auth->register($request['email'], $request['password'], $request['email'], $create_user, [$request['role']]);

                            if ($user_id != "" && $user_id > 0) {
                                if($request['role'] == SERVICE_PROVIDER) {
                                    $profile = $this->comman->get_record_byid('users', $user_id);
                                    $profile['api_key'] = $this->_generate_key($user_id);
                                    $data['profile']    = $profile;
                                }
                                // $profile = $this->comman->get_record_byid('users', $user_id);
                                // $profile['api_key'] = $this->_generate_key($user_id);
                                // $data['profile']    = $profile;
                                $data['status']  = true;
                                $data['message'] = "Registered successfully! Email verification link has been sent to your registered email";
                            } else {
                                $data['user_id'] = $user_id;
                                $data['status']  = false;
                                $data['message'] = "Something went wrong!";
                            }                                
                        }
                    }
                } else {
                    $data['status'] = false;
                    $data['message'] = "Role field is required";
                } 
            } else {
                $data['status'] = false;
                $data['message'] = 'Authorization failed';
            }
                
        } else {
            $data['status'] = false;
            $data['message'] = 'Authorization key is required';
        }
        $this->response($data);
    }
    
    public function isexists($str = NULL, $grp = NULL) {
        
            $this->db->select('t1.*');
            $this->db->group_start();
            $this->db->where('t1.email', trim($str));
            $this->db->or_where('t1.phone', trim($str));
            $this->db->group_end();
            $this->db->where('t1.deleted_at', NULL);
            $this->db->where('t2.group_id', $grp);
            $this->db->from('users t1');
            $this->db->join('users_groups t2', 't1.id = t2.user_id');
            
            $this->db->limit(1);
            $sql_query = $this->db->get();
            if ($sql_query->num_rows() > 0) {
                $this->form_validation->set_message('isexists', (is_numeric($str)) ? "The phone is already exists": "The email is already exists");
                return false;
            } else {
                return true;
            }
        
        
    }
    public function forgot_password_post() {
        if (isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {
            $auth = validate_key($_SERVER['HTTP_KEY']);
            if ($auth) {
                $this->form_validation->set_rules('email', 'email', 'required');
                
                $this->form_validation->set_rules('role', 'role', 'required');
                if ($this->form_validation->run() == FALSE) {
                    $data['status'] = false;
                    $data['message'] = validation_errors_response();
                } else {
                    $email = $this->post('email');
                    $role = $this->post('role');
                    
                    $this->db->select('t1.id, t1.email,t1.active');
                    $this->db->from('users t1');
                    $this->db->where('t1.email', $email);
                    $this->db->where('t2.group_id', $role);
                    $this->db->join('users_groups t2', 't1.id = t2.user_id');
                    $this->db->limit(1);
                    $this->db->order_by('t1.id', 'desc');
                    $sql_query = $this->db->get();
                    
                    if ($sql_query->num_rows() > 0) {
                        $return_data = $sql_query->row();
                        if($return_data->active) {
                            $result = $this->ion_auth->forgotten_password($email, $return_data);
                            if ($result == TRUE) {
                                $data['status'] = true;
                                $data['message'] = "Reset password link sent to your email address";
                            } else {
                                $data['message'] = "Something went wrong";
                            }
                            $data['result'] = $result;
                        } else {
                            $data['status'] = false;
                            $data['message'] = "Account not activated.";
                        }
                    } else {
                        $data['status'] = false;
                        $data['message'] = "This email is not registered.";
                    }
                }
            } else {
                $data['status'] = false;
                $data['message'] = 'Authorization failed';
            }
        } else {
            $data['status'] = false;
            $data['message'] = 'Authorization key is required';
        }
        $this->response($data);
    }
    
    public function logout_post() {
        // log the user out
        $this->form_validation->set_rules('user_id', 'user id', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $response['status'] = false;
            $response['message'] = validation_errors_response();
        } else {
            $request = $this->input->post();
            $response['status'] = true;
            $this->comman->update_record('users', ['device_token' => NULL, 'voip_device_token' => NULL,'device_type' => 0], $request['user_id']);
            $this->comman->update_record_by_condition('availability', ['status' => STATUS_INACTIVE],$this->post());

            $response['message'] = 'Log out successfully';
        }
        $this->response($response);
    }
    
    public function settings_links_get() {
        $contents = $this->comman->get_record_by_condition('settings', 'name IN ("privacy_policy", "customer_terms", "advisor_terms")', 'file');
//        $data['privacy_policy']  = stripslashes($contents[0]['value']);
//        $data['customer_terms_condition'] = stripslashes($contents[1]['value']);
//        $data['advisor_terms_condition'] = stripslashes($contents[2]['value']);
        $data['privacy_policy']  = $contents[0]['file'];
        $data['customer_terms_condition'] = $contents[1]['file'];
        $data['advisor_terms_condition'] = $contents[2]['file'];
        $data['status']  = TRUE;
        $data['message'] = "";
        $this->response($data);
    }
    
    public function contact_us_request_post(){

        $this->form_validation->set_rules('user_id', 'User id', 'required');

        $this->form_validation->set_rules('full_name', 'Name', 'required');

        $this->form_validation->set_rules('email', 'Email', 'required');

        $this->form_validation->set_rules('phone', 'Phone', 'required');

        $this->form_validation->set_rules('message', 'Message', 'required');

        if($this->form_validation->run() == FALSE){

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        }else{

            $request = $this->post(); 

            $contact_us = array(

                'user_id'       => $request['user_id'],   

                'full_name'     => $request['full_name'],               

                'email'         => $request['email'],               

                'phone'         => $request['phone'],

                'message'       => $request['message'],

                'created_at'    => current_date()

            );

            $this->comman->insert_record('contact_us',$contact_us);
            
            $user_details=$this->db->select('u.id,u.email,ug.group_id', false)->from('users as u')

              	->join('users_groups ug', 'u.id = ug.user_id')

				->where('u.id',$request['user_id'])

				->get()->row_array();

				if($user_details['group_id'] == 2){$role = "Advisor";}else{$role = "Customer";}

                $template = file_get_contents(base_url('email_templates/contact_us_request.html'));
		        $message  = create_email_template($template);
		        $message  = str_replace('##NAME##',$contact_us['full_name'], $message);
		        $message  = str_replace('##EMAIL##',$contact_us['email'], $message);
		        $message  = str_replace('##PHONE##',$contact_us['phone'], $message);
//		        $message  = str_replace('##SUBJECT##',$contact_us['subject'], $message);
		        $message  = str_replace('##MESSAGE##',$contact_us['message'], $message);
		        $message  = str_replace('##ROLE##',$role, $message);
		        $subject = $this->config->item('site_title', 'ion_auth') . ' - Contact Us Request' ;
		        sendEmail($subject, CONTACT_EMAIL, $message);


            $response['status'] = TRUE;

            $response['message'] = 'Request submitted successfully.';


        }

        $this->response($response);

    }

    public function country_code_get(){
        
        $country_code = $this->db->select('value')->from('settings')->where('name',"country_code")->get()->row_array();

        $response['status'] = TRUE;

        $response['country_code'] = json_decode($country_code['value'],true);

        $this->response($response);
    }
    
    public function _generate_key($uid) {
        do {
            // Generate a random salt
            $salt = base_convert(bin2hex($this->security->get_random_bytes(64)), 16, 36);
            // If an error occurred, then fall back to the previous method
            if ($salt === FALSE) {
                $salt = hash('sha256', time() . mt_rand());
            }
            $new_key = substr($salt, 0, config_item('rest_key_length'));
        } while ($this->_key_exists($new_key));
        $this->_insert_key($new_key, ['level' => 1, 'ignore_limits' => 1, 'user_id' => $uid]);
        return $new_key;
    }
    private function _key_exists($key) {
        return $this->rest->db
                    ->where(config_item('rest_key_column'), $key)
                    ->count_all_results(config_item('rest_keys_table')) > 0;
    }
    private function _insert_key($key, $data) {
        $data[config_item('rest_key_column')] = $key;
        $data['date_created'] = function_exists('now') ? now() : time();
        $check_key = $this->db->get_where('tokens', array('user_id' => $data['user_id']))->row();
        if (empty($check_key)) {
            return $this->rest->db
                    ->set($data)
                    ->insert(config_item('rest_keys_table'));
        } else {
            $this->_update_key($key, $data['user_id']);
        }
    }
    private function _update_key($key, $uid) {
        return $this->rest->db
                ->where('user_id', $uid)
                ->update(config_item('rest_keys_table'), array('date_created' => time(), 'token' => $key));
    }
    private function _delete_key($key) {
        return $this->rest->db
                    ->where(config_item('rest_key_column'), $key)
                    ->delete(config_item('rest_keys_table'));
    }
}
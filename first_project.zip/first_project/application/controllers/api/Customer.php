<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Customer extends REST_Controller {

    function __construct() {

        header('Access-Control-Allow-Origin: *');

        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

        parent::__construct();

        $this->load->model('ion_auth_model');

    }

    public function init_get($app_version = '',$type = '', $user_id = '') {

        if(isset($_SERVER['HTTP_KEY']) && $_SERVER['HTTP_KEY'] != '') {              

            $auth = validate_key($_SERVER['HTTP_KEY']); 

            if($auth) {

                $postFields['app_version'] = $app_version;        

                $postFields['type'] = $type;               

                $errorPost = ValidatePostFields($postFields);

                if(empty($errorPost)) {

                    $update['app_version'] = $app_version;
                    $where = array('id' => $user_id);
                    $this->db->update('users',$update,$where);

                    $MaintenanceMode = (array)$this->db->get_where('appsetting',array('app_name' => 'maintenance_mode'))->row();

                    $AppVersion = (array)$this->db->get_where('appsetting',array('app_name' => $type))->row();

                    $current_version = (Int)str_replace('.', '',$AppVersion['app_version']);

                    $app_version = (Int)str_replace('.', '', $app_version);

                    if($MaintenanceMode['updates'] == 1) {

                        $response['status'] = FALSE;

                        $response['update'] = FALSE;

                        $response['maintenance'] = TRUE;

                        $response['message'] = 'Server under maintenance, please try again after some time';

                    } else if($app_version < $current_version && $AppVersion['updates'] == 0) {

                        $response['status'] = TRUE;

                        $response['update'] = FALSE;

                        $response['message'] = SITENAME.' app new version available';

                    } else if($app_version < $current_version && $AppVersion['updates'] == 1) {

                        $response['status'] = FALSE;

                        $response['update'] = TRUE;

                        $response['message'] = SITENAME.' app new version available, please upgrade your application';

                    } else {

                        $response['status'] = TRUE;
                        
                        $response['category_count'] = $this->comman->get_record_by_condition('settings', ['name' => 'category_count'], 'value')[0]['value'];
                        
                        $response['device_token'] = '';
                        
                        
                        $response['current_time'] = current_date();

                    }
                    if(!empty($user_id)) {
                        $user_data = $this->comman->get_record_byid('users', $user_id, 'device_token,wallet_amount');
                        // _pre($user_data);
                        $response['device_token'] = $user_data['device_token'];
                        $response['wallet_amount'] = $user_data['wallet_amount'];
                    }
                    

                } else {

                    $response['status'] = FALSE;

                    $response['message'] = $errorPost;

                }

            } else {

                $response['status'] = FALSE;

                $response['message'] = 'Authorization failed';

            }

            

        } else {

            $response['status'] = FALSE;

            $response['message'] = 'Authorization key is required';

        }

        $this->response($response);

    }

    public function first_time_post(){

        $this->form_validation->set_rules('user_id', 'user_id', 'required|trim');

        $this->form_validation->set_rules('user_id', 'user_id', 'trim');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $data['status'] = TRUE;

            $booking = $this->db->select('id')->from('booking_request')
                        ->where('user_id',$request['user_id'])
                        ->where('status',1)
                        ->get()->result_array();

            $data['free_minute_name'] = "";
            $data['free_minute'] = "0";

            if(count($booking) == 0){
                $promocode = $this->db->select('*')->from('promocode')
                            ->where('promocode_type','first_time')
                            ->where('status',1)
                            ->where('deleted_at IS NULL')
                            ->get()->row_array();
                if(!empty($promocode)){
                    $data['free_minute'] = $promocode['free_minute'];
                    $data['free_minute_name'] = $promocode['promocode'];
                }else{
                    $data['free_minute'] = "0";
                    $data['free_minute_name'] = "";
                }
            }

            $data['dob_name'] = '';
            $data['dob_discount_type'] = '';
            $data['dob_discount_value'] = '0';

            if(isset($request['dob']) && !empty($request['dob']) && $request['dob'] != ''){
                $dob = date('d-m',strtotime($request['dob']));
                if($dob == date('d-m')){
                    $promocode_dob = $this->db->select('*')->from('promocode')
                            ->where('promocode_type','birthday')
                            ->where('status',1)
                            ->where('deleted_at IS NULL')
                            ->get()->row_array();
                    
                    if(!empty($promocode_dob)){
                        $data['dob_name'] = $promocode_dob['promocode'];
                        $data['dob_discount_type'] = $promocode_dob['discount_type'];
                        $data['dob_discount_value'] = $promocode_dob['discount_value'];
                    }
                    
                }
            }

            $this->response($data);

        }
    }

    public function profile_update_post(){

        $this->form_validation->set_rules('user_id', 'user_id', 'required|trim');

        $this->form_validation->set_rules('full_name', 'full name', 'required|trim');        

        $this->form_validation->set_rules('email', 'email', 'required|trim|callback_isexists[' . $this->post('user_id') . ']');        

        $this->form_validation->set_rules('phone', 'phone', 'required|trim|callback_isexists[' . $this->post('user_id') . ']');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $user_data = array(

                'full_name'    => addslashes($request['full_name']),               

                'email'        => $request['email'],               

                'phone'        => $request['phone'],

                'updated_at'   => current_date()

            );

            if(isset($request['remove_image']) && $request['remove_image'] == 1)
            {

                $user_data['profile_picture'] = '';
                $get_user_detail = $this->comman->get_record_byid('users', $request['user_id'], 'profile_picture');
                @unlink(FCPATH.$get_user_detail['profile_picture']);

            } 

            if (isset($_FILES['profile_picture']) && !empty($_FILES['profile_picture']))
            {

                $image_is_uploaded = image_upload('profile_picture', 'images/users/', TRUE, 'jpg|JPG|png|PNG|jpeg|JPEG', '5000');

                if(isset($image_is_uploaded['status']) && $image_is_uploaded['status']) {

                   $user_data['profile_picture'] = $image_is_uploaded['uploaded_path'];

                } 
                else if( isset($image_is_uploaded['error']) ) {

                   $data['status'] = FALSE;

                   $data['message'] = ucfirst($image_is_uploaded['error']);

                   $this->response($data);

                   die();

                }

            }
            
            $response = $this->ion_auth->update($request['user_id'], $user_data);

            if($response) {
               
                $data['status'] = TRUE;

                $data['profile'] = $this->comman->get_record_byid('users', $request['user_id']);

                // $data['profile']['api_key'] = $this->comman->get_record_by_condition('tokens', ['user_id' => $request['user_id']], 'token')[0]['token'];

                $data['message'] = 'Profile updated successfully';

            } else {

                $data['status'] = FALSE;

                $data['message'] = $this->ion_auth->errors();

            }

        }

        $this->response($data);

    }

    public function change_password_post() {

        $this->form_validation->set_rules('old_password', 'Old Password', 'required');

        $this->form_validation->set_rules('new_password', 'New Password', 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|matches[new_confirm_password]');

        $this->form_validation->set_rules('new_confirm_password', 'Confirm New Password', 'required');

        $this->form_validation->set_rules('user_id', 'user id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $id = $this->post('user_id');

            $user = $this->ion_auth->user($id)->row();

            if (empty($user)) {

                $data['status'] = FALSE;

                $data['message'] = "User not exist.";

            } else {

                $response = $this->ion_auth->change_password($user->email, $this->post('old_password'), $this->post('new_password'), $id);

                if ($response) {

                    $data['status'] = TRUE;

                    $data['message'] = "Your password changed successfully.";

                } else {

                    $data['status'] = FALSE;

                    $data['message'] = strip_tags($this->ion_auth->errors());

                }

            }

        }

        $this->response($data);

    }
    
    public function isexists($str = NULL, $id = NULL) {

        $grp = $this->config->item('roles', 'ion_auth')['customer'];

        $this->db->select('t1.*');

        $this->db->group_start();

        $this->db->where('t1.email', trim($str));

        $this->db->or_where('t1.phone', trim($str));

        $this->db->group_end();

        $this->db->where('t1.deleted_at', NULL);

        $this->db->where('t2.group_id', $grp);

        if(!is_null($id)) {

            $this->db->where_not_in('t1.id', $id);
        }

        $this->db->from('users t1');

        $this->db->join('users_groups t2', 't1.id = t2.user_id');

        $this->db->limit(1);

        $sql_query = $this->db->get();

        if ($sql_query->num_rows() > 0) {

            $this->form_validation->set_message('isexists', (is_numeric($str)) ? "The phone is already exists": "The email is already exists");

            return false;

        } else {

            return true;

        }

    }

    public function category_list_post(){
        
        $request = $this->post();
        $search_string = ' 1=1';
        if(isset($request['search_string']) && !empty($request['search_string']) && !is_null($request['search_string'])) {
            $search_string = ' LOWER(name) LIKE "%'.strtolower($request['search_string']).'%" ';
        }
        $data['category'] = $this->db->query('SELECT id,name,image,description, description as customer_description FROM category WHERE status = '.STATUS_ACTIVE.' AND deleted_at IS NULL AND '.$search_string)->result_array();
        // $data['category'] = $this->comman->get_all_record('category','id,name,image,description',TRUE);

        $data['status'] = TRUE;

        $this->response($data);

    }

    // this api is old one
    public function advisor_list_post(){
        
        $this->form_validation->set_rules('category_id', 'category id', 'trim');
        
        $this->form_validation->set_rules('user_id', 'user id', 'trim');
        
        $this->form_validation->set_rules('type', 'type', 'trim|in_list[all,ratings,chat,audio,video]');
        
        $this->form_validation->set_rules('search_string', 'search_string', 'trim');

        // $this->form_validation->set_rules('advisor_id', 'advisor_id', 'trim');
        
        $this->form_validation->set_rules('is_favourite', 'is_favourite', 'trim|in_list[0,1]');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
            
            $where = '1=1';
            //            if(isset($request['type']) && !empty($request['type']) && !is_null($request['type']) && $request['type'] != 'all') {
            //                $where = 'type = "'.$request['type'].'"';
            //            }
            //            $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->where($where)->group_by('user_id')->get()->result_array();
                        $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->group_by('user_id')->get()->result_array();
                        if(isset($request['category_id']) && !empty($request['category_id']) && !is_null($request['category_id'])) {
                            
                            $users = $this->db->query('SELECT GROUP_CONCAT(id) as user_ids FROM `users` WHERE find_in_set('.$request['category_id'].',`category_id`)')->row_array();

                            $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->where($where)->where('user_id in ('.$users['user_ids'].')')->group_by('user_id')->get()->result_array();
                        } 
                        // echo '<pre>';print_r($availability);exit();

                        if(count($availability)) {
                            $get_advisor_promocode = $this->comman->get_record_by_condition('promocode',['promocode_for' => 'advisor','status' => 1],'special_day_date,discount_value');
                            $user_ids = array_column($availability, 'user_id');
                            $search_string = '1=1 AND ';
                            if(isset($request['search_string']) && !empty($request['search_string']) && !is_null($request['search_string'])) {
                                $search_string = 'LOWER(users.nick_name) LIKE "%'.strtolower($request['search_string']).'%" AND ';
                            }
                            if(isset($request['user_id']) && !empty($request['user_id']) && !is_null($request['user_id'])) {
                                $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("'.$request['user_id'].'", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE '.$search_string.' users.id IN ('.implode(',', $user_ids).') AND active = '.STATUS_ACTIVE.' AND (approve_advisor_detail = 1 OR change_params IS NOT NULL) AND deleted_at IS NULL')->result_array();
                            } else {
                                $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("0", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE '.$search_string.' users.id IN ('.implode(',', $user_ids).') AND active = '.STATUS_ACTIVE.' AND (approve_advisor_detail = 1 OR change_params IS NOT NULL) AND deleted_at IS NULL')->result_array();
                            }
                            $row = [];
                            $record_ids = implode(',', array_column($availability, 'id'));
                            if(!empty($get_advisor_promocode)) {
                                $availability = $this->db->query('SELECT category_id, user_id, type, price, status, CASE WHEN "'.date('Y-m-d',strtotime(current_date())).'" = "'.date('Y-m-d',strtotime($get_advisor_promocode[0]['special_day_date'])).'" THEN TRUNCATE((price-((price*'.$get_advisor_promocode[0]['discount_value'].')/100)), 2) ELSE price END AS discount_price FROM `availability`')->result_array();
                            } else {
                                $availability = $this->db->select('category_id, user_id, type, price, status, price as discount_price')->from('availability')->where('id IN ('.$record_ids.')')->get()->result_array();
                            }
                            $ratings = $this->db->query('SELECT advisor_id, CASE WHEN count(id) > 0 THEN FORMAT((sum(rating)/count(id)), 2) ELSE 0 END AS avg_rating, COUNT(id) as total_rating FROM advisor_rating where advisor_id IN ('.implode(',', $user_ids).') group by advisor_id order by avg_rating desc')->result_array();

                            
                            $type = "";
                            if(isset($request['type']) && !empty($request['type']) && !is_null($request['type']) && $request['type'] != 'all' && $request['type'] != 'ratings') {
                                $type = $request['type'];
                            }
                            
                            foreach ($advisors as $key => $value) {
                                $row[$key] = $value;
                                $row[$key]['availability'] = array_values(array_filter($availability, function($val) use($value){
                                    return $val['user_id'] == $value['id'];
                                }));
                                
                                $row[$key]['categories']     = implode(',',array_unique(array_column($row[$key]['availability'], 'category_id')));
            //                    $row[$key]['categories_name'] = $this->db->select('GROUP_CONCAT(name) as category_name')->from('category')->where('id IN ('.$row[$key]['categories'].')')->order_by( 'FIELD (id,"5","4","8")')->get()->row()->category_name;
                                $row[$key]['categories_name'] = $this->db->select('name')->from('category')->where('id IN ('.$row[$key]['categories'].')')->order_by( 'FIELD (id,'.$row[$key]['categories'].')')->get()->result_array();
                                $row[$key]['categories_name'] = implode(', ',array_column($row[$key]['categories_name'], 'name'));
                                
                                $availible_options = array_values(array_filter($row[$key]['availability'], function($val) use($type){
                                    if(!empty($type)) {
                                        return ($val['status'] == 1 && $val['type'] == $type);
                                    } else {
                                        return $val['status'] == 1;
                                    }
                                }));
                                $row[$key]['availabile_for'] = implode(',',array_unique(array_column($availible_options, 'type')));
                                $row[$key]['availabile_for_count'] = count(array_filter(explode(',',$row[$key]['availabile_for'])));
                                $row[$key]['ratings'] = 0;
                                $doctor_ratings = array_values(array_filter($ratings, function($val) use($value){
                                    return $val['advisor_id'] == $value['id'];
                                }));
                                
                                $row[$key]['avg_rating'] = !empty($doctor_ratings) ? $doctor_ratings[0]['avg_rating'] : "0.00";
                                $row[$key]['total_rating'] = !empty($doctor_ratings) ? $doctor_ratings[0]['total_rating'] : "0";
                                if(!empty($type)) {
                                    $row[$key]['is_availabile'] = (in_array(STATUS_ACTIVE, array_column(array_filter($row[$key]['availability'], function($val) use($type){
                                        if(!empty($type)) {
                                            return $val['type'] == $type;
                                        } 
                                    }), 'status'))) ? STATUS_ACTIVE : ((in_array(STATUS_BUZY, array_column(array_filter($row[$key]['availability'], function($val) use($type){
                                        if(!empty($type)) {
                                            return $val['type'] == $type;
                                        } 
                                    }), 'status'))) ? STATUS_BUZY : STATUS_INACTIVE);
                                } else {
                                    $row[$key]['is_availabile'] = (in_array(STATUS_ACTIVE, array_unique(array_column($row[$key]['availability'], 'status')))) ? 1 : ((in_array(STATUS_BUZY, array_unique(array_column($row[$key]['availability'], 'status')))) ? STATUS_BUZY : STATUS_INACTIVE);
                                }
                                
                                $row[$key]['review_history'] = $this->db->select('advisor_id, advisor_rating.rating, advisor_rating.note, users.full_name, users.profile_picture, advisor_rating.created_at')->from('advisor_rating')->join('users', 'advisor_rating.user_id = users.id')->where('advisor_id', $value['id'])->order_by('advisor_rating.id','desc')->limit(5)->get()->result_array();
                            }
                            if(isset($request['is_favourite']) && $request['is_favourite'] && count($row)) {
                                $row = array_values(array_filter($row, function($val){
                                    return $val['is_favourite'] == "1";
                                }));
                            }
                            $ratings_unsorted = array_column($row, 'avg_rating');
                            asort($ratings_unsorted);
                            $ratings_sorted = array_values(array_reverse($ratings_unsorted, true));
                            
                            // top ratings filter
                            usort($row, function ($a, $b) use ($ratings_sorted) {
                                $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                                $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                                return $pos_a - $pos_b;
                            });
            //                _pre($row);
                
                // active,buzy,inactive ()
                $listing_ordered_array = [STATUS_ACTIVE,STATUS_BUZY,STATUS_INACTIVE];
                usort($row, function ($a, $b) use ($listing_ordered_array) {
                    $pos_a = array_search($a['is_availabile'], $listing_ordered_array);
                    $pos_b = array_search($b['is_availabile'], $listing_ordered_array);
                    return $pos_a - $pos_b;
                });

                // availiblity options hierarchy (chat, audio, video)
                $listing_availiblity_array = [CHAT,AUDIO,VIDEO];
                
                /*active array :start*/
                $availible_array = array_values(array_filter($row, function($val){
                    return $val['is_availabile'] == STATUS_ACTIVE;
                }));
                usort($availible_array, function ($a, $b) use ($listing_availiblity_array) {
                    $pos_a = array_search($a['availabile_for_count'], $listing_availiblity_array);
                    $pos_b = array_search($b['availabile_for_count'], $listing_availiblity_array);
                    return $pos_a - $pos_b;
                });
                
                /*active array :end*/
                
                /* buzzy array :start*/
                $buzzy_array = array_values(array_filter($row, function($val){
                    return $val['is_availabile'] == STATUS_BUZY;
                }));
                usort($buzzy_array, function ($a, $b) use ($listing_availiblity_array) {
                    $pos_a = array_search($a['availabile_for_count'], $listing_availiblity_array);
                    $pos_b = array_search($b['availabile_for_count'], $listing_availiblity_array);
                    return $pos_a - $pos_b;
                });
                /* buzzy array :end*/
                // echo '<pre>';print_r($buzzy_array);exit();
                /* in-active array :start*/
                $not_availible_array = array_values(array_filter($row, function($val){
                    return $val['is_availabile'] == STATUS_INACTIVE;
                }));
                usort($not_availible_array, function ($a, $b) use ($listing_availiblity_array) {
                    $pos_a = array_search($a['availabile_for_count'], $listing_availiblity_array);
                    $pos_b = array_search($b['availabile_for_count'], $listing_availiblity_array);
                    return $pos_a - $pos_b;
                });
                usort($not_availible_array, function ($a, $b) use ($ratings_sorted) {
                    $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                    $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                    return $pos_a - $pos_b;
                });
                /* in-active array :end*/
                 
                $sorted_array = array_merge($availible_array,$buzzy_array,$not_availible_array);
                if(isset($request['type']) && !empty($request['type']) && !is_null($request['type']) && $request['type'] == 'ratings'){
                    // $ratings_unsorted = array_column($sorted_array, 'avg_rating');
                    // asort($ratings_unsorted);
                    // $ratings_sorted = array_values(array_reverse($ratings_unsorted, true));
                    // top ratings filter
                    usort($sorted_array, function ($a, $b) use ($ratings_sorted) {
                        $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                        $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                        return $pos_a - $pos_b;
                    });
                }
                $response['status'] = TRUE;
                $response['advisors'] = $sorted_array;

            } else {
                $response['status'] = TRUE;
                $response['message'] = 'Advisor not available';
            }
            
        }

        $this->response($response);
    }

    // currently using this api
    public function advisor_list1_post(){
        
        $this->form_validation->set_rules('category_id', 'category id', 'trim');
        
        $this->form_validation->set_rules('user_id', 'user id', 'trim');
        
        $this->form_validation->set_rules('type', 'type', 'trim|in_list[all,ratings,chat,audio,video]');
        
        $this->form_validation->set_rules('search_string', 'search_string', 'trim');

        // $this->form_validation->set_rules('advisor_id', 'advisor_id', 'trim');
        
        $this->form_validation->set_rules('is_favourite', 'is_favourite', 'trim|in_list[0,1]');

        $this->form_validation->set_rules('page', 'page', 'trim|required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
            
            $where = '1=1';
            
            //            if(isset($request['type']) && !empty($request['type']) && !is_null($request['type']) && $request['type'] != 'all') {
            //                $where = 'type = "'.$request['type'].'"';
            //            }
            //            $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->where($where)->group_by('user_id')->get()->result_array();
                        $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->group_by('user_id')->get()->result_array();
                        if(isset($request['category_id']) && !empty($request['category_id']) && !is_null($request['category_id'])) {
                            
                            $users = $this->db->query('SELECT GROUP_CONCAT(id) as user_ids FROM `users` WHERE find_in_set('.$request['category_id'].',`category_id`)')->row_array();

                            $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->where($where)->where('user_id in ('.$users['user_ids'].')')->group_by('user_id')->get()->result_array();
                        } 
                        // echo '<pre>';print_r($availability);exit();

                        if(count($availability)) {
                            $get_advisor_promocode = $this->comman->get_record_by_condition('promocode',['promocode_for' => 'advisor','status' => 1],'special_day_date,discount_value');
                            $user_ids = array_column($availability, 'user_id');
                            $search_string = '1=1 AND ';
                            if(isset($request['search_string']) && !empty($request['search_string']) && !is_null($request['search_string'])) {
                                $search_string = 'LOWER(users.nick_name) LIKE "%'.strtolower($request['search_string']).'%" AND ';
                            }
                            if(isset($request['user_id']) && !empty($request['user_id']) && !is_null($request['user_id'])) {
                                $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("'.$request['user_id'].'", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE '.$search_string.' users.id IN ('.implode(',', $user_ids).') AND active = '.STATUS_ACTIVE.' AND (approve_advisor_detail = 1 OR change_params IS NOT NULL) AND  deleted_at IS NULL ')->result_array();
                                //LIMIT '.$start.','.$limit.'
                            } else {
                                $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("0", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE '.$search_string.' users.id IN ('.implode(',', $user_ids).') AND active = '.STATUS_ACTIVE.' AND (approve_advisor_detail = 1 OR change_params IS NOT NULL) AND  deleted_at IS NULL ')->result_array();
                            }
                            // _pre($advisors);
                            $row = [];
                            $record_ids = implode(',', array_column($availability, 'id'));
                            if(!empty($get_advisor_promocode)) {
                                $availability = $this->db->query('SELECT category_id, user_id, type, price, status, CASE WHEN "'.date('Y-m-d',strtotime(current_date())).'" = "'.date('Y-m-d',strtotime($get_advisor_promocode[0]['special_day_date'])).'" THEN TRUNCATE((price-((price*'.$get_advisor_promocode[0]['discount_value'].')/100)), 2) ELSE price END AS discount_price FROM `availability` ')->result_array();
                            } else {
                                $availability = $this->db->select('category_id, user_id, type, price, status, price as discount_price')->from('availability')->where('id IN ('.$record_ids.')')->get()->result_array();
                            }
                            $ratings = $this->db->query('SELECT advisor_id, CASE WHEN count(id) > 0 THEN FORMAT((sum(rating)/count(id)), 2) ELSE 0 END AS avg_rating, COUNT(id) as total_rating FROM advisor_rating where deleted_at IS NULL AND advisor_id IN ('.implode(',', $user_ids).') group by advisor_id order by avg_rating desc')->result_array();

                            
                            $type = "";
                            if(isset($request['type']) && !empty($request['type']) && !is_null($request['type']) && $request['type'] != 'all' && $request['type'] != 'ratings') {
                                $type = $request['type'];
                            }
                          
                            foreach ($advisors as $key => $value) {
                                $row[$key] = $value;
                                $row[$key]['availability'] = array_values(array_filter($availability, function($val) use($value){
                                    return $val['user_id'] == $value['id'];
                                }));
                                
                                $row[$key]['categories']     = implode(',',array_unique(array_column($row[$key]['availability'], 'category_id')));
            //                    $row[$key]['categories_name'] = $this->db->select('GROUP_CONCAT(name) as category_name')->from('category')->where('id IN ('.$row[$key]['categories'].')')->order_by( 'FIELD (id,"5","4","8")')->get()->row()->category_name;
                                $row[$key]['categories_name'] = $this->db->select('name')->from('category')->where('id IN ('.$row[$key]['categories'].')')->order_by( 'FIELD (id,'.$row[$key]['categories'].')')->get()->result_array();
                                $row[$key]['categories_name'] = implode(', ',array_column($row[$key]['categories_name'], 'name'));
                                
                                $availible_options = array_values(array_filter($row[$key]['availability'], function($val) use($type){
                                    if(!empty($type)) {
                                        return ($val['status'] == 1 && $val['type'] == $type);
                                    } else {
                                        return $val['status'] == 1;
                                    }
                                }));
                                $row[$key]['availabile_for'] = implode(',',array_unique(array_column($availible_options, 'type')));
                                $row[$key]['availabile_for_count'] = count(array_filter(explode(',',$row[$key]['availabile_for'])));
                                $row[$key]['ratings'] = 0;
                                $doctor_ratings = array_values(array_filter($ratings, function($val) use($value){
                                    return $val['advisor_id'] == $value['id'];
                                }));
                                $row[$key]['avg_rating'] = !empty($doctor_ratings) ? $doctor_ratings[0]['avg_rating'] : "0.00";
                                $row[$key]['total_rating'] = !empty($doctor_ratings) ? $doctor_ratings[0]['total_rating'] : "0";
                                if(!empty($type)) {
                                    $row[$key]['is_availabile'] = (in_array(STATUS_ACTIVE, array_column(array_filter($row[$key]['availability'], function($val) use($type){
                                        if(!empty($type)) {
                                            return $val['type'] == $type;
                                        } 
                                    }), 'status'))) ? STATUS_ACTIVE : ((in_array(STATUS_BUZY, array_column(array_filter($row[$key]['availability'], function($val) use($type){
                                        if(!empty($type)) {
                                            return $val['type'] == $type;
                                        } 
                                    }), 'status'))) ? STATUS_BUZY : STATUS_INACTIVE);
                                } else {
                                    $row[$key]['is_availabile'] = (in_array(STATUS_ACTIVE, array_unique(array_column($row[$key]['availability'], 'status')))) ? 1 : ((in_array(STATUS_BUZY, array_unique(array_column($row[$key]['availability'], 'status')))) ? STATUS_BUZY : STATUS_INACTIVE);
                                }
                                
                                $row[$key]['review_history'] = $this->db->select('advisor_id, advisor_rating.rating, advisor_rating.note, users.full_name, users.profile_picture, advisor_rating.created_at')->from('advisor_rating')->join('users', 'advisor_rating.user_id = users.id')->where('advisor_id', $value['id'])->where('advisor_rating.deleted_at IS NULL')->order_by('advisor_rating.id','desc')->limit(5)->get()->result_array();
                            }
                            if(isset($request['is_favourite']) && $request['is_favourite'] && count($row)) {
                                $row = array_values(array_filter($row, function($val){
                                    return $val['is_favourite'] == "1";
                                }));
                            }
                            $ratings_unsorted = array_column($row, 'avg_rating');
                            asort($ratings_unsorted);
                            $ratings_sorted = array_values(array_reverse($ratings_unsorted, true));
                            // top ratings filter
                            usort($row, function ($a, $b) use ($ratings_sorted) {
                                $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                                $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                                return $pos_a - $pos_b;
                            });
            
                // active,buzy,inactive ()
                $listing_ordered_array = [STATUS_ACTIVE,STATUS_BUZY,STATUS_INACTIVE];
                usort($row, function ($a, $b) use ($listing_ordered_array) {
                    $pos_a = array_search($a['is_availabile'], $listing_ordered_array);
                    $pos_b = array_search($b['is_availabile'], $listing_ordered_array);
                    return $pos_a - $pos_b;
                });
                // availiblity options hierarchy (chat, audio, video)
                $listing_availiblity_array = [CHAT,AUDIO,VIDEO];
                
                /*active array :start*/
                $availible_array = array_values(array_filter($row, function($val){
                    return $val['is_availabile'] == STATUS_ACTIVE;
                }));
                usort($availible_array, function ($a, $b) use ($ratings_sorted) {
                    $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                    $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                    return $pos_a - $pos_b;
                });
                usort($availible_array, function ($a, $b) use ($listing_availiblity_array) {
                    $pos_a = array_search($a['availabile_for_count'], $listing_availiblity_array);
                    $pos_b = array_search($b['availabile_for_count'], $listing_availiblity_array);
                    return $pos_a - $pos_b;
                });
                /*active array :end*/
                
                /* buzzy array :start*/
                $buzzy_array = array_values(array_filter($row, function($val){
                    return $val['is_availabile'] == STATUS_BUZY;
                }));
                usort($buzzy_array, function ($a, $b) use ($listing_availiblity_array) {
                    $pos_a = array_search($a['availabile_for_count'], $listing_availiblity_array);
                    $pos_b = array_search($b['availabile_for_count'], $listing_availiblity_array);
                    return $pos_a - $pos_b;
                });
                /* buzzy array :end*/
                // echo '<pre>';print_r($buzzy_array);exit();
                /* in-active array :start*/
                $not_availible_array = array_values(array_filter($row, function($val){
                    return $val['is_availabile'] == STATUS_INACTIVE;
                }));
                usort($not_availible_array, function ($a, $b) use ($listing_availiblity_array) {
                    $pos_a = array_search($a['availabile_for_count'], $listing_availiblity_array);
                    $pos_b = array_search($b['availabile_for_count'], $listing_availiblity_array);
                    return $pos_a - $pos_b;
                });
                usort($not_availible_array, function ($a, $b) use ($ratings_sorted) {
                    $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                    $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                    return $pos_a - $pos_b;
                });
                /* in-active array :end*/

                $sorted_array = array_merge($availible_array,$buzzy_array,$not_availible_array);
                // _pre( $sorted_array);
                if(isset($request['type']) && !empty($request['type']) && !is_null($request['type']) && $request['type'] == 'ratings'){
                    // $ratings_unsorted = array_column($sorted_array, 'avg_rating');
                    // asort($ratings_unsorted);
                    // $ratings_sorted = array_values(array_reverse($ratings_unsorted, true));
                    // top ratings filter
                    usort($sorted_array, function ($a, $b) use ($ratings_sorted) {
                        $pos_a = array_search($a['avg_rating'], $ratings_sorted);
                        $pos_b = array_search($b['avg_rating'], $ratings_sorted);
                        return $pos_a - $pos_b;
                    });
                }
                //_pre($type);

                if($request['page'] == 0)
                {
                    $request['page'] = 1;
                }
                $limit = $this->config->item('page_item');
                $offset = $limit * ($request['page'] - 1);
                $sorted_array = array_slice($sorted_array, $offset, $limit);
                
                $response['status'] = TRUE;
                $response['advisors'] = $sorted_array;

            } else {
                $response['status'] = TRUE;
                $response['message'] = 'Advisor not available';
            }
            
        }

        $this->response($response);
    }
    
    public function rating_review_post() {
        
        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
        
            $review_history = $this->db->select('advisor_rating.rating, advisor_rating.note, users.full_name, users.profile_picture, advisor_rating.created_at')->from('advisor_rating')->join('users', 'advisor_rating.user_id = users.id')->where('advisor_id', $request['advisor_id'])->order_by('advisor_rating.id','desc')->get()->result_array();
            
            $response['status'] = true;
            $response['message'] = 'Review not availible';
            if(count($review_history)) {
                $response['status'] = true;
                $response['message'] = '';
            }
            $response['review_history'] = $review_history;
        }
        $this->response($response);
    }
    
    public function favourite_advisor_post() {
        
        $this->form_validation->set_rules('user_id', 'User id', 'trim|required');

        $this->form_validation->set_rules('advisor_id', 'Advisor id', 'trim|required');

        $this->form_validation->set_rules('status', 'status', 'trim|required|in_list[0,1]');

        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 

            $user_detail = $this->comman->get_record_byid('users',$request['advisor_id'], 'favourite_advisor');
            if(!$request['status']) {
                $favourite_advisor = explode(',', $user_detail['favourite_advisor']);
                unset($favourite_advisor[array_search($request['user_id'], $favourite_advisor)]);
                $update_arr = ['favourite_advisor' => null];
                if(count($favourite_advisor)) {
                    $favourite_advisor = implode(',', $favourite_advisor);
                    $update_arr = ['favourite_advisor' => $favourite_advisor];
                }
            } else {
                $update_arr = ['favourite_advisor' => ($user_detail['favourite_advisor'].','.$request['user_id']) ];
                if(empty($user_detail['favourite_advisor']) || is_null($user_detail['favourite_advisor'])) {
                    $update_arr = ['favourite_advisor' => $request['user_id']];
                }
            }
            $this->comman->update_record('users', $update_arr, $request['advisor_id']);

            $response['status'] = TRUE;

            $response['message'] = '';
            
        }

        $this->response($response);
    }
    
    public function advisor_rating_post(){

        $this->form_validation->set_rules('user_id', 'User id', 'required');

        $this->form_validation->set_rules('advisor_id', 'Advisor id', 'required');

        $this->form_validation->set_rules('rating', 'Rating', 'required');
        
        $this->form_validation->set_rules('booking_id', 'booking_id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 

            $rating_data = array(

                'booking_id'    => $request['booking_id'],   
                
                'user_id'       => $request['user_id'],   

                'advisor_id'    => $request['advisor_id'],               

                'rating'        => $request['rating'],               

                'note'          => $request['note'],

                'created_at'    => current_date()

            );

            $rating = $this->comman->insert_record('advisor_rating',$rating_data);

            if($rating){

                $response['status'] = TRUE;

                $response['message'] = 'Rating added successfully.';

            }else{

                $response['status'] = FALSE;

                $response['message'] = 'something went wrong';
            }
        }

        $this->response($response);

    }
    
    public function minutes_get() {
        $minutes = $this->comman->get_record_by_condition('settings',['name' => 'minutes'],'value');
        $data['minutes'] = explode('|',$minutes[0]['value']);
        $data['status'] = TRUE;
        $this->response($data);
    }
    
    
    public function session_list1_post() {
        
        $this->form_validation->set_rules('user_id', 'user id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post();
            
            $session_list = $this->db->query('SELECT booking_request.id as booking_id, advisor.id as advisor_id, advisor.profile_picture, advisor.nick_name,booking_request.type,booking_request.created_at as booking_date, booking_request.session_minute as total_minutes, CASE WHEN advisor_rating.id IS NOT NULL THEN true ELSE false END AS rating_availible, CASE WHEN booking_request.end_time IS NULL THEN false ELSE true END AS is_session_end FROM `chat_history` join booking_request on chat_history.booking_id = booking_request.id join users AS advisor on booking_request.advisor_id = advisor.id left join advisor_rating ON booking_request.id = advisor_rating.booking_id WHERE booking_request.user_id = '.$request['user_id'].' AND booking_request.status = 1 AND booking_request.end_time IS NOT NULL GROUP BY booking_request.id ORDER BY booking_id DESC')->result_array();
            $response['status'] = false;
            $response['message'] = 'Sessions not availible';
            if(count($session_list)) {
                $response['status'] = true;
                $response['message'] = '';
                $block_sessions = $this->comman->get_record_by_condition('delete_session', ['user_id' => $request['user_id']], 'booking_id');
                $block_booking_id = array_unique(array_column($block_sessions, 'booking_id'));
                $session_list = array_values(array_filter($session_list, function($val) use ($block_booking_id){
                    return (!in_array($val['booking_id'], $block_booking_id));
                }));
            }
            $response['session_list'] = $session_list;
        
        }
        $this->response($response);
    }

    public function session_list_post() {
        
        $this->form_validation->set_rules('user_id', 'user id', 'required');

        $this->form_validation->set_rules('page', 'page', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            if($request['page'] == 0)
            {
                $request['page'] = 1;
            }

            if($request['page'] == 1)
            {
                $start = 0;
            }
            else
            {
                $start = ($request['page'] - 1) * $this->config->item('page_item');;
            }
            $limit = $this->config->item('page_item');
            
            $session_list = $this->db->query('SELECT booking_request.id as booking_id, advisor.id as advisor_id, advisor.profile_picture, advisor.nick_name,booking_request.type,booking_request.created_at as booking_date,category.name as category_name,booking_request.offer_id,booking_request.promocode_minute, booking_request.session_minute as total_minutes,(SELECT COUNT(chat_history.id) from chat_history where chat_history.booking_id = booking_request.id AND chat_history.message_type = "free" AND chat_history.receiver_id = '.$request['user_id'].' AND chat_history.read_status = 0) as post_unread_message_count ,booking_request.total as total_price, 
                CASE WHEN advisor_rating.id IS NOT NULL THEN true ELSE false END AS rating_availible, 
                CASE WHEN booking_request.end_time IS NULL THEN false ELSE true END AS is_session_end 
                FROM `booking_request` 
                left join chat_history on booking_request.id = chat_history.booking_id 
                join users AS advisor on booking_request.advisor_id = advisor.id 
                join category on booking_request.category_id = category.id 
                left join advisor_rating ON booking_request.id = advisor_rating.booking_id 
                WHERE booking_request.user_id = '.$request['user_id'].' AND booking_request.status = 1 AND booking_request.is_session_running = 1 AND booking_request.end_time IS NOT NULL GROUP BY booking_request.id ORDER BY booking_id DESC LIMIT '.$start.','.$limit.'')->result_array();
            // _pre($this->db->last_query());
            $response['status'] = false;
            $response['message'] = 'Sessions not availible';
            if(count($session_list)) {
                $response['status'] = true;
                $response['message'] = '';
                $block_sessions = $this->comman->get_record_by_condition('delete_session', ['user_id' => $request['user_id']], 'booking_id');
                $block_booking_id = array_unique(array_column($block_sessions, 'booking_id'));
                $session_list = array_values(array_filter($session_list, function($val) use ($block_booking_id){
                    return (!in_array($val['booking_id'], $block_booking_id));
                }));
            }
            if(!empty($session_list)){
                foreach ($session_list as $key => $value) {
                   $row[$key] = $value;
                   $row[$key]['total_minutes'] = ($value['promocode_minute'] != 0) ? $value['promocode_minute'] : $value['total_minutes'];
                }
                $session_list = $row;
            }
            $response['session_list'] = $session_list;
        
        }
        $this->response($response);
    }
    
    public function chat_history_post() {
        
        $this->form_validation->set_rules('booking_id', 'booking id', 'required');
        $this->form_validation->set_rules('chat_type', 'chat type', 'required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
        
            $chat_history = $this->db->query('SELECT chat_history.id as chat_id, booking_request.created_at as booking_date, chat_history.message, chat_history.sender_type, chat_history.receiver_type, chat_history.created_at as message_date, chat_history.read_status, booking_request.id as booking_id, chat_history.sender_id, chat_history.receiver_id, sender.full_name, CASE WHEN sender.nick_name IS NOT NULL THEN sender.nick_name ELSE "" END AS nick_name, sender.profile_picture FROM `chat_history` join booking_request on chat_history.booking_id = booking_request.id join users as sender on chat_history.sender_id = sender.id WHERE booking_request.id = '.$request['booking_id'].' AND chat_history.message_type="'.$request['chat_type'].'" ORDER BY chat_history.id DESC')->result_array();
            $response['remaining_msg'] = 0;
            if($request['chat_type'] == 'free') {
                $response['remaining_msg'] = $this->comman->get_record_byid('booking_request',$request['booking_id'],'end_session_messages')['end_session_messages'];
            }
            $response['status'] = true;
            $response['message'] = 'Chat not availible';
            if(count($chat_history)) {
                $response['status'] = true;
                $response['message'] = '';
            }
            $response['chat_history'] = $chat_history;
        }
        $this->response($response);
    }
    
    public function delete_session_post() {
        $this->form_validation->set_rules('booking_id', 'booking id', 'required');
        $this->form_validation->set_rules('user_id', 'user_id', 'required');
        
        if ($this->form_validation->run() == FALSE) {

            $response['status'] = FALSE;

            $response['message'] = validation_errors_response();

        } else {

            $request = $this->post(); 
        
            $session = array(

                'booking_id'    => $request['booking_id'],   
                
                'user_id'       => $request['user_id'],   

                'created_at'    => current_date()

            );

            $this->comman->insert_record('delete_session',$session);
            
            $response['status'] = TRUE;

            $response['message'] = 'Session Deleted Successfully';
        }
        $this->response($response);
    }
    
    public function add_payment_card_post(){

        $this->form_validation->set_rules('user_id', 'user id', 'trim|required');

        $this->form_validation->set_rules('card_holder_name', 'card holder name', 'trim|required');

        $this->form_validation->set_rules('card_number', 'card number', 'trim|required');

        $this->form_validation->set_rules('expiry_date', 'expiry date', 'trim|required');

        $this->form_validation->set_rules('cvv', 'cvv', 'trim|required');

        $this->form_validation->set_rules('card_type', 'card type', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();
            $data['arabic_message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $card_number    = str_replace(' ', '', $request['card_number']);

            $validate_date  = $this->validate_expirydate($request['expiry_date']);

            if($validate_date) {

                $card_types     = array('1' => 'visa', '2' => 'mastercard', '3' => 'amex', '4' => 'jcb', '5' => 'dinnerclub', '6' => 'discover');

                $my_card_type   = $card_types[$request['card_type']];

                $card_type      = $this->validate_customer_card($card_number);

                if($card_type != '' && $card_type == $my_card_type) {

                    $check_card_is_exist = $this->comman->get_record_by_condition('payment_card', ['user_id' => $request['user_id'],'card_number' => encrypt($card_number), 'deleted_at' => null]);

                    if(!empty($check_card_is_exist) && count($check_card_is_exist) > 0) {

                        $data['status'] = FALSE;

                        $data['message'] = 'Card already exists';

                    } else {

                        $payment_card_data = array(

                            'user_id'          => $request['user_id'],

                            'card_holder_name' => ucfirst(addslashes($request['card_holder_name'])),

                            'card_number'      => encrypt($card_number),

                            'display_number'   => 'XXXX XXXX XXXX '.substr($card_number, -4),

                            'expiry_date'      => encrypt($request['expiry_date']),

                            'cvv'              => encrypt(($request['cvv'])),

                            'card_type'        => intval($request['card_type']),

                            'created_at'       => current_date()

                        );

                        $this->comman->insert_record('payment_card',$payment_card_data);

                        $data['status'] = TRUE;

                        $data['message'] = 'Card added successfully';

                    }

                } else {

                    $data['status'] = FALSE;

                    $data['message'] = 'Invalid card number';

                }

            } else {

                $data['status'] = FALSE;

                $data['message'] = 'Card is already expired';
            }

        }

        $this->response($data);

    }
    
    public function my_payment_cards_post(){

        $this->form_validation->set_rules('user_id', 'user id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else{

            $request = $this->post();

            $cards = $this->comman->get_record_by_condition('payment_card', ['user_id' => $request['user_id'], 'deleted_at' => null], 'id, user_id, card_holder_name, card_number, display_number, expiry_date, cvv, card_type');

            if(count($cards) > 0) {

                foreach($cards as $key => $value) {

                    $row[$key] = $value;

                    $row[$key]['display_expiry_date'] = decrypt($value['expiry_date']);
                    $row[$key]['original_cvv'] = decrypt($value['cvv']);

                }

                $data['cards'] = $row;

                $data['status'] = TRUE;

                $data['message'] = '';

            } else {

                $data['cards'] = [];

                $data['status'] = TRUE;

                $data['message'] = 'Card not found';

            }

        }

        $this->response($data);

    }
    
    public function card_delete_post() {

        $this->form_validation->set_rules('card_id', 'card id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $this->comman->update_record('payment_card', ['deleted_at' => current_date()], $request['card_id']);

            $data['status'] = TRUE;

            $data['card_id'] = $request['card_id'];

            $data['message'] = "Card deleted successfully.";

        }

        $this->response($data);

    }

    public function add_amount_post(){
        
        $this->form_validation->set_rules('card_id', 'card id', 'required');

        $this->form_validation->set_rules('amount', 'amount', 'required');

        $this->form_validation->set_rules('booking_id', 'booking id', 'trim');
        
        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();
            $current_date = current_date();
            $booking_id = 0;
            if(isset($request['booking_id']) && $request['booking_id'] != ''){
                $booking_id = $request['booking_id'];
                $wallet['booking_id'] = $request['booking_id'];
            }
            $card_details = $this->db->select('*')->from('payment_card')->where('id', $request['card_id'])->get()->row_array();
            $user_detail  = $this->db->select('wallet_amount')->from('users')->where('id', $card_details['user_id'])->get()->row_array();

            /* Add initial transaction : start*/
            $transaction['user_id'] = $card_details['user_id'];
            $transaction['amount']  = $request['amount'];
            $transaction['card_id'] = $request['card_id'];
            $transaction['status']  = 'pending';
            $transaction['transaction_type'] = 'wallet';
            $transaction['reference_id'] = '';
            $transaction['description'] = 'Card payment to add wallet.';
            $transaction['created_at'] = $current_date;

            $last_transaction_id = $this->comman->insert_record('transactions',$transaction);
            /* Add initial transaction : end*/

            $strp_transaction['cost'] = $request['amount'] * 100;
            $strp_transaction['purchase_id'] = $last_transaction_id;
            $strp_transaction['credit_card_no'] = decrypt($card_details['card_number']);
            $strp_transaction['security_code'] = decrypt($card_details['cvv']);
            $strp_transaction['expiry_date'] = decrypt($card_details['expiry_date']);
            $strp_transaction['Fullname'] = $card_details['card_holder_name'];
            $strp_transaction['Description'] = 'Transaction ID #'.$last_transaction_id;
            $res = pay_stripe($strp_transaction);
            // _pre($res);
            // print_r($strp_transaction);exit;
//            $res['ReferenceId'] = rand(11111111,99999999);
//            $res['Status'] = 'success';
            if(!empty($res) && $res['Status'] == 'success') {
                $data['status'] = TRUE;
                $data['message'] = "Payment Successful";
                $update_transaction['status'] = 'success';

                $user_update['wallet_amount'] = (float)$user_detail['wallet_amount'] + (float)$request['amount'];
                $this->comman->update_record('users', $user_update, $card_details['user_id']);

                $wallet['user_id']     = $card_details['user_id'];
                $wallet['amount_type'] = 'plus';
                $wallet['amount']      = $request['amount'];
                $wallet['description'] = "Amount Added";
                $wallet['created_at']  = $current_date;

                $this->comman->insert_record('wallet',$wallet);

            } else {
                $data['status'] = FALSE;
                $data['message'] = "Payment Failed";
                $update_transaction['status'] = 'failed';
            }
            $update_transaction['reference_id'] = $booking_id;
            $update_transaction['updated_at'] = current_date();
            $this->comman->update_record('transactions', $update_transaction, $last_transaction_id );

            $data['wallet_history'] = $this->db->select('*')->from('wallet')->where('user_id', $card_details['user_id'])->order_by('id','desc')->get()->result_array();
            $data['wallet_amount'] = $this->comman->get_record_byid('users', $card_details['user_id'], 'wallet_amount')['wallet_amount'];

        }

        $this->response($data);
    }


    public function wallet_history_post() {
        $this->form_validation->set_rules('user_id', 'user id', 'required');

        $this->form_validation->set_rules('page', 'page', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            if($request['page'] == 0)
            {
                $request['page'] = 1;
            }

            if($request['page'] == 1)
            {
                $start = 0;
            }
            else
            {
                $start = ($request['page'] - 1) * $this->config->item('page_item');;
            }
            $limit = $this->config->item('page_item');
            
            $data['status'] = TRUE;
            $data['wallet_amount'] = $this->comman->get_record_byid('users', $request['user_id'], 'wallet_amount')['wallet_amount'];
            $data['wallet_history'] = $this->db->select('*')->from('wallet')
                                            ->where('user_id', $request['user_id'])
                                            ->order_by('id','desc')
                                            ->limit($limit, $start)
                                            ->get()->result_array();
        
        }
        $this->response($data);
    }

    public function notify_me_post(){

        $this->form_validation->set_rules('user_id', 'user id', 'required');

        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $user_detail = $this->comman->get_record_byid('users',$request['advisor_id'], 'notify_me_customers');

            if(empty($user_detail['notify_me_customers']) || is_null($user_detail['notify_me_customers'])){
                $update_arr = ['notify_me_customers' => $request['user_id']];
            }else{

                $notify_me_customers = explode(',', $user_detail['notify_me_customers']);
                if (!in_array($request['user_id'], $notify_me_customers)){
                    $update_arr = ['notify_me_customers' => ($user_detail['notify_me_customers'].','.$request['user_id']) ];
                }else{$update_arr = [];}
                // _pre($update_arr);
            }
            if(!empty($update_arr)){

                $this->comman->update_record('users', $update_arr, $request['advisor_id']);
            }

            $data['status'] = TRUE;

            $data['message'] = '';
        }

        $this->response($data); 
    }

    public function advisor_details_post(){
        $this->form_validation->set_rules('advisor_id', 'advisor id', 'required');

        $this->form_validation->set_rules('user_id', 'user id', 'trim');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            $get_advisor_promocode = $this->comman->get_record_by_condition('promocode',['promocode_for' => 'advisor','status' => 1],'special_day_date,discount_value');

            $availability = $this->db->select('group_concat(id) as id,user_id, group_concat(type) as type, status')->from('availability')->group_by('user_id')->get()->result_array();
            $user_ids = array_column($availability, 'user_id');


            if(isset($request['user_id']) && !empty($request['user_id']) && !is_null($request['user_id'])) {

                $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("'.$request['user_id'].'", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE users.id IN ('.implode(',', $user_ids).') AND users.id = '.$request['advisor_id'].' AND active = '.STATUS_ACTIVE.' AND deleted_at IS NULL ')->row_array();

            } else {

                $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("0", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE users.id IN ('.implode(',', $user_ids).') AND active = '.STATUS_ACTIVE.' AND users.id = '.$request['advisor_id'].' AND approve_advisor_detail = 1 AND deleted_at IS NULL')->row_array();

                // $advisors = $this->db->query('SELECT users.id, users.full_name, users.nick_name, CASE WHEN users.profile_picture IS NOT NULL THEN users.profile_picture ELSE "" END AS profile_picture,users.advisor_description, CASE WHEN find_in_set("0", users.favourite_advisor) <> 0 THEN 1 ELSE 0 END AS is_favourite from users WHERE active = '.STATUS_ACTIVE.' AND approve_advisor_detail = 1 AND users.id = '.$request['advisor_id'].'  AND deleted_at IS NULL ')->result_array();
            }


            // _pre($advisors);
            
            if(!empty($get_advisor_promocode)) {
                $availability = $this->db->query('SELECT category_id, user_id, type, price, status, CASE WHEN "'.date('Y-m-d',strtotime(current_date())).'" = "'.date('Y-m-d',strtotime($get_advisor_promocode[0]['special_day_date'])).'" THEN TRUNCATE((price-((price*'.$get_advisor_promocode[0]['discount_value'].')/100)), 2) ELSE price END AS discount_price FROM `availability` WHERE user_id ='.$request['advisor_id'])->result_array();
            } else {
                $availability = $this->db->select('category_id, user_id, type, price, status, price as discount_price')->from('availability')->where('user_id',$request['advisor_id'])->get()->result_array();
            }

            $ratings = $this->db->query('SELECT advisor_id, CASE WHEN count(id) > 0 THEN FORMAT((sum(rating)/count(id)), 2) ELSE 0 END AS avg_rating, COUNT(id) as total_rating FROM advisor_rating where advisor_id = '.$request['advisor_id'].' group by advisor_id order by avg_rating desc')->result_array();

            $advisor_details['id'] = $advisors['id'];
            $advisor_details['full_name'] = $advisors['full_name'];
            $advisor_details['nick_name'] = $advisors['nick_name'];
            $advisor_details['profile_picture'] = $advisors['profile_picture'];
            $advisor_details['advisor_description'] = $advisors['advisor_description'];
            $advisor_details['is_favourite'] = $advisors['is_favourite'];
            $advisor_details['availability'] = $availability;
            $advisor_details['categories'] = implode(',',array_unique(array_column($availability, 'category_id')));
            $advisor_details['categories_name'] = $this->db->select('name')->from('category')->where('id IN ('.$advisor_details['categories'].')')->order_by( 'FIELD (id,'.$advisor_details['categories'].')')->get()->result_array();
            $advisor_details['categories_name'] = implode(', ',array_column( $advisor_details['categories_name'], 'name'));
            $type = "";
            $availible_options = array_values(array_filter($availability, function($val) use($type){
                if(!empty($type)) {
                    return ($val['status'] == 1 && $val['type'] == $type);
                } else {
                    return $val['status'] == 1;
                }
            }));
            $advisor_details['availabile_for'] = implode(',',array_unique(array_column($availible_options, 'type')));
            $advisor_details['availabile_for_count'] = count(array_filter(explode(',',$advisor_details['availabile_for'])));
            $advisor_details['ratings'] = 0;
            $advisor_details['avg_rating'] = !empty($ratings) ? $ratings[0]['avg_rating'] : "0.00";
            $advisor_details['total_rating'] = !empty($ratings) ? $ratings[0]['total_rating'] : "0";
            $advisor_details['is_availabile'] = (in_array(STATUS_ACTIVE, array_unique(array_column($availability, 'status')))) ? 1 : ((in_array(STATUS_BUZY, array_unique(array_column($availability, 'status')))) ? STATUS_BUZY : STATUS_INACTIVE);
            $advisor_details['review_history'] = $this->db->select('advisor_id, advisor_rating.rating, advisor_rating.note, users.full_name, users.profile_picture, advisor_rating.created_at')->from('advisor_rating')->join('users', 'advisor_rating.user_id = users.id')->where('advisor_id', $request['advisor_id'])->order_by('advisor_rating.id','desc')->limit(5)->get()->result_array();
            
            $data['status'] = TRUE;
            $data['advisor_details'] = $advisor_details;
            //_pre($advisor_details);
        }

        $this->response($data);
    }

    // this api is old one
    // public function wallet_history1_post() {
    //     $this->form_validation->set_rules('user_id', 'user id', 'required');
    //     $this->form_validation->set_rules('page', 'page', 'trim');

    //     if ($this->form_validation->run() == FALSE) {

    //         $data['status'] = FALSE;

    //         $data['message'] = validation_errors_response();

    //     } else {

    //         $request = $this->post();

    //         if($request['page'] == 0)
    //         {
    //             $request['page'] = 1;
    //         }

    //         if($request['page'] == 1)
    //         {
    //             $start = 0;
    //         }
    //         else
    //         {
    //             $start = ($request['page'] - 1) * $this->config->item('page_item');;
    //         }
    //         $limit = $this->config->item('page_item');;
            
    //         $data['status'] = TRUE;
    //         $data['wallet_amount'] = $this->comman->get_record_byid('users', $request['user_id'], 'wallet_amount')['wallet_amount'];
    //         $data['wallet_history'] = $this->db->select('*')->from('wallet')
    //                                         ->where('user_id', $request['user_id'])
    //                                         ->order_by('id','desc')
    //                                         ->limit($limit, $start)
    //                                         ->get()->result_array();
        
    //     }
    //     $this->response($data);
    // }
    
    function validate_customer_card($card_number = NULL){

        if (isset($card_number) && $card_number != ''){

            global $type;

            $cardtype = array(

                "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",

                "mastercard" => "/^5[1-5][0-9]{14}$/",

                "amex"       => "/^3[47][0-9]{13}$/",

                "jcb"        => "/^(?:2131|1800|35\d{3})\d{11}$/",

                "dinnerclub" => "/^3(?:0[0-5]|[68][0-9])[0-9]{11}$/",

                "discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",

            );

            if (preg_match($cardtype['visa'],$card_number)) {

                return 'visa';

            } else if (preg_match($cardtype['mastercard'],$card_number)) {

                return 'mastercard';

            } else if (preg_match($cardtype['dinnerclub'],$card_number)) {

                return 'dinnerclub';

            } else if (preg_match($cardtype['jcb'],$card_number)) {

                return 'jcb';

            } else if (preg_match($cardtype['amex'],$card_number)) {

                return 'amex';

            } else if (preg_match($cardtype['discover'],$card_number)) {

                return 'discover';

            } else {

                return '';

            }

        }

    }
    
    public function validate_expirydate($expiry_date = NULL){

        $return = FALSE;

        $expiry_date_array = explode('/',$expiry_date);

        if (count($expiry_date_array) == 2) {

            if (checkdate($expiry_date_array[0], '01' , $expiry_date_array[1])) {

                $expiry_date_obj = DateTime::createFromFormat('d/m/Y H:i:s', "01/" . $expiry_date_array[0] . "/" .  $expiry_date_array[1]." 00:00:00");

                $expiry_date_obj = new DateTime($expiry_date_obj->format("Y-m-t"));

                $my_date = date('d/m/Y');

                $today = DateTime::createFromFormat('d/m/Y H:i:s', $my_date ." 00:00:00");

                if($expiry_date_obj >= $today){

                    $return = TRUE;

                }

            }

        }

        return $return;

    }

    public function booking_details_post(){

        $this->form_validation->set_rules('user_id', 'user id', 'required');

        $this->form_validation->set_rules('type', 'type', 'required');

        if ($this->form_validation->run() == FALSE) {

            $data['status'] = FALSE;

            $data['message'] = validation_errors_response();

        } else {

            $request = $this->post();

            ($request['type'] == '3') ? $where = 'booking_request.user_id = '.$request['user_id'] : $where = 'booking_request.advisor_id = '.$request['user_id'];

            $booking_details = $this->db->select('booking_request.id as booking_id,booking_request.advisor_id,booking_request.user_id,booking_request.type,booking_request.status as booking_status,booking_request.end_time,booking_request.start_time,booking_request.minute,customer.profile_picture as customer_profile_picture,customer.full_name as customer_name,advisor.profile_picture as advisor_profile_picture,advisor.nick_name as advisor_name,')->from('booking_request')
            ->join('users as advisor','booking_request.advisor_id = advisor.id','left')
            ->join('users as customer','booking_request.user_id = customer.id','left')
            ->where($where)
            ->order_by('booking_request.id','desc')->limit(1)->get()->row_array();

            if($booking_details['booking_status'] == 1 && $booking_details['end_time'] != '' && $booking_details['end_time'] != NULL && $booking_details['is_session_running'] == 1){
                $booking_details['booking_status'] = "1";
            }

            $data['status'] = TRUE;
            $data['booking_details'] =  $booking_details;

        }

        $this->response($data);

    }

}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller{

	public function __construct() {
        parent::__construct();
    }
    
    public function advisor_special_day() {
        $get_advisor_promocode = $this->comman->get_record_by_condition('promocode',['promocode_for' => 'advisor','status' => 1],'special_day_date,discount_value');
       
        if(!empty($get_advisor_promocode)) {
            $notification_title = SITENAME.' - Offer Day';
            $notification_description = 'Your price reduce upto '.$get_advisor_promocode[0]['discount_value'].'%';
            if(date('Y-m-d',strtotime(current_date())) == date('Y-m-d',strtotime($get_advisor_promocode[0]['special_day_date']))) {
                $user_details = $this->db->query('SELECT users.id,users.device_type,users.device_token from users JOIN users_groups on users.id = users_groups.user_id where users_groups.group_id = '.$this->config->item('roles', 'ion_auth')['service_provider'].' AND device_token IS NOT NULL AND device_token != ""')->result_array();
                //id IN (SELECT GROUP_CONCAT(user_id) as user_ids FROM `availability`) AND
                //  _pre($user_details); 
                $ios_users = array_filter($user_details, function ($value) {
                    return $value['device_type'] == 1;
                });
                if(count($ios_users) > 0) {
                    $ios_tokens = array_values(array_column($ios_users, 'device_token'));
                    send_bulk_push($ios_tokens, 'ios', $notification_title, $notification_description, 'general');
                }
                $android_users = array_filter($user_details, function ($value) {
                    return $value['device_type'] == 2;
                });
                if(count($android_users) > 0) {
                    $android_tokens = array_values(array_column($android_users, 'device_token'));
                    send_bulk_push($android_tokens, 'android', $notification_title, $notification_description, 'general');
                }
                $cron_data['status'] = 1;
            }
        }

        $cron_data['type'] = "advisor_special_day";
        $cron_data['created_at'] = current_date();
        $this->comman->insert_record("cron_log", $cron_data);
    }
    
    public function customer_birthday() {
        $get_advisor_promocode = $this->comman->get_record_by_condition('promocode',['promocode_for' => 'customer', 'promocode_type' => 'birthday','status' => 1],'special_day_date,discount_value,discount_type');
        if(!empty($get_advisor_promocode)) {
            $user_details = $this->db->query('SELECT id,device_type,device_token from users where DATE_FORMAT(dob,"%m-%d") = "'.date('m-d',strtotime(current_date())).'"')->result_array();
               
            if(!empty($user_details)) {
                $notification_title = SITENAME.' - Offer Day';
                $notification_description = 'Today, you will get '.$get_advisor_promocode[0]['discount_value'].'% discount on every booking.';
                if($get_advisor_promocode[0]['discount_type'] == 'flat') {
                    $notification_description = 'Today, you will get '.$get_advisor_promocode[0]['discount_type'].' '.$get_advisor_promocode[0]['discount_value'].'$ discount on every booking.';
                } 
                $ios_users = array_filter($user_details, function ($value) {
                    return $value['device_type'] == 1;
                });
                if(count($ios_users) > 0) {
                    $ios_tokens = array_values(array_column($ios_users, 'device_token'));
                    send_bulk_push($ios_tokens, 'ios', $notification_title, $notification_description, 'general');
                }
                $android_users = array_filter($user_details, function ($value) {
                    return $value['device_type'] == 2;
                });
                if(count($android_users) > 0) {
                    $android_tokens = array_values(array_column($android_users, 'device_token'));
                    send_bulk_push($android_tokens, 'android', $notification_title, $notification_description, 'general');
                }
                $cron_data['status'] = 1;
            }
        }

        $cron_data['type'] = "customer_birthday";
        $cron_data['created_at'] = current_date();
        $this->comman->insert_record("cron_log", $cron_data);
    }

    public function autopay(){

        $advisors =  $this->db->query('SELECT users.id,account_detail as email,device_type,device_token
        FROM users 
        JOIN users_groups ON users.id = users_groups.user_id
        JOIN advisor_payment_detail ON users.id= advisor_payment_detail.user_id
        JOIN booking_request on users.id = booking_request.advisor_id
        JOIN advisor_amount_log ON booking_request.id = advisor_amount_log.booking_id
        WHERE users_groups.group_id = '.$this->config->item('roles', 'ion_auth')['service_provider'].' AND advisor_amount_log.status = 0 AND booking_request.status = 1 AND booking_request.end_time IS NOT NULL AND booking_request.is_session_running = 1 AND DATE(booking_request.end_time) <= DATE_SUB(DATE(NOW()), INTERVAL 15 DAY)  GROUP BY users.id')->result_array();
        
        $admin_details = $this->db->select('value')->from('settings')->where('name','admin_paypal_commission')->get()->row_array();

        $items = [];
        $token = get_token();
        $current_date = current_date();
        if(!empty(array_values($advisors))){

            foreach ($advisors as $key => $value) {
                
                $available = $this->available($value['id'],'sum');

                if(!empty($available) && $available[0]['advisor_available_amount'] != 0 && $available[0]['advisor_available_amount'] != null && $available[0]['advisor_available_amount'] >= 500){
                    $payout_amount = number_format($available[0]['advisor_available_amount'], 2);
                    if(number_format($available[0]['advisor_available_amount'], 2) > (int)$admin_details['value']){
                        $payout_amount = number_format($available[0]['advisor_available_amount'], 2) - (int)$admin_details['value'];
                    }
                    $items[] = ["recipient_type" => "EMAIL","amount" => ["value" => $payout_amount,"currency" => "USD"],"receiver" => $value['email'],"note" => "Payout #".$token];
                }
            }
        //    _pre($items);
            if(!empty(array_values($items))){
               
                
                $response = payout_bulk(json_encode($items),$token);
                $withdrawal_log = [];
                
                if(!isset(json_decode($response['response'],true)['error']) && (!isset(json_decode($response['response'],true)['name']))){

                    foreach (array_column($advisors,'id') as $key => $value) {

                        $available = $this->available($value,'sum');
                        if(!empty($available) && $available[0]['advisor_available_amount'] != 0 && $available[0]['advisor_available_amount'] != null && $available[0]['advisor_available_amount'] >= 500){
                            $withdrawal_log[$key]['user_id'] = $value; 
                            $withdrawal_log[$key]['batch_id'] = $response['batch_id'];
                            $withdrawal_log[$key]['initiate_response'] = $response['response'];
                            $withdrawal_log[$key]['token'] = $token;
                            $withdrawal_log[$key]['created_at'] = $current_date;
                        }

                    }
                    $this->db->insert_batch('withdrawal_log',array_values($withdrawal_log));
                    
                    $payout_batch_id = json_decode($response['response'],true)['batch_header']['payout_batch_id'];
                    sleep(8);
                    $payment_status = payment_status($payout_batch_id,$token);
                    $items = json_decode($payment_status,true)['items'];
                    //_pre( json_encode($items,true));
                    $success = [];
                    $advisor_amount_log = [];
                    $advisor_update = [];
                    $admin_paypal_commission = [];
                    
                    foreach ($items as $key => $value) {

                        if($value['transaction_status'] == 'SUCCESS'){

                            $email = $value['payout_item']['receiver'];
                            $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                                if($val['email'] == $email){
                                    return $val['id'];
                                }
                            }),'id'));
                            
                            $success[$key]['user_id'] = $id[0];
                            $success[$key]['amount_type'] = 'withdraw';
                            $success[$key]['amount'] = (int)$value['payout_item']['amount']['value'];
                            $success[$key]['created_at']  = $current_date;

                            $available = $this->available($id[0],'booking_id');
                            $booking_ids = implode(',',array_column($available,'id'));

                            $withdrawal_update[$key]['user_id'] = $id[0];
                            $withdrawal_update[$key]['success_response'] = $payment_status;
                            $withdrawal_update[$key]['status'] = 1;
                            $withdrawal_update[$key]['booking_ids'] = $booking_ids;

                            $profile = $this->comman->get_record_byid('users', $id[0], 'advisor_withdrawal_amount');
                            $amount = $profile['advisor_withdrawal_amount'] - $value['payout_item']['amount']['value'];
                            $advisor_update[$key]['id'] = $id[0];
                            $advisor_update[$key]['advisor_withdrawal_amount'] = $amount;

                            $admin_paypal_commission[$key]['advisor_id']       = $id[0];
                            $admin_paypal_commission[$key]['booking_id']       = $booking_ids;
                            $admin_paypal_commission[$key]['amount']           = $value['payout_item']['amount']['value'] + $admin_details['value'];
                            $admin_paypal_commission[$key]['admin_commission'] = $admin_details['value'];
                            $admin_paypal_commission[$key]['created_at']       = $current_date;

                            $paypal_transaction_log[$key]['user_id'] = $id[0];
                            $paypal_transaction_log[$key]['booking_id'] = $booking_ids;
                            $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                            $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                            $paypal_transaction_log[$key]['payout_batch_id'] = $payout_batch_id;
                            $paypal_transaction_log[$key]['items'] = json_encode($value,true);
                            $paypal_transaction_log[$key]['token'] = $token;
                            $paypal_transaction_log[$key]['status'] = 1;
                            $paypal_transaction_log[$key]['created_at'] =  $current_date;

                            // $advisor_amount_log[$key]['advisor_id'] = $id[0];
                            // $advisor_amount_log[$key]['status'] = 1;
                            // $advisor_amount_log[$key]['updated_at'] = $current_date;
                            $this->db->query('UPDATE advisor_amount_log SET status = 1,updated_at = "'.$current_date.'" WHERE booking_id IN('.$booking_ids.')');

                            $title = "Payment Successful";
                            $description = "Earning amount ".(int)$value['payout_item']['amount']['value']." of ".$current_date." transferred to your account.";
                            $notification[$key]['sent_to'] = $id[0];
                            $notification[$key]['sent_by'] = 1;
                            $notification[$key]['title'] = $title;
                            $notification[$key]['description'] = $description;
                            $notification[$key]['created_at'] = $current_date;
                            send_push($id[0],'users',$title,$description,'general');

                        }else if($value['transaction_status'] == 'PENDING' || $value['transaction_status'] == 'ONHOLD'){

                            $email = $value['payout_item']['receiver'];
                            $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                                if($val['email'] == $email){
                                    return $val['id'];
                                }
                            }),'id'));

                            $available = $this->available($id[0],'booking_id');
                            $booking_ids = implode(',',array_column($available,'id'));

                            $withdrawal_update[$key]['user_id'] = $id[0];
                            $withdrawal_update[$key]['success_response'] = $payment_status;
                            $withdrawal_update[$key]['status'] = 3;
                            $withdrawal_update[$key]['booking_ids'] = $booking_ids;

                            $profile = $this->comman->get_record_byid('users', $id[0], 'advisor_withdrawal_amount');
                            $amount = $profile['advisor_withdrawal_amount'] - $value['payout_item']['amount']['value'];
                            $advisor_update[$key]['id'] = $id[0];
                            $advisor_update[$key]['advisor_withdrawal_amount'] = $amount;

                            $admin_paypal_commission[$key]['advisor_id']       = $id[0];
                            $admin_paypal_commission[$key]['payout_item_id']   = $value['payout_item_id'];
                            $admin_paypal_commission[$key]['payout_batch_id']  = $payout_batch_id;
                            $admin_paypal_commission[$key]['booking_id']       = $booking_ids;
                            $admin_paypal_commission[$key]['amount']           = $value['payout_item']['amount']['value'] + $admin_details['value'];
                            $admin_paypal_commission[$key]['admin_commission'] = $admin_details['value'];
                            $admin_paypal_commission[$key]['created_at']       = $current_date;

                            $paypal_transaction_log[$key]['user_id'] = $id[0];
                            $paypal_transaction_log[$key]['booking_id'] = $booking_ids;
                            $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                            $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                            $paypal_transaction_log[$key]['payout_batch_id'] = $payout_batch_id;
                            $paypal_transaction_log[$key]['items'] = json_encode($value,true);
                            $paypal_transaction_log[$key]['token'] = $token;
                            $paypal_transaction_log[$key]['status'] = 0;
                            $paypal_transaction_log[$key]['created_at'] =  $current_date;

                            // $advisor_amount_log[$key]['advisor_id'] = $id[0];
                            // $advisor_amount_log[$key]['status'] = 3;
                            // $advisor_amount_log[$key]['updated_at'] = $current_date;
                            $this->db->query('UPDATE advisor_amount_log SET status = 3,updated_at = "'.$current_date.'" WHERE booking_id IN('.$booking_ids.')');

                            $title = "Payment Pending";
                            $description = "Earning amount ".(int)$value['payout_item']['amount']['value']." of ".$current_date." is in Pending.Please Wait!";
                            $notification[$key]['sent_to'] = $id[0];
                            $notification[$key]['sent_by'] = 1;
                            $notification[$key]['title'] = $title;
                            $notification[$key]['description'] = $description;
                            $notification[$key]['created_at'] = $current_date;
                            send_push($id[0],'users',$title,$description,'general');

                        }
                        else if($value['transaction_status'] == 'UNCLAIMED'){
                            sleep(5);
                            $unclaimed = json_decode(cancel_unclaimed_payment($value['payout_item_id'],$token),true);
                            if(!empty($unclaimed) && isset($unclaimed['transaction_status']) && $unclaimed['transaction_status'] == "RETURNED"){

                                $email = $value['payout_item']['receiver'];
                                $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                                    if($val['email'] == $email){
                                        return $val['id'];
                                    }
                                }),'id'));

                                $available = $this->available($id[0],'booking_id');
                                $booking_ids = implode(',',array_column($available,'id'));

                                $withdrawal_update[$key]['user_id'] = $id[0];
                                $withdrawal_update[$key]['success_response'] = $payment_status;
                                $withdrawal_update[$key]['status'] = 3;
                                $withdrawal_update[$key]['booking_ids'] = $booking_ids;

                                $paypal_transaction_log[$key]['user_id'] = $id[0];
                                $paypal_transaction_log[$key]['booking_id'] = $booking_ids;
                                $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                                $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                                $paypal_transaction_log[$key]['payout_batch_id'] = $payout_batch_id;
                                $paypal_transaction_log[$key]['items'] = json_encode($value,true);
                                $paypal_transaction_log[$key]['token'] = $token;
                                $paypal_transaction_log[$key]['status'] = 3;
                                $paypal_transaction_log[$key]['created_at'] =  $current_date;

                                $title = "Payment Failed";
                                $description = "Earning amount ".$value['payout_item']['amount']['value']." of ".$current_date." Transferred failed! You don't have Paypal account associated with email that you provided. Please first open your Paypal Account.";
                                $notification[$key]['sent_to'] = $id[0];
                                $notification[$key]['sent_by'] = 1;
                                $notification[$key]['title'] = $title;
                                $notification[$key]['description'] = $description;
                                $notification[$key]['created_at'] = $current_date;
                                send_push($id[0],'users',$title,$description,'general');
                            }
                        }
                        else{

                            $email = $value['payout_item']['receiver'];
                            $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                                if($val['email'] == $email){
                                    return $val['id'];
                                }
                            }),'id'));
                            
                            $withdrawal_update[$key]['user_id'] = $id[0];
                            $withdrawal_update[$key]['success_response'] = $payment_status;
                            $withdrawal_update[$key]['status'] = 2;

                            $available = $this->available($id[0],'booking_id');
                            $booking_ids = implode(',',array_column($available,'id'));

                            $paypal_transaction_log[$key]['user_id'] = $id[0];
                            $paypal_transaction_log[$key]['booking_id'] = $booking_ids;
                            $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                            $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                            $paypal_transaction_log[$key]['payout_batch_id'] = $payout_batch_id;
                            $paypal_transaction_log[$key]['items'] = json_encode($value,true);
                            $paypal_transaction_log[$key]['token'] = $token;
                            $paypal_transaction_log[$key]['status'] = 2;
                            $paypal_transaction_log[$key]['created_at'] =  $current_date;

                            $title = "Payment Failed";
                            $description = "Earning amount ".(int)$value['payout_item']['amount']['value']." of ".$current_date."  transferred failed due to technical reason. Please contact admin.";
                            $notification[$key]['sent_to'] = $id[0];
                            $notification[$key]['sent_by'] = 1;
                            $notification[$key]['title'] = $title;
                            $notification[$key]['description'] = $description;
                            $notification[$key]['created_at'] = $current_date;
                            send_push($id[0],'users',$title,$description,'general');
                        }
                    }

                    if(!empty(array_values($success))){
                        $this->db->insert_batch('wallet',$success);
                    }
                    if(!empty(array_values($paypal_transaction_log))){
                        $this->db->insert_batch('paypal_transaction_log',$paypal_transaction_log);
                    }
                    if(!empty(array_values($notification))){
                        $this->db->insert_batch('notification',$notification);
                    }
                    if(!empty(array_values($withdrawal_update))){
                        $this->db->where('batch_id',$response['batch_id']);
                        $this->db->update_batch('withdrawal_log', array_values($withdrawal_update), 'user_id');
                    }
                    if(!empty(array_values($advisor_update))){
                        $this->db->update_batch('users', array_values($advisor_update), 'id');   
                    }
                    if(!empty(array_values($admin_paypal_commission))){
                        $this->db->insert_batch('admin_paypal_commission_log',$admin_paypal_commission);
                    }
                    // if(!empty(array_values($advisor_amount_log))){
                    //     $this->db->where('status',0);
                    //     $this->db->update_batch('advisor_amount_log', array_values($advisor_amount_log), 'advisor_id');
                    // }
                    $cron_data['status'] = 1;
                }
            }
        }

        $cron_data['type'] = "autopay";
        $cron_data['created_at'] = $current_date;
        $this->comman->insert_record("cron_log", $cron_data);
    }

    public function available($id,$type = ''){

        $select = "REPLACE(FORMAT(SUM(booking_request.advisor_commission), 2), ',', '1') as advisor_available_amount";
        if($type == 'booking_id'){
            $select = 'booking_request.id,booking_request.advisor_commission';
        }

        $where = "advisor_amount_log.status = 0 AND DATE(booking_request.end_time) <= DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)";
        $available = $this->db->select($select)->from('booking_request')
                            ->join('advisor_amount_log','booking_request.id = advisor_amount_log.booking_id')
                            ->where('booking_request.advisor_id',$id)
                            ->where('booking_request.status != 2')
                            ->where('booking_request.end_time IS NOT NULL')
                            ->where('booking_request.is_session_running',1)
                            ->where($where)->get()->result_array();

        if($type != 'booking_id'){
            foreach ($available as $key => $value) {
                if($type != 'booking_id'){
                    $row[$key] = $value;
                    $row[$key]['advisor_available_amount'] = str_replace(',','',$value['advisor_available_amount']);
                }
            }
            $available = $row;
        }
        
        return $available;
    }

    public function get_available(){
        $data = $this->available('760');
        _pre($data);
    }
    
    public function pending_transactions(){
        $token = get_token();
        //_pre(json_decode(payout_item_details("GSXLW5WS8T5TU",$token),true));
        $current_date = current_date();
        $paypal_transaction_update = [];
        $notification = [];
        $paypal_transaction = $this->db->select('*')->from('paypal_transaction_log')->where('status',0)->get()->result_array();
        
        if(!empty(array_values($paypal_transaction))){
            
            foreach ($paypal_transaction as $key => $value) {

                if($value['payout_item_id'] != ''){
                    $response[] = json_decode(payout_item_details($value['payout_item_id'],$token),true);
                    
                    if($response[$key]['transaction_status'] == "SUCCESS"){

                        $paypal_transaction_update[$key]['status'] = 1;
                        $paypal_transaction_update[$key]['payout_item_id'] = $value['payout_item_id'];
                        $paypal_transaction_update[$key]['updated_items'] = json_encode($response[$key]);

                        $title = "Payment Successful";
                        $description = "Pending amount ".$response[$key]['payout_item']['amount']['value']." of ".$value['created_at']." transferred to your account.";
                        $notification[$key]['sent_to'] = $value['created_at'];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                        //send_push($value['created_at'],'users',$title,$description,'general');
                    }else if($response[$key]['transaction_status'] == "RETURNED"){

                        $paypal_transaction_update[$key]['status'] = 4;
                        $paypal_transaction_update[$key]['payout_item_id'] = $value['payout_item_id'];
                        $paypal_transaction_update[$key]['updated_items'] = json_encode($response[$key]);
                        $title = "Payment Returned";
                        $description = "Pending amount ".$response[$key]['payout_item']['amount']['value']." of ".$value['created_at']." transferred to your account.";
                        $notification[$key]['sent_to'] = $value['created_at'];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                        // send_push($value['created_at'],'users',$title,$description,'general');
                    }else if($response[$key]['transaction_status'] == "FAILED"){

                        $paypal_transaction_update[$key]['status'] = 2;
                        $paypal_transaction_update[$key]['payout_item_id'] = $value['payout_item_id'];
                        $paypal_transaction_update[$key]['updated_items'] = json_encode($response[$key]);
                        $title = "Payment Failed";
                        $description = "Pending amount ".$response[$key]['payout_item']['amount']['value']." of ".$value['created_at']." is failed.";
                        $notification[$key]['sent_to'] = $value['created_at'];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                        //send_push($value['created_at'],'users',$title,$description,'general');
                    }
                    
                }
            }
        
            $cron_data['status'] = 1;
        }
        
        if(!empty(array_values($paypal_transaction_update))){
            $this->db->update_batch('paypal_transaction_log', array_values($paypal_transaction_update), 'payout_item_id');   
        }
        if(!empty(array_values($notification))){
            $this->db->insert_batch('notification',$notification);
        }

        $cron_data['type'] = "pending_transactions";
        $cron_data['created_at'] = $current_date;
        $this->comman->insert_record("cron_log", $cron_data);
        //_pre(array_values( $response));
    }

    public function test_cron(){
       
        $advisors =  $this->db->query('SELECT users.id,account_detail as email,device_type,device_token
        FROM users 
        JOIN users_groups ON users.id = users_groups.user_id
        JOIN advisor_payment_detail ON users.id= advisor_payment_detail.user_id
        JOIN booking_request on users.id = booking_request.advisor_id
        JOIN advisor_amount_log ON booking_request.id = advisor_amount_log.booking_id
        WHERE users_groups.group_id = '.$this->config->item('roles', 'ion_auth')['service_provider'].' AND advisor_amount_log.status = 0 AND booking_request.status = 1 AND booking_request.end_time IS NOT NULL AND booking_request.is_session_running = 1 AND DATE(booking_request.end_time) <= DATE_SUB(DATE(NOW()), INTERVAL 15 DAY)  GROUP BY users.id')->result_array();

        //$available = $this->available(256,'sum');
        foreach ($advisors as $key => $value) {
                
            $available = $this->available($value['id'],'sum');

            if(!empty($available) && $available[0]['advisor_available_amount'] != 0 && $available[0]['advisor_available_amount'] != null){
                $items[] = ["recipient_type" => "EMAIL","amount" => ["value" => number_format($available[0]['advisor_available_amount'], 2),"currency" => "USD"],"receiver" => $value['email'],"note" => "Payouts sample transaction"];
            }
        }
        $booking_ids = implode(',',array_column($available,'id'));
        $profile = $this->comman->get_record_byid('users', 469, 'advisor_withdrawal_amount');
        _pre($items);
        //
    }

    public function test_update(){
        // $update_data[] = array(
        //     'booking_id' => "5,6",
        //     'status' => 1 //expire status
        //     );
            
            //$advisor_amount_log['booking_id'] = "5,6";
            // $current_date = current_date();
            // $id = $this->db->select('booking_id')->from('advisor_amount_log')
            //                                     ->where('advisor_id',250)
            //                                     ->where('status',0)
            //                                     ->get()->result_array();
            // $ids = implode(',',array_column($id,'booking_id'));
            // $advisor_amount_log['status'] = 1;
            // $this->db->where_in('booking_id', $ids);
            // $this->db->update('advisor_amount_log', $advisor_amount_log);


            // $current_date = current_date();
            // $popup = $this->db->query("SELECT CASE WHEN popup_end_time IS NULL THEN TIME_TO_SEC(TIMEDIFF('".$current_date."',popup_start_time)) ELSE null END AS seconds,TIME_TO_SEC(TIMEDIFF(popup_end_time,popup_start_time)) diff FROM booking_request WHERE id = 5103")->row_array();
            $token = get_token();
            // $payment_status = payment_status("TKU6BJ3T3JSVE",$token);
            // $items = json_decode($payment_status,true);
            $data = json_decode(payout_item_details("TKU6BJ3T3JSVE",$token),true);
            //$return = json_decode(cancel_unclaimed_payment("XPAP6KAZA9AAY",$token),true);
            // _pre($return);
            _pre($data);
            

            //$popup = $this->db->query("SELECT CONVERT_TZ(NOW(),'+00:00','+04:00')")->row_array();
            //$this->db->update_batch('advisor_amount_log', $advisor_amount_log, 'booking_id');
    }

    public function identity(){

        $token = get_token();
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/payments/payouts-item/XP7TN7L5YZ8VG/cancel');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: Bearer '.$token;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        _pre($result);
    }

    public function autopay1(){

        $advisors = $this->db->select('users.id,advisor_withdrawal_amount,account_detail as email,device_type,device_token')->from('users')->join('advisor_payment_detail', 'users.id= advisor_payment_detail.user_id')->where('advisor_withdrawal_amount >= 500')->get()->result_array();
        
        $items = [];
        $current_date = current_date();
        if(!empty(array_values($advisors))){

            foreach ($advisors as $key => $value) {
                $items[] = ["recipient_type" => "EMAIL","amount" => ["value" => $value['advisor_withdrawal_amount'],"currency" => "USD"],"receiver" => $value['email'],"note" => "Payouts sample transaction"];
            }

            $token = get_token();
            $response = payout_bulk(json_encode($items),$token);
            $withdrawal_log = [];
            if(!isset(json_decode($response['response'],true)['error']) && (!isset(json_decode($response['response'],true)['name']))){
                foreach (array_column($advisors,'id') as $key => $value) {
                    $withdrawal_log[$key]['user_id'] = $value; 
                    $withdrawal_log[$key]['batch_id'] = $response['batch_id'];
                    $withdrawal_log[$key]['initiate_response'] = $response['response'];
                    $withdrawal_log[$key]['token'] = $token;
                    $withdrawal_log[$key]['created_at'] = $current_date;
                }
                $this->db->insert_batch('withdrawal_log',array_values($withdrawal_log));
                
                $payout_batch_id = json_decode($response['response'],true)['batch_header']['payout_batch_id'];
                sleep(8);
                $payment_status = payment_status($payout_batch_id,$token);
                $items = json_decode($payment_status,true)['items'];
                
                $success = [];
                $advisor_amount_log = [];
                $advisor_update = [];

                foreach ($items as $key => $value) {
                    if($value['transaction_status'] == 'SUCCESS'){

                        $email = $value['payout_item']['receiver'];
                        $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                            if($val['email'] == $email){
                                return $val['id'];
                            }
                        }),'id'));
                        
                        $success[$key]['user_id'] = $id[0];
                        $success[$key]['amount_type'] = 'withdraw';
                        $success[$key]['amount'] = (int)$value['payout_item']['amount']['value'];
                        $success[$key]['created_at']  = $current_date;

                        $booking_ids = $this->db->select('booking_id')->from('advisor_amount_log')
                                                ->where('advisor_id',$id[0])
                                                ->where('status',0)
                                                ->get()->result_array();

                        $withdrawal_update[$key]['user_id'] = $id[0];
                        $withdrawal_update[$key]['success_response'] = $payment_status;
                        $withdrawal_update[$key]['status'] = 1;
                        $withdrawal_update[$key]['booking_ids'] = implode(',',array_column($booking_ids,'booking_id'));

                        $advisor_update[$key]['id'] = $id[0];
                        $advisor_update[$key]['advisor_withdrawal_amount'] = 0;

                        $paypal_transaction_log[$key]['user_id'] = $id[0];
                        $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                        $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                        $paypal_transaction_log[$key]['status'] = 1;
                        $paypal_transaction_log[$key]['created_at'] =  $current_date;

                        $advisor_amount_log[$key]['advisor_id'] = $id[0];
                        $advisor_amount_log[$key]['status'] = 1;
                        $advisor_amount_log[$key]['updated_at'] = $current_date;

                        $title = "Payment Successful";
                        $description = "Earning amount ".(int)$value['payout_item']['amount']['value']." of ".$current_date." transferred to your account.";
                        $notification[$key]['sent_to'] = $id[0];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                        send_push($id[0],'users',$title,$description,'general');

                    }else if($value['transaction_status'] == 'PENDING'){

                        $email = $value['payout_item']['receiver'];
                        $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                            if($val['email'] == $email){
                                return $val['id'];
                            }
                        }),'id'));

                        $booking_ids = $this->db->select('booking_id')->from('advisor_amount_log')
                                                ->where('advisor_id',$id[0])
                                                ->where('status',0)
                                                ->get()->result_array();

                        $withdrawal_update[$key]['user_id'] = $id[0];
                        $withdrawal_update[$key]['success_response'] = $payment_status;
                        $withdrawal_update[$key]['status'] = 3;
                        $withdrawal_update[$key]['booking_ids'] = implode(',',array_column($booking_ids,'booking_id'));

                        $advisor_update[$key]['id'] = $id[0];
                        $advisor_update[$key]['advisor_withdrawal_amount'] = 0;

                        $paypal_transaction_log[$key]['user_id'] = $id[0];
                        $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                        $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                        $paypal_transaction_log[$key]['status'] = 0;
                        $paypal_transaction_log[$key]['created_at'] =  $current_date;

                        $advisor_amount_log[$key]['advisor_id'] = $id[0];
                        $advisor_amount_log[$key]['status'] = 3;
                        $advisor_amount_log[$key]['updated_at'] = $current_date;

                        $title = "Payment Pending";
                        $description = "Earning amount ".(int)$value['payout_item']['amount']['value']." of ".$current_date." is in Pending.Please contact admin.";
                        $notification[$key]['sent_to'] = $id[0];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                        send_push($id[0],'users',$title,$description,'general');

                    }
                    else{
                        $email = $value['payout_item']['receiver'];
                        $id = array_values( array_column(array_filter($advisors,function($val) use($email){
                            if($val['email'] == $email){
                                return $val['id'];
                            }
                        }),'id'));
                        
                        $withdrawal_update[$key]['user_id'] = $id[0];
                        $withdrawal_update[$key]['success_response'] = $payment_status;
                        $withdrawal_update[$key]['status'] = 2;

                        $paypal_transaction_log[$key]['user_id'] = $id[0];
                        $paypal_transaction_log[$key]['amount'] = $value['payout_item']['amount']['value'];
                        $paypal_transaction_log[$key]['payout_item_id'] = $value['payout_item_id'];
                        $paypal_transaction_log[$key]['status'] = 2;
                        $paypal_transaction_log[$key]['created_at'] =  $current_date;

                        $title = "Payment Failed";
                        $description = "Earning amount ".(int)$value['payout_item']['amount']['value']." of ".$current_date."  transferred failed due to technical reason. Please contact admin.";
                        $notification[$key]['sent_to'] = $id[0];
                        $notification[$key]['sent_by'] = 1;
                        $notification[$key]['title'] = $title;
                        $notification[$key]['description'] = $description;
                        $notification[$key]['created_at'] = $current_date;
                        send_push($id[0],'users',$title,$description,'general');
                    }
                }

                if(!empty(array_values($success))){
                    $this->db->insert_batch('wallet',$success);
                }
                if(!empty(array_values($paypal_transaction_log))){
                    $this->db->insert_batch('paypal_transaction_log',$paypal_transaction_log);
                }
                if(!empty(array_values($notification))){
                    $this->db->insert_batch('notification',$notification);
                }
                if(!empty(array_values($withdrawal_update))){
                    $this->db->where('batch_id',$response['batch_id']);
                    $this->db->update_batch('withdrawal_log', array_values($withdrawal_update), 'user_id');
                }
                if(!empty(array_values($advisor_update))){
                    $this->db->update_batch('users', array_values($advisor_update), 'id');   
                }
                if(!empty(array_values($advisor_amount_log))){
                    $this->db->where('status',0);
                    $this->db->update_batch('advisor_amount_log', array_values($advisor_amount_log), 'advisor_id');
                }
                // echo "<pre>";
                // print_r($withdrawal_update);
            }
        }
    }

   // $status_pending = 0;
        // $status_success = 0;
        // $status_fail = 0;
        // $pending = $this->db->select('*')->from('withdrawal_log')->where('status',0)->where('token IS NOT NULL')->group_by('batch_id')->get()->result_array();
        // $items = [];
        // if(!empty(array_values($pending))){
        //     foreach ($pending as $key => $value) {
        //         $payout_batch_id = json_decode($value['initiate_response'],true)['batch_header']['payout_batch_id'];
        //         $payment_status = payment_status($payout_batch_id,$token);
        //         //$items[$key] = json_decode($payment_status,true)['items'];
        //         foreach (json_decode($payment_status,true)['items'] as $key1 => $row) {
                    
        //             $response[] = $row;
        //             $advisor_id = $this->db->select('id,user_id')->from('advisor_payment_detail')->where('account_detail',$row['payout_item']['receiver'])->get()->row_array();
        //             $paypal_transaction_log = $this->db->select('id,payout_item_id,status,created_at')->from('paypal_transaction_log')->where('payout_item_id',$row['payout_item_id'])->where('user_id',$advisor_id['user_id'])->get()->row_array();
        //             if($row['transaction_status'] == 'SUCCESS'){
        //                 $withdrawal_update['status'] = 1;
        //                 $status_success = $status_success + 1;
        //             }
        //             else if($row['transaction_status'] == 'PENDING'){
        //                 $withdrawal_update['status'] = 0;
        //                 $status_pending = $status_pending + 1;
        //             }else{
        //                 $withdrawal_update['status'] = 2;
        //                 $status_fail = $status_fail + 1;
        //             }
        //             if(!empty($paypal_transaction_log)){
        //                 if($paypal_transaction_log['status'] == 0 && $row['transaction_status'] == 'SUCCESS'){
                           
        //                     $title = "Payment Successful";
        //                     $description = "Pending Earning amount ".(int)$row['payout_item']['amount']['value']." of ".$paypal_transaction_log['created_at']." transferred to your account.";
        //                     $notification['sent_to'] = $advisor_id['user_id'];
        //                     $notification['sent_by'] = 1;
        //                     $notification['title'] = $title;
        //                     $notification['description'] = $description;
        //                     $notification['created_at'] = $current_date;
        //                     send_push($advisor_id['user_id'],'users',$title,$description,'general');
                            
        //                 }
        //                 else if($paypal_transaction_log['status'] == 0 && ($row['transaction_status'] != 'SUCCESS' || $row['transaction_status'] != 'PENDING')){
        //                     $title = "Payment Failed";
        //                     $description = "Pending Earning amount ".(int)$row['payout_item']['amount']['value']." of ".$paypal_transaction_log['created_at']."  transferred failed due to technical reason. Please contact admin.";
        //                     $notification['sent_to'] =  $advisor_id['user_id'];
        //                     $notification['sent_by'] = 1;
        //                     $notification['title'] = $title;
        //                     $notification['description'] = $description;
        //                     $notification['created_at'] = $current_date;
        //                     send_push($advisor_id['user_id'],'users',$title,$description,'general');
        //                 }
        //             }
        //             // $this->db->update('withdrawal_log', $withdrawal_update, ['user_id' => $advisor_id['user_id'],'batch_id' => $value['batch_id']]);
        //             // $this->db->update('paypal_transaction_log', $withdrawal_update, ['payout_item_id' => $row['payout_item_id'],'user_id' =>  $advisor_id['user_id']]);
        //         }
        //     }

        // }

    public function transaction(){
        $token = get_token();
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://api-m.sandbox.paypal.com/v1/reporting/transactions?start_date=2021-03-19T00:00:00-0700&end_date=2021-03-21T23:59:59-0700&transaction_id=69L31655161487010&fields=all&page_size=100&page=1');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: Bearer '.$token;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        _pre(json_decode($result,true));
    }

    
}


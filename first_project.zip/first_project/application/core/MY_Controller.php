<?php 
abstract class MY_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        
        if (!$this->ion_auth->logged_in()) {
            redirect('auth/login');
        }  
        define('SLUG', trim($this->session->userdata('role_id')));
    }

    public function renderAdmin($page = null,$params = null, $return = false)
    {
        
        $params['body_class'] = $this->_generate_body_class();
        $this->load->view('admin/layout/header',$params);
        $this->load->view('admin/layout/sidebar',$params);
        if($page != null){
            $this->load->view('admin/pages/'.$page,$params,$return);
        }
        $this->load->view('admin/layout/footer',$params);
    }
    
    // public function renderWebsite($page = null,$params = null, $return = false)
    // {
    //     $params['body_class'] = $this->_generate_body_class();
    //     $this->load->view('website/header',$params);
    //     // $this->load->view('kitchen/layout/sidebar',$params);
    //     if($page != null){
    //         $this->load->view('website/'.$page,$params,$return);
    //     }
    //     $this->load->view('website/footer',$params);
    // }

    public function response($data = null,$http = null,$format = 'json')
    {
        echo json_encode($data);
    }
    

    public function _generate_body_class()
    {
        if($this->uri->segment_array() == null){
            $uri = array('index');
        }else{
            $uri = $this->uri->segment_array();
            if(end($uri) == 'index'){
                array_pop($uri);
            }
        }
        return implode('-', $uri);
    }

   

}